"""Seed the knowledge store from prior discovery runs and from the graph itself.

Two sources, deliberately different in character:

  * HARVESTED — the patterns, notes and gotchas that discovery agents verified against
    source at real cost. Their value is the *how* and the *why not*, which no amount of
    re-parsing recovers. Each keeps its file:line and is checked by re-confirming the
    cited evidence still exists.
  * DERIVED — facts the graph can restate and therefore prove exactly (counts, links).
    These are cheap, and their checks are strong.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from .knowledge import Claim, Knowledge

_FILE_LINE = re.compile(r"([A-Za-z0-9_./-]+\.(?:kt|kts|py|ts|tsx|toml|yaml|yml|json|md))(?::(\d+))?")

# Weighted, because a single keyword lies: a build gotcha mentioning the artifact
# `connector-slave` is not knowledge about slave handlers. Strong terms are worth more.
_TOPIC_RULES = [
    ("messaging", ("routingkey", "routing key", "rabbitmq", "publish", "subscribe",
                   "broker", "exchange", "queue", "dispatch")),
    ("slave-handlers", ("taskhandler", "taskhandlerrouter", "serviceloader",
                        "meta-inf/services", "spi", "consumerconfiguration",
                        "handleslavetaskuseCase", "browsertaskhandler", "jobpayload")),
    ("contracts", ("zodable", "serializable", "dto", "sealed", "serialname", "npm",
                   "wire", "contract")),
    ("http", ("resource", "ktor", "route", "endpoint", "kaccelero", "apimapping")),
    ("data-layer", ("exposed", "table", "column", "sql", "migration", "resultrow")),
    ("workflows", ("workflow", "step", "itemhistory", "state machine", "transition")),
    ("guards", ("guard", "early return", "elvis", "precondition", "return@")),
    ("tests", ("test", "mockk", "subject", "jvmtest")),
    ("build", ("gradle", "catalog", "libs.versions", "pin", "artifact", "maven",
               "publish", "settings.gradle")),
    ("di", ("koin", "single<", "injection", "constructor", "module")),
    ("app", ("typescript", "zustand", "awilix", "react", "packages/common")),
]


# Terms that identify a topic on their own; a passing mention of anything else does not.
_STRONG = {
    "slave-handlers": ("taskhandlerrouter", "serviceloader", "meta-inf/services",
                       "handleslavetaskusecase", "browsertaskhandler"),
    "build": ("libs.versions.toml", "version.ref", "gradle", "[libraries]", "[versions]"),
    "data-layer": ("exposed", "resultrow", "idtable", "schemautils"),
    "workflows": ("workflowstep", "itemhistorytype", "workflowimpl"),
    "http": ("@resource", "kaccelero", "apimapping", "ktor"),
    "tests": ("jvmtest", "mockk", "@test"),
    "guards": ("return@", "elvis", "early return"),
}


def _topic(text: str) -> str:
    """Highest-scoring topic, not the first keyword that happens to appear."""
    low = text.lower()
    best, best_score = "general", 0
    for topic, needles in _TOPIC_RULES:
        score = sum(3 if n in _STRONG.get(topic, ()) else 1
                    for n in needles if n in low)
        score += sum(4 for n in _STRONG.get(topic, ()) if n in low)
        if score > best_score:
            best, best_score = topic, score
    return best


def _cid(prefix: str, text: str) -> str:
    return f"{prefix}-{hashlib.sha1(text.encode()).hexdigest()[:10]}"


def _evidence(text: str, root: Path, limit: int = 4) -> list[str]:
    """Real file:line references only — a path that no longer exists is not evidence."""
    out: list[str] = []
    for m in _FILE_LINE.finditer(text or ""):
        path = m.group(1).lstrip("./")
        # Transcripts often quote absolute paths. Re-anchor them on the workspace by
        # its own directory name rather than a hardcoded one, which only worked on the
        # machine the name was taken from.
        marker = root.name + "/"
        if marker in path:
            path = path.split(marker, 1)[-1]
        if "/" not in path:
            continue
        if not (root / path).exists():
            continue
        ref = f"{path}:{m.group(2)}" if m.group(2) else path
        if ref not in out:
            out.append(ref)
        if len(out) >= limit:
            break
    return out


# Identifiers too generic to be worth checking — their presence proves nothing.
_GENERIC = {"String", "Boolean", "Long", "Int", "List", "Map", "Set", "Unit", "Any",
            "Table", "Column", "Test", "Impl", "Type", "Name", "Data", "Value",
            "Instant", "Uuid", "Note", "The", "This", "A", "An", "It", "If", "Do",
            "NOT", "AND", "OR", "ALL", "ONE", "TWO", "Kotlin", "Java", "JSON", "SQL"}
_IDENT = re.compile(r"\b([A-Z][A-Za-z0-9]{4,})\b")


def _check_for(evidence: list[str], root: Path, text: str = "",
               node_names: set[str] | None = None) -> dict | None:
    """Universal staleness signal: the cited evidence must still be there.

    A claim citing a file is checked on that file. One citing only a type — most
    gotchas do — is checked on the type still existing, which is weaker but still
    catches a rename or a deletion, and is far better than trusting it forever.
    """
    files = []
    for ref in evidence[:2]:
        path = ref.split(":")[0]
        if (root / path).exists():
            files.append({"op": "file_exists", "file": path})
    if files:
        return files[0] if len(files) == 1 else {"op": "all", "checks": files}
    if not node_names:
        return None
    seen: list[str] = []
    for m in _IDENT.finditer(text or ""):
        name = m.group(1)
        if name in _GENERIC or name in seen:
            continue
        if name in node_names:
            seen.append(name)
        if len(seen) >= 2:
            break
    if not seen:
        return None
    checks = [{"op": "node_exists", "name": n} for n in seen]
    return checks[0] if len(checks) == 1 else {"op": "all", "checks": checks}


def harvest(kb: Knowledge, transcripts: Path, root: Path,
            graph=None) -> dict[str, int]:
    """Turn prior discovery output into checked claims."""
    node_names = {n.name for n in graph.nodes.values()} if graph is not None else set()
    counts = {"patterns": 0, "gotchas": 0, "notes": 0, "skipped": 0}
    for journal in sorted(transcripts.glob("wf_*/journal.jsonl")):
        for line in journal.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                rec = json.loads(line)
            except Exception:
                continue
            if rec.get("type") != "result":
                continue
            res = rec.get("result")
            if not isinstance(res, dict):
                continue
            area = res.get("area", "")
            src = f"discovery/{journal.parent.name}"

            for p in res.get("patterns", []):
                name = " ".join((p.get("name") or "").split())
                how = " ".join((p.get("how_to_detect") or "").split())
                occ = " ".join((p.get("approx_occurrences") or "").split())
                if not name:
                    continue
                ev = _evidence(f"{p.get('evidence_file_line', '')} {how}", root)
                if not ev:
                    counts["skipped"] += 1
                    continue
                detail = how[:900]
                if occ:
                    detail += f"  [{occ[:180]}]"
                kb.add(Claim(id=_cid("pat", name + area), claim=name[:300],
                             topic=_topic(f"{area} {name} {how}"), kind="convention",
                             evidence=ev,
                             check=_check_for(ev, root, f"{name} {how}", node_names),
                             source=src, detail=detail))
                counts["patterns"] += 1

            for g in res.get("gotchas", []):
                text = " ".join((g or "").split())
                if len(text) < 25:
                    continue
                ev = _evidence(text, root)
                kb.add(Claim(id=_cid("got", text[:160]), claim=text[:300],
                             topic=_topic(f"{area} {text}"), kind="gotcha",
                             evidence=ev,
                             check=_check_for(ev, root, text, node_names),
                             source=src, detail=text[300:1100]))
                counts["gotchas"] += 1

            for n in res.get("notes", []):
                text = " ".join((n or "").split())
                if len(text) < 40:
                    continue
                ev = _evidence(text, root)
                kb.add(Claim(id=_cid("note", text[:160]), claim=text[:300],
                             topic=_topic(f"{area} {text}"), kind="convention",
                             evidence=ev,
                             check=_check_for(ev, root, text, node_names),
                             source=src, detail=text[300:1100]))
                counts["notes"] += 1
    return counts


def derive(kb: Knowledge, graph, stats: dict) -> int:
    """Facts the graph can restate exactly — cheap to make, strong to check."""
    n = 0

    def add(cid, claim, topic, check, detail="", kind="count"):
        nonlocal n
        kb.add(Claim(id=cid, claim=claim, topic=topic, kind=kind, check=check,
                     source="derived/graph", detail=detail))
        n += 1

    def count(kind_):
        return sum(1 for x in graph.nodes.values() if x.kind == kind_)

    add("derived-routing-keys",
        f"The message contract has exactly {count('routing_key')} routing keys.",
        "messaging",
        {"op": "count", "kind": "routing_key", "eq": count("routing_key")},
        "Where they are declared in one enum, that enum is the single source of truth "
        "and every other service resolves through it.")
    add("derived-tables",
        f"There are {count('table')} Exposed tables and "
        f"{sum(len(t.attrs.get('columns', [])) for t in graph.nodes.values() if t.kind == 'table')} "
        "columns; there is no migration tool, so the Table object IS the schema.",
        "data-layer", {"op": "count", "kind": "table", "eq": count("table")},
        "SchemaUtils.create() only creates missing TABLES — it never adds a column to an "
        "existing one. A new column needs a hand-run ALTER TABLE.")
    add("derived-workflows",
        f"{sum(1 for x in graph.nodes.values() if x.attrs.get('workflow'))} sealed "
        "workflow state machines drive the item and conversation pipelines.",
        "workflows",
        {"op": "node_exists", "name": "RepublishItemWorkflowStep"},
        "They advance three ways: a recursive invoke(NextStep), a broker publish then "
        "return (re-entered from a message handler), or a handler constructing a step.")
    add("derived-publish-coverage",
        "Every `send*` broker call site in source is represented in the graph.",
        "messaging", {"op": "stat", "key": "publish_coverage_pct", "gte": 95},
        "graphify doctor fails below 90%. It caught a walk that missed top-level Ktor "
        "route functions and silently dropped 15 publishes.", kind="process")
    add("derived-exposed-naming",
        "Exposed keeps the CamelCase object name VERBATIM for a table with no explicit "
        "name — it does not snake_case it.", "data-layer",
        {"op": "attr_eq", "name": "ItemOnPlatforms", "attr": "explicit_name", "value": False},
        "object ItemOnPlatforms -> table `ItemOnPlatforms`. Snake_casing it invents a "
        "table that does not exist; this is the single most likely wrong-answer here.",
        kind="gotcha")
    return n
