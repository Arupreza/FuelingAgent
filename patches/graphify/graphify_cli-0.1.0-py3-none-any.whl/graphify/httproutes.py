"""HTTP surface: Ktor type-safe resources, their handlers, and cross-package imports.

Ktor models a URL as a chain of nested `@Resource` classes linked by a `parent`
constructor property, so a path only exists once that chain is walked to its root.
Reconstructing it is what turns 181 opaque resource classes into a route table.
"""
from __future__ import annotations

import re

from . import model as M
from .extract import nid

# `\s` matches newlines, so `^\s*` happily starts on the blank line above the route
# and every such node reported a line number one too low. `[ \t]` keeps it on-line.
_HANDLER_1 = re.compile(
    r"^[ \t]*(get|post|put|delete|patch|head|options)<\s*([A-Za-z_][A-Za-z0-9_.]*)\s*>\s*\{", re.M)
# Ktor's typed-body overload: `post<Body>("/path") { }`. The type argument is the
# request body and the path is the literal -- the opposite of the resource form.
_HANDLER_BODY_PATH = re.compile(
    r"^[ \t]*(get|post|put|delete|patch)<\s*([A-Za-z_][A-Za-z0-9_.]*)\s*>\s*\(\s*\"([^\"]*)\"\s*\)",
    re.M)
_HANDLER_2 = re.compile(
    r"^[ \t]*(get|post|put|delete|patch|head|options)<\s*([A-Za-z_][A-Za-z0-9_.]*)\s*,"
    r"\s*([A-Za-z_][A-Za-z0-9_.<>?]*)\s*>\s*\{", re.M)
_HANDLER_STR = re.compile(
    r"^[ \t]*(get|post|put|delete|patch|webSocket|sse)\(\s*\"([^\"]*)\"\s*\)\s*\{", re.M)
_ROUTE_BLOCK = re.compile(r'^[ \t]*route\(\s*"([^"]*)"\s*\)\s*\{', re.M)
_AUTHENTICATE = re.compile(r"authenticate\(([^)]*)\)\s*\{")
_ROUTE_FN_CALL = re.compile(r"\b([a-z][A-Za-z0-9]*Routes)\s*\(\s*get\(\)\s*\)")
_ZOD_IMPORT = re.compile(r'@ZodImport\(\s*"([A-Za-z0-9_]+)"\s*,\s*"([a-z0-9-]+)"\s*\)')
_CONST_VAL = re.compile(r'const\s+val\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*"([^"]*)"')

# `presentation/routes/Extensions.kt` declares generic helpers whose type arguments
# are type *parameters* (R, L, B), not resources -- 10 phantom routes if not skipped.
_SKIP_ROUTE_FILES = ("presentation/routes/Extensions.kt",)


def link_http(ext) -> None:
    paths = _reconstruct_paths(ext)
    _link_handlers(ext, paths)
    _link_zod_imports(ext)
    _link_legacy_routers(ext)
    link_route_handlers(ext)


# kaccelero verb/path table. The annotation on a controller method decides both.
# `{id}` is a placeholder here: kaccelero uses `<model.lowercase()>Id`, filled in below.
_MODEL_PATHS = {
    "ListModelPath":   ("GET", ""),
    "GetModelPath":    ("GET", "/{id}"),
    "CreateModelPath": ("POST", ""),
    "UpdateModelPath": ("PUT", "/{id}"),
    "DeleteModelPath": ("DELETE", "/{id}"),
}
_ROUTER_BASES = {"APIModelRouter", "APIChildModelRouter", "WebSocketAPIModelRouter",
                 "WebSocketAPIChildModelRouter", "APIUnitRouter",
                 "AbstractModelRouter", "AbstractChildModelRouter"}
_NAMED_ARG = re.compile(r'\b(route|id|prefix)\s*=\s*"([^"]*)"')
_TYPEINFO = re.compile(r"typeInfo<\s*([A-Za-z_][A-Za-z0-9_.]*)\s*>")
_CONTROLLER = re.compile(r"\b(I[A-Za-z0-9_]*Controller)::class")
_ACTIVE = re.compile(r"get<\s*([A-Za-z0-9_]+Router)\s*>\s*\(\s*\)")


def _link_legacy_routers(ext) -> None:
    """The backend's second HTTP surface: kaccelero routers under controllers/.

    Only routers listed in `configureLegacyRouting()` are live, and only controller
    methods carrying BOTH @APIMapping and a path annotation produce an endpoint --
    there are no implicit CRUD routes.
    """
    active: set[str] = set()
    for rel, kf in ext.kt_files.items():
        if not rel.endswith("plugins/Routing.kt"):
            continue
        try:
            active |= set(_ACTIVE.findall(
                (ext.root / rel).read_text(encoding="utf-8", errors="replace")))
        except OSError:
            pass
    if not active:
        return

    routers: dict[str, dict] = {}
    for rel, kf in ext.kt_files.items():
        for d in kf.decls:
            if d.name not in active:
                continue
            base = next((sp.name for sp in d.supers if sp.name in _ROUTER_BASES), "")
            if not base:
                continue
            try:
                text = (ext.root / rel).read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            head = text[:text.find("{", text.find(f"class {d.name}"))] or text[:4000]
            named = dict(_NAMED_ARG.findall(head))
            models = _TYPEINFO.findall(head)
            ctrl = _CONTROLLER.search(head)
            model = models[0].split(".")[-1] if models else ""
            # kaccelero defaults the route to the pluralised model name; verified
            # against the client, which requests /places, /labels, /fields.
            route = named.get("route") or (model.lower() + "s" if model else "")
            routers[d.name] = {
                "file": rel, "line": d.line, "base": base, "model": model,
                "route": route, "prefix": named.get("prefix", ""),
                "controller": ctrl.group(1) if ctrl else "",
                "parent_router": next(
                    (p.type.split("<")[0].lstrip("I")
                     for p in d.ctor_params
                     if p.type and p.type.split("<")[0].rstrip("?").endswith("Router")),
                    ""),
            }

    def id_param(rec: dict) -> str:
        return f"{rec['model'].lower()}Id" if rec.get("model") else "id"

    def route_of(name: str, seen: tuple = ()) -> str:
        """Full route including every parent segment, per kaccelero's nesting rule."""
        rec = routers.get(name)
        if rec is None or name in seen:
            return ""
        parent = rec.get("parent_router")
        if parent and parent in routers:
            base = route_of(parent, seen + (name,))
            pid = id_param(routers[parent])
            # a pseudo-parent with an empty route contributes no segment
            if base:
                return f"{base}/{{{pid}}}/{rec['route']}".replace("//", "/")
        return f"{rec['prefix'].rstrip('/')}/{rec['route']}".replace("//", "/")

    svc = _service_of(ext, "controlresell-backend")
    for name, r in routers.items():
        if not r["controller"]:
            continue
        for rel, kf in ext.kt_files.items():
            iface = next((d for d in kf.decls if d.name == r["controller"]), None)
            if iface is None:
                continue
            base_path = route_of(name)
            for fn in iface.functions:
                anns = {a.name: a for a in fn.annotations}
                if "APIMapping" not in anns:
                    continue
                verb = suffix = None
                for ann_name, (v, sfx) in _MODEL_PATHS.items():
                    if ann_name in anns:
                        verb, suffix = v, sfx
                        break
                if verb is None and "Path" in anns:
                    args = anns["Path"].args or ""
                    lits = re.findall(r'"([^"]*)"', args)
                    if len(lits) >= 2:
                        verb = lits[0].upper()
                        suffix = ("/" + lits[1].lstrip("/")).rstrip("/")
                if verb is None:
                    continue
                path = (base_path + suffix.replace("{id}", "{" + id_param(r) + "}")) or "/"
                rid = nid(M.HTTP_ROUTE, f"controlresell-backend:{verb} {path}")
                ext.g.node(rid, M.HTTP_ROUTE, f"{verb} {path}",
                           repo="controlresell-backend", file=rel, line=fn.line,
                           attrs={"path": path, "verb": verb, "legacy": True,
                                  "router": name, "controller": r["controller"],
                                  "handler": fn.name, "auth": "api-v2-jwt (optional)"})
                ext.g.add_edge(svc, rid, M.EXPOSES, file=rel, line=fn.line,
                               attrs={"legacy": True})
                ext.stats["legacy_routes"] += 1
            break


def _reconstruct_paths(ext) -> dict[str, str]:
    """Walk each resource's `parent` chain to build its absolute URL template."""
    resources = {n.id: n for n in ext.g.by_kind(M.HTTP_ROUTE)
                 if "template" in n.attrs}
    # simple name -> node, for resolving `val parent: ItemsApi`
    by_simple: dict[str, list] = {}
    for n in resources.values():
        by_simple.setdefault(n.name, []).append(n)

    def parent_of(node):
        pt = (node.attrs.get("parent_resource") or "").split("<")[0].strip()
        if not pt:
            return None
        cands = by_simple.get(pt.split(".")[-1], [])
        if len(cands) == 1:
            return cands[0]
        for c in cands:                     # prefer the same file, then the same repo
            if c.file == node.file:
                return c
        for c in cands:
            if c.repo == node.repo:
                return c
        return None

    out: dict[str, str] = {}
    for node in resources.values():
        segs, cur, guard = [], node, 0
        while cur is not None and guard < 12:
            t = (cur.attrs.get("template") or "").strip()
            if t:
                segs.append(t)
            if t.startswith("/"):
                break
            cur = parent_of(cur)
            guard += 1
        segs.reverse()
        path = ""
        for s in segs:
            if s.startswith("/"):
                path = s
            elif s:
                path = f"{path.rstrip('/')}/{s}"
        node.attrs["path"] = path or (node.attrs.get("template") or "")
        node.attrs["resolved"] = bool(segs) and segs[0].startswith("/")
        out[node.name] = node.attrs["path"]
        # A path parameter is any {name} that matches a constructor property.
        params = re.findall(r"\{([A-Za-z_][A-Za-z0-9_]*)", node.attrs["path"])
        if params:
            node.attrs["path_params"] = params
        ext.stats["resources_resolved"] += 1 if node.attrs["resolved"] else 0
    return out


def _link_handlers(ext, paths) -> None:
    """`get<ItemsApi.Id> { }` binds an HTTP verb to a resource, in a service."""
    for rel, kf in ext.kt_files.items():
        if "/routes/" not in rel and not rel.endswith("Routes.kt"):
            continue
        if any(rel.endswith(s) for s in _SKIP_ROUTE_FILES):
            continue
        try:
            text = (ext.root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        repo = rel.split("/", 1)[0]
        svc = _service_of(ext, repo)
        consts = dict(_CONST_VAL.findall(text))

        seen: set[tuple] = set()
        for m in _HANDLER_2.finditer(text):
            verb, res, body = m.group(1), m.group(2), m.group(3)
            _emit(ext, kf, rel, text, m, svc, verb, res, body, seen)
        for m in _HANDLER_1.finditer(text):
            verb, res = m.group(1), m.group(2)
            if len(res) <= 2 and res.isupper():      # a generic type parameter
                continue
            _emit(ext, kf, rel, text, m, svc, verb, res, "", seen)
        for m in _HANDLER_BODY_PATH.finditer(text):
            verb, body, path = m.group(1), m.group(2), m.group(3)
            line = text.count("\n", 0, m.start()) + 1
            prefix = _enclosing_route(text, m.start())
            full = (prefix.rstrip("/") + "/" + path.lstrip("/")) if prefix else path
            rid = nid(M.HTTP_ROUTE, f"{repo}:{verb.upper()} {full}")
            ext.g.node(rid, M.HTTP_ROUTE, f"{verb.upper()} {full}", repo=repo,
                       file=rel, line=line,
                       attrs={"path": full, "literal": True, "verb": verb.upper(),
                              "request_type": body})
            ext.g.add_edge(svc, rid, M.EXPOSES, file=rel, line=line)
            bt = ext._resolve(body, kf, "")
            if bt:
                ext.g.add_edge(rid, nid("kt", bt), M.CARRIES, file=rel, line=line,
                               attrs={"direction": "request"})
            ext.stats["body_path_routes"] += 1

        for m in _HANDLER_STR.finditer(text):
            verb, path = m.group(1), m.group(2)
            for k, v in consts.items():
                path = path.replace(f"${k}", v).replace(f"${{{k}}}", v)
            line = text.count("\n", 0, m.start()) + 1
            prefix = _enclosing_route(text, m.start())
            full = (prefix.rstrip("/") + "/" + path.lstrip("/")) if prefix else path
            rid = nid(M.HTTP_ROUTE, f"{repo}:{verb.upper()} {full}")
            ext.g.node(rid, M.HTTP_ROUTE, f"{verb.upper()} {full}", repo=repo,
                       file=rel, line=line, attrs={"path": full, "literal": True})
            ext.g.add_edge(svc, rid, M.EXPOSES, file=rel, line=line)
            ext.stats["literal_routes"] += 1


def _emit(ext, kf, rel, text, m, svc, verb, res, body, seen) -> None:
    line = text.count("\n", 0, m.start()) + 1
    key = (verb, res, line)
    if key in seen:
        return
    seen.add(key)
    target = ext._resolve(res, kf, "")
    path = ""
    if target:
        node = ext.g.nodes.get(nid("kt", target))
        if node is not None:
            path = node.attrs.get("path", "")
            node.attrs.setdefault("verbs", []).append(verb.upper())
    rid = nid(M.HTTP_ROUTE, f"{rel.split('/', 1)[0]}:{verb.upper()} {path or res}")
    attrs = {"path": path, "resource": res, "verb": verb.upper()}
    if body:
        attrs["request_type"] = body
    ext.g.node(rid, M.HTTP_ROUTE, f"{verb.upper()} {path or res}",
               repo=rel.split("/", 1)[0], file=rel, line=line, attrs=attrs)
    ext.g.add_edge(svc, rid, M.EXPOSES, file=rel, line=line)
    if target:
        ext.g.add_edge(rid, nid("kt", target), "uses_resource", file=rel, line=line)
    if body:
        bt = ext._resolve(body.split("<")[0].rstrip("?"), kf, "")
        if bt:
            ext.g.add_edge(rid, nid("kt", bt), M.CARRIES, file=rel, line=line,
                           attrs={"direction": "request"})
    ext.stats["resource_routes"] += 1


def _enclosing_route(text: str, offset: int) -> str:
    """Nearest preceding `route("...") {` whose block still encloses `offset`."""
    best = ""
    for m in _ROUTE_BLOCK.finditer(text, 0, offset):
        depth = 0
        for ch in text[m.end() - 1: offset]:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth <= 0:
                    break
        else:
            best = m.group(1)
    return best


def _service_of(ext, repo: str) -> str:
    for e in ext.g.out_edges(nid(M.REPO, repo), "runs_as"):
        return e.dst
    return nid(M.REPO, repo)


def link_route_handlers(ext) -> None:
    """`serves` edges from a route to the symbols its handler body invokes.

    Without these, `explain` can never name an HTTP entry point — the walk climbs
    calls/injects and route nodes point only at their `@Resource`.
    """
    for rel, kf in ext.kt_files.items():
        if "/routes/" not in rel and not rel.endswith("Routes.kt"):
            continue
        if any(rel.endswith(sk) for sk in _SKIP_ROUTE_FILES):
            continue
        try:
            text = (ext.root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        repo = rel.split("/", 1)[0]
        # The RoutesDependencies data class is the symbol table for `with(deps) { }`.
        # It usually lives in its OWN file next to the routes, so resolve it by name
        # rather than only looking in this file.
        deps: dict[str, str] = {}
        for d in kf.decls:
            if d.name.endswith("RoutesDependencies"):
                for p_ in d.ctor_params:
                    if p_.name and p_.type:
                        deps[p_.name] = p_.type
        if not deps:
            for fn in kf.top_functions:
                for p_ in fn.params:
                    t = (p_.type or "").split("<")[0]
                    if not t.endswith("RoutesDependencies"):
                        continue
                    dep_fqn = ext._resolve(t, kf, "")
                    dep_decl = ext.decl_by_fqn.get(dep_fqn) if dep_fqn else None
                    if dep_decl:
                        for dp in dep_decl.ctor_params:
                            if dp.name and dp.type:
                                deps[dp.name] = dp.type
        if not deps:
            continue
        routes = [n for n in ext.g.by_kind(M.HTTP_ROUTE)
                  if n.file == rel and n.attrs.get("path")]
        if not routes:
            continue
        routes.sort(key=lambda n: n.line)
        lines = text.split("\n")
        for idx, route in enumerate(routes):
            end = routes[idx + 1].line if idx + 1 < len(routes) else len(lines)
            body = "\n".join(lines[route.line - 1: end])
            for cm in re.finditer(r"\b([a-z][A-Za-z0-9]*)\s*\(", body):
                nm = cm.group(1)
                if nm not in deps:
                    continue
                tgt = ext._resolve(deps[nm].split("<")[0], kf, "")
                if tgt:
                    ext.g.add_edge(route.id, nid("kt", tgt), "serves",
                                   file=rel, line=route.line)
                    ext.stats["route_serves_edges"] += 1
        del repo


def _link_zod_imports(ext) -> None:
    """`@ZodImport("AccountPlatform", "controlresell-connector")` is an explicit,
    machine-readable declaration that this module's contract depends on another's."""
    for rel, kf in ext.kt_files.items():
        if "-commons" not in rel and "-api" not in rel:
            continue
        try:
            text = (ext.root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if "@ZodImport" not in text:
            continue
        repo = rel.split("/", 1)[0]
        for m in _ZOD_IMPORT.finditer(text):
            type_name, pkg = m.group(1), m.group(2)
            line = text.count("\n", 0, m.start()) + 1
            pkg_id = nid(M.NPM, pkg)
            ext.g.node(pkg_id, M.NPM, pkg)
            src = nid(M.REPO, repo)
            for d in kf.decls:
                if d.line >= line:
                    src = nid("kt", d.fqn)
                    break
            ext.g.add_edge(src, pkg_id, M.DEPENDS_ON, file=rel, line=line,
                           attrs={"via": "ZodImport", "type": type_name})
            tgt = ext._resolve(type_name, kf, "")
            if tgt:
                ext.g.add_edge(src, nid("kt", tgt), M.REFERENCES, file=rel, line=line,
                               attrs={"via": "ZodImport", "npm": pkg})
            ext.stats["zod_import_edges"] += 1
