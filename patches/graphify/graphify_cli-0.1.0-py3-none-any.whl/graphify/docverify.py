"""Check the CLAUDE.md files against the code they describe.

Root CLAUDE.md section 14 requires these docs to stay true, and nothing enforced it —
drift was found repeatedly (stale pins, wrong module lists, a locale count off by six).

Built precision-first: only claim shapes that resolve reliably are checked, and a claim
that cannot be evaluated is reported as UNCHECKED rather than guessed at. A false drift
report costs more trust than a missed one.
"""
from __future__ import annotations

import re
from pathlib import Path

# Metasyntactic names that look exactly like symbols but describe a shape, not a type.
_PLACEHOLDERS = re.compile(
    r"^(?:I?Xxx|Xxx\w*|\w*Xxx\w*|Foo\w*|Bar\w*|MyApp|SomeThing)$")

_CODE_SPAN = re.compile(r"`([^`\n]{2,120})`")
_FENCE = re.compile(r"^\s*```")
_FILE_PATH = re.compile(
    r"^[\w\-./@{}*]+\.(?:kt|kts|ts|tsx|py|toml|yml|yaml|json|properties|ftl|css|sql|md)"
    r"(?::\d+(?:-\d+)?)?$")
_ROUTING_KEY = re.compile(r"^[a-z]+(?:\.[a-z*_]+){1,4}$")
_SYMBOL = re.compile(r"^([A-Z][A-Za-z0-9]{3,})(?:Impl)?(?:\.[A-Za-z_]\w*)*(?:\(\))?$")
_GRADLE_MODULE = re.compile(r"^:[a-z][a-z0-9-]*$")
# "There is no X" / "no Y exists" — an absence claim inverts the check, so skip it.
# Trailing tokens that make a dotted span a filename or a package, not a routing key.
_NOT_KEYS = {"conf", "kt", "kts", "ts", "tsx", "py", "json", "yml", "yaml", "toml",
             "md", "properties", "ftl", "css", "sql", "gradle", "xml", "env", "sh"}
# Cardinality claims. Deliberately a CLOSED whitelist: a stated integer is only
# checkable when the counting rule is unambiguous. "~25 route groups" has three
# defensible answers, so it is not here and never will be.
# `modules` and `repos` are deliberately absent: "478 issues across 4 modules" counts
# modules WITH debt, and "from >=3 repos" is a threshold. Both read as totals and are
# not. Only nouns whose count cannot plausibly be scoped stay here.
_CARDINALITY = re.compile(
    r"(?i)\b(?:exactly\s+|only\s+|all\s+)?(\d{1,4})\s+"
    r"(routing keys|entries|tables|locales)\b")
# Anything making the number a range, estimate, threshold or historical statement.
_APPROX = re.compile(r"(?i)(~|≈|≥|≤|>=|<=|\+\s*$|approx|about|around|roughly|up to|"
                     r"at least|at most|as of|used to|previously|was |formerly|"
                     r"across|among|out of|of the|issues)")

_NEGATIVE = re.compile(r"(?i)\b(there is no|there are no|no longer|never|not in|"
                       r"does not|doesn't|isn't|aren't|no \w+ table)\b")


def _lines_outside_fences(text: str):
    infence = False
    for i, line in enumerate(text.split("\n"), 1):
        if _FENCE.match(line):
            infence = not infence
            continue
        if not infence:
            yield i, line


_SEMVER = re.compile(r"^\^?(\d+\.\d+\.\d+)$")
_ARTIFACT_CELL = re.compile(r"`([a-z][a-z0-9-]*)`")


def check_pin_table(root: Path, graph, doc: Path) -> list[dict]:
    """Version pins written into a markdown table, checked against the catalogues.

    This is where drift concentrates: the table is hand-maintained and every consumer
    bumps independently, so a snapshot goes stale the moment anyone upgrades.
    """
    out: list[dict] = []
    try:
        lines = doc.read_text(encoding="utf-8", errors="replace").split("\n")
    except OSError:
        return out
    # actual pins: repo -> artifact -> version, from the dependency edges
    actual: dict[str, dict[str, str]] = {}
    for e in graph.edges:
        if e.kind != "depends_on" or not e.attrs.get("version"):
            continue
        s_, d_ = graph.nodes.get(e.src), graph.nodes.get(e.dst)
        if s_ and d_ and d_.kind == "artifact" and s_.repo:
            actual.setdefault(s_.repo, {})[d_.name] = e.attrs["version"]
    if not actual:
        return out

    # npm pins live in the same table but resolve against package.json, not a catalogue
    npm_actual: dict[str, str] = {}
    pj = root / "controlresell-app" / "package.json"
    if pj.exists():
        try:
            import json as _json
            data = _json.loads(pj.read_text(encoding="utf-8", errors="replace"))
            for scope in ("dependencies", "devDependencies"):
                for k, v in (data.get(scope) or {}).items():
                    if k.startswith("controlresell"):
                        npm_actual[k] = v
        except Exception:
            pass

    header: list[str] = []
    rel = str(doc.relative_to(root)) if doc.is_relative_to(root) else str(doc)
    for i, line in enumerate(lines, 1):
        if not line.strip().startswith("|"):
            header = []
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if all(set(c) <= set("-: ") for c in cells if c):
            continue                      # markdown separator row, not a header

        repo_cell0 = cells[0].strip("`* ")
        if npm_actual and repo_cell0.lower().startswith("app"):
            for cell in cells[1:]:
                pkg = re.search(r"`(controlresell[a-z-]*)`", cell)
                ver = re.search(r"\^?(\d+\.\d+\.\d+)", cell)
                if not pkg or not ver:
                    continue
                real = npm_actual.get(pkg.group(1), "")
                real_v = re.sub(r"^\^", "", real)
                out.append({"doc": rel, "line": i, "kind": "version_pin",
                            "claim": f"app pins {pkg.group(1)} {ver.group(1)}",
                            "status": "ok" if ver.group(1) == real_v else "drift",
                            "detail": "" if ver.group(1) == real_v
                            else f"package.json says {real}, doc says ^{ver.group(1)}"})
            continue
        if not any(_SEMVER.match(c.strip("`")) for c in cells):
            # Only accept a row as the header if the NEXT line is a separator; any
            # other prose row would otherwise silently become the column names.
            nxt = lines[i] if i < len(lines) else ""
            if (len(cells) > 2 and nxt.strip().startswith("|")
                    and set(nxt.strip()) <= set("|-: ")):
                header = cells
            continue
        if not header:
            continue
        repo_cell = cells[0].strip("`* ")
        # `(v2.25.0+)` states a MINIMUM, not an exact version — 2.25.1 satisfies it.
        own = re.search(r"\(v(\d+\.\d+\.\d+)(\+?)", repo_cell)
        if own and own.group(2) == "+":
            own = None
        if own:
            name = repo_cell.split(" ")[0]
            node = next((n for n in graph.nodes.values()
                         if n.kind == "repo"
                         and (n.name == name
                              or n.name.replace("controlresell-", "") == name)), None)
            real = (node.attrs.get("version") or "") if node else ""
            if real:
                out.append({"doc": rel, "line": i, "kind": "version_pin",
                            "claim": f"{name} is at v{own.group(1)}",
                            "status": "ok" if own.group(1) == real else "drift",
                            "detail": "" if own.group(1) == real
                            else f"build.gradle.kts says {real}, doc says {own.group(1)}"})
        repo = next((r for r in actual
                     if r.endswith(repo_cell) or repo_cell.startswith(r)
                     or r.replace("controlresell-", "") == repo_cell.split(" ")[0]), None)
        if repo is None:
            continue
        for col, cell in enumerate(cells[1:], 1):
            v = _SEMVER.match(cell.strip("`* "))
            if not v or col >= len(header):
                continue
            art_hint = header[col].strip("`* ").lower()
            match = next((a for a in actual[repo]
                          if a == art_hint or a.startswith(art_hint)
                          or art_hint.startswith(a.split("-")[0])), None)
            if match is None:
                continue
            claimed, real = v.group(1), actual[repo][match]
            out.append({"doc": rel, "line": i, "kind": "version_pin",
                        "claim": f"{repo_cell} pins {match} {claimed}",
                        "status": "ok" if claimed == real else "drift",
                        "detail": "" if claimed == real
                        else f"catalogue says {real}, doc says {claimed}"})
    return out


def check_docs(root: Path, graph, routing_keys: set[str],
               file_index: dict[str, set[str]]) -> list[dict]:
    """One record per checked claim. status: ok | drift | unchecked."""
    out: list[dict] = []
    names = {n.name for n in graph.nodes.values()}
    names |= {n.name.replace("Impl", "") for n in graph.nodes.values()}
    enum_members = {n.name: set(n.attrs.get("entries", []))
                    for n in graph.nodes.values()
                    if n.kind == "enum" and n.attrs.get("entries")}

    for doc in sorted(root.glob("*/CLAUDE.md")) + [root / "CLAUDE.md"]:
        if not doc.exists():
            continue
        rel_doc = str(doc.relative_to(root))
        repo = rel_doc.split("/")[0] if "/" in rel_doc else ""
        try:
            text = doc.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        out.extend(check_pin_table(root, graph, doc))
        out.extend(_check_cardinality(root, graph, doc, rel_doc, repo, text))
        for line_no, line in _lines_outside_fences(text):
            for span in _CODE_SPAN.findall(line):
                # Scope the negation guard to the span's own clause, not the whole
                # line: one "never" in a long bullet must not discard the rest.
                at = line.find("`" + span + "`")
                clause = line[max(0, at - 90): at + len(span) + 20] if at >= 0 else line
                if _NEGATIVE.search(clause):
                    continue
                span = span.strip()
                rec = {"doc": rel_doc, "line": line_no, "claim": span}

                if _FILE_PATH.match(span):
                    path = span.split(":")[0]
                    # A bare filename is rarely a claim that THAT file exists. In these
                    # docs it is usually a naming convention ("interface in `Foo.kt`,
                    # impl in `FooImpl.kt`"), a property (`Serialization.json`), or a
                    # file in another repo ("see `integration-sumup.md` (meta repo)").
                    # Only a path carrying a directory is specific enough to check.
                    if "/" not in path:
                        out.append({**rec, "kind": "file", "status": "unchecked",
                                    "detail": "bare filename — illustrative, or in "
                                              "another repo"})
                        continue
                    if "..." in path or re.search(r"(?i)\bxxx\b|\{|\*", path):
                        # an elided or metasyntactic path describes a shape, not a file
                        out.append({**rec, "kind": "file", "status": "unchecked",
                                    "detail": "elided or placeholder path"})
                        continue
                    hit = _resolve_path(root, repo, path, file_index)
                    out.append({**rec, "kind": "file",
                                "status": "ok" if hit else "drift",
                                "detail": "" if hit else "no such file in the workspace"})
                    continue

                if (_ROUTING_KEY.match(span) and "*" not in span
                        and not _FILE_PATH.match(span)
                        and not span.split(".")[-1] in _NOT_KEYS):
                    if "." in span and span.split(".")[0] in (
                            "platforms", "vision", "inventory", "notifications",
                            "subscriptions", "vms", "discord", "preferences",
                            "application"):
                        ok = span in routing_keys
                        out.append({**rec, "kind": "routing_key",
                                    "status": "ok" if ok else "drift",
                                    "detail": "" if ok else
                                    "not a RoutingKey enum value"})
                    continue

                if _GRADLE_MODULE.match(span):
                    mod = span.lstrip(":")
                    ok = any(n.kind == "module" and n.name == mod
                             and (not repo or n.repo == repo)
                             for n in graph.nodes.values())
                    out.append({**rec, "kind": "module",
                                "status": "ok" if ok else "unchecked",
                                "detail": "" if ok else
                                "no such gradle module in that repo"})
                    continue

                m = _SYMBOL.match(span)
                if m and not _PLACEHOLDERS.match(m.group(1)):
                    base = m.group(1)
                    parts = span.replace("()", "").split(".")
                    root_name = parts[0]
                    ok = (root_name in names or base in names
                          or f"{root_name}Impl" in names)
                    detail = "" if ok else "no declaration with this name"
                    # `Enum.MEMBER` must validate the MEMBER too: checking only the
                    # container passes a claim about a constant that does not exist.
                    if ok and len(parts) == 2 and parts[1].isupper():
                        entries = enum_members.get(root_name)
                        if entries is not None and parts[1] not in entries:
                            ok = False
                            detail = (f"{root_name} has no member {parts[1]} "
                                      f"({len(entries)} members)")
                            behind = _behind_origin(root, _repo_of_symbol(graph, root_name))
                            if behind:
                                detail += (f" — but {behind} is behind origin/main, so "
                                           "this may be a stale checkout, not doc drift")
                            out.append({**rec, "kind": "enum_member",
                                        "status": "stale_checkout" if behind else "drift",
                                        "detail": detail})
                            continue
                    out.append({**rec, "kind": "symbol",
                                "status": "ok" if ok else "unchecked",
                                "detail": detail})
    return out


def _check_cardinality(root: Path, graph, doc: Path, rel: str, repo: str,
                       text: str) -> list[dict]:
    """A stated integer against a count the graph can produce exactly."""
    out: list[dict] = []

    def count(kind: str, in_repo: str = "") -> int:
        return sum(1 for n in graph.nodes.values()
                   if n.kind == kind and (not in_repo or n.repo == in_repo))

    for line_no, line in _lines_outside_fences(text):
        if _NEGATIVE.search(line) or _APPROX.search(line):
            continue
        for m in _CARDINALITY.finditer(line):
            claimed, noun = int(m.group(1)), m.group(2).lower()
            ctx = line.lower()
            actual = None
            what = ""
            if noun in ("routing keys",) or (noun == "entries" and "routingkey" in
                                             ctx.replace(" ", "")):
                actual, what = count("routing_key"), "RoutingKey entries"
            elif noun == "tables" and repo:
                # Only in a per-repo doc: in the root doc "N tables" is workspace-wide
                # or scoped to a subsystem, and the counting rule is not stated.
                actual, what = count("table", repo), f"Exposed tables in {repo}"
            elif noun == "locales":
                loc = root / "controlresell-app/packages/common/src/locales"
                if loc.is_dir():
                    actual = sum(1 for d in loc.iterdir() if d.is_dir())
                    what = "locale directories"
            if actual is None:
                continue
            out.append({"doc": rel, "line": line_no, "kind": "cardinality",
                        "claim": f"{claimed} {noun}",
                        "status": "ok" if claimed == actual else "drift",
                        "detail": "" if claimed == actual
                        else f"{what}: actually {actual}, doc says {claimed}"})
    return out


def _repo_of_symbol(graph, name: str) -> str:
    for n in graph.nodes.values():
        if n.name == name and n.repo:
            return n.repo
    return ""


_BEHIND_CACHE: dict[str, str] = {}


def _behind_origin(root: Path, repo: str) -> str:
    """Repo name if its checkout is behind origin, else "".

    A symbol the docs cite but the working tree lacks is usually a stale clone, not a
    wrong document — and telling someone to edit the doc would be the wrong advice.
    """
    if not repo:
        return ""
    if repo in _BEHIND_CACHE:
        return _BEHIND_CACHE[repo]
    import subprocess
    try:
        out = subprocess.run(["git", "-C", str(root / repo), "status", "-sb"],
                             capture_output=True, text=True, timeout=8).stdout
        _BEHIND_CACHE[repo] = repo if "behind" in out.split("\n")[0] else ""
    except Exception:
        _BEHIND_CACHE[repo] = ""
    return _BEHIND_CACHE[repo]


def _resolve_path(root: Path, repo: str, path: str,
                  file_index: dict[str, set[str]]) -> bool:
    if repo and (root / repo / path).exists():
        return True
    if (root / path).exists():
        return True
    base = path.rsplit("/", 1)[-1]
    for cand in file_index.get(base, ()):
        if cand.endswith(path):
            return True
    return bool(file_index.get(base)) and "/" not in path


def build_file_index(root: Path) -> dict[str, set[str]]:
    """basename -> set of workspace-relative paths, for suffix resolution."""
    from .workspace import walk_files, KOTLIN_EXT, TS_EXT, PY_EXT
    idx: dict[str, set[str]] = {}
    # Resources count: the docs reference .properties, .css and .ftl files, and an
    # unindexed extension reads as a missing file.
    exts = set(KOTLIN_EXT) | set(TS_EXT) | set(PY_EXT) | {
        ".toml", ".kts", ".yaml", ".yml", ".json", ".md", ".properties", ".css",
        ".ftl", ".html", ".sql", ".conf", ".xml", ".sh", ".env"}
    for f in walk_files(root, exts):
        try:
            rel = str(f.relative_to(root))
        except ValueError:
            continue
        idx.setdefault(f.name, set()).add(rel)
    return idx
