"""TypeScript / TSX structural extraction via tree-sitter.

Scoped to what makes cross-boundary edges visible: imports (especially from the
generated `controlresell*` npm packages), class and interface declarations,
exported symbols, and call sites. It is intentionally lighter than the Kotlin
extractor -- the app consumes contracts, it does not define them.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import tree_sitter_typescript as tst
from tree_sitter import Language, Parser

_TS = Language(tst.language_typescript())
_TSX = Language(tst.language_tsx())


def new_parsers() -> tuple[Parser, Parser]:
    return Parser(_TS), Parser(_TSX)


@dataclass
class TsImport:
    source: str                       # module specifier
    names: list[str] = field(default_factory=list)
    default_name: str = ""
    namespace: str = ""
    line: int = 0
    type_only: bool = False


@dataclass
class TsDecl:
    name: str
    kind: str                         # class | interface | type | enum | function | const
    line: int
    extends: list[str] = field(default_factory=list)
    implements: list[str] = field(default_factory=list)
    exported: bool = False
    methods: list[str] = field(default_factory=list)


@dataclass
class TsFile:
    path: str
    imports: list[TsImport] = field(default_factory=list)
    decls: list[TsDecl] = field(default_factory=list)
    calls: list[tuple[str, str, int]] = field(default_factory=list)  # receiver, callee, line
    string_literals: list[tuple[str, int]] = field(default_factory=list)
    parse_errors: int = 0


def _txt(src: bytes, n) -> str:
    return src[n.start_byte:n.end_byte].decode("utf8", "replace")


def _child(n, *types):
    for c in n.children:
        if c.type in types:
            return c
    return None


def _field(n, name):
    return n.child_by_field_name(name)


def _walk(root):
    stack = [root]
    while stack:
        n = stack.pop()
        yield n
        stack.extend(n.children)


def parse_typescript(path: str, src: bytes,
                     parser: Parser | None = None, tsx: bool = False) -> TsFile:
    parser = parser or Parser(_TSX if tsx else _TS)
    tree = parser.parse(src)
    tf = TsFile(path=path)

    for n in _walk(tree.root_node):
        t = n.type
        if t == "ERROR" or n.is_missing:
            tf.parse_errors += 1

        elif t == "import_statement":
            srcn = _field(n, "source")
            imp = TsImport(source=_txt(src, srcn).strip("'\"`") if srcn else "",
                           line=n.start_point[0] + 1,
                           type_only="import type" in _txt(src, n)[:12])
            for c in _walk(n):
                if c.type == "import_specifier":
                    nm = _field(c, "name")
                    alias = _field(c, "alias")
                    if nm is not None:
                        imp.names.append(_txt(src, alias or nm))
                elif c.type == "namespace_import":
                    ident = _child(c, "identifier")
                    if ident is not None:
                        imp.namespace = _txt(src, ident)
            clause = _child(n, "import_clause")
            if clause is not None:
                first = clause.children[0] if clause.children else None
                if first is not None and first.type == "identifier":
                    imp.default_name = _txt(src, first)
            if imp.source:
                tf.imports.append(imp)

        elif t in ("class_declaration", "abstract_class_declaration"):
            nm = _field(n, "name")
            d = TsDecl(name=_txt(src, nm) if nm else "", kind="class",
                       line=n.start_point[0] + 1,
                       exported=n.parent is not None and n.parent.type == "export_statement")
            heritage = _child(n, "class_heritage")
            if heritage is not None:
                for c in heritage.children:
                    if c.type == "extends_clause":
                        for v in c.children:
                            if v.type in ("identifier", "generic_type", "member_expression"):
                                d.extends.append(_txt(src, v).split("<")[0])
                    elif c.type == "implements_clause":
                        for v in c.children:
                            if v.type in ("type_identifier", "generic_type", "identifier"):
                                d.implements.append(_txt(src, v).split("<")[0])
            body = _field(n, "body")
            if body is not None:
                for m in body.children:
                    if m.type in ("method_definition", "method_signature"):
                        mn = _field(m, "name")
                        if mn is not None:
                            d.methods.append(_txt(src, mn))
            if d.name:
                tf.decls.append(d)

        elif t == "interface_declaration":
            nm = _field(n, "name")
            d = TsDecl(name=_txt(src, nm) if nm else "", kind="interface",
                       line=n.start_point[0] + 1,
                       exported=n.parent is not None and n.parent.type == "export_statement")
            ext = _child(n, "extends_type_clause", "extends_clause")
            if ext is not None:
                for v in ext.children:
                    if v.type in ("type_identifier", "generic_type"):
                        d.extends.append(_txt(src, v).split("<")[0])
            body = _field(n, "body")
            if body is not None:
                for m in body.children:
                    if m.type == "method_signature":
                        mn = _field(m, "name")
                        if mn is not None:
                            d.methods.append(_txt(src, mn))
            if d.name:
                tf.decls.append(d)

        elif t == "type_alias_declaration":
            nm = _field(n, "name")
            if nm is not None:
                tf.decls.append(TsDecl(name=_txt(src, nm), kind="type",
                                       line=n.start_point[0] + 1))

        elif t == "enum_declaration":
            nm = _field(n, "name")
            if nm is not None:
                tf.decls.append(TsDecl(name=_txt(src, nm), kind="enum",
                                       line=n.start_point[0] + 1))

        elif t == "function_declaration":
            nm = _field(n, "name")
            if nm is not None:
                tf.decls.append(TsDecl(name=_txt(src, nm), kind="function",
                                       line=n.start_point[0] + 1))

        elif t == "call_expression":
            fn = _field(n, "function")
            if fn is not None:
                full = _txt(src, fn)
                if len(full) < 160:
                    recv, callee = ("", full)
                    if fn.type == "member_expression":
                        obj, prop = _field(fn, "object"), _field(fn, "property")
                        if obj is not None and prop is not None:
                            recv, callee = _txt(src, obj), _txt(src, prop)
                    tf.calls.append((" ".join(recv.split()),
                                     " ".join(callee.split()), n.start_point[0] + 1))

        elif t == "string" and n.parent is not None and n.parent.type != "import_statement":
            s = _txt(src, n).strip("'\"`")
            if 3 <= len(s) <= 90:
                tf.string_literals.append((s, n.start_point[0] + 1))

    return tf
