"""Where a domain status is written.

Deliberately NOT a transition graph. Measurement showed only about half of writes have
a statically determinable from-state, so a from/to graph would be half-invented. What
is solid is the write site itself: "where does an order become SHIPPED" is answerable
exactly, and that is the question people actually ask.

Enums that merely classify a thing (AccountPlatform, PreferenceType, UserLimitType) are
excluded: nothing transitions through them and pretending otherwise invents structure.
"""
from __future__ import annotations

import re

from . import model as M
from .extract import nid

# A thing moves through these. Anything else is a label, not a state.
CLASSIFICATION = {
    "AccountPlatform", "PreferenceType", "UserLimitType", "OrderType", "JobOrderType",
    "ItemHistoryType", "RoutingKey", "Service", "Environment", "FailReason",
    "ConversationMessagePreferenceType", "PreferenceActionPayloadType",
}
_STATUS_NAME = re.compile(r"(Status|State|Phase)$")

# `Update*Payload(status = Enum.LIT)` is the dominant write; the argument is often on
# its own line, so every pattern here must tolerate a newline after the `=`.
# Any PascalCase constructor, not only `*Payload`: the most consequential write in the
# wholesale schema is `Order(status = OrderStatus.PAID)`, a plain entity constructor.
_PAYLOAD_WRITE = re.compile(
    r"\b([A-Z][A-Za-z0-9]*)\s*\((?:[^()]|\([^()]*\))*?"
    r"\b(status|state|recoveryPhase)\s*=\s*([A-Za-z_][\w.]*)", re.S)
_COPY_WRITE = re.compile(
    r"\.copy\s*\((?:[^()]|\([^()]*\))*?\b(status|state)\s*=\s*([A-Za-z_][\w.]*)", re.S)
_SETTER = re.compile(
    r"\b(update|set|mark|advance|transition)[A-Za-z]*(?:Status|State|Phase)\s*\(")
_OPAQUE = re.compile(r"\bit\[\s*[\w.]*\b(status|state|recoveryPhase)\s*\]\s*=")
# `val status = if (cond) LotStatus.SOLD_OUT else lot.status` — the literal sits on a
# local val that is written to the column a few lines later. Common enough to matter.
_LOCAL_VAL = re.compile(r"\bval\s+(status|state|newStatus|nextStatus)\s*=\s*")


def link_statuses(ext) -> None:
    enums = _status_enums(ext)
    if not enums:
        return
    members = {f"{e}.{m}" for e, ms in enums.items() for m in ms}
    for rel, kf in ext.kt_files.items():
        try:
            text = (ext.root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if not any(e in text for e in enums):
            continue
        repo = rel.split("/", 1)[0]
        for m in _PAYLOAD_WRITE.finditer(text):
            _emit(ext, kf, rel, repo, text, m.start(), m.group(3), members, enums,
                  kind="create" if m.group(1).startswith(("Create", "New")) else "update",
                  via=m.group(1))
        for m in _COPY_WRITE.finditer(text):
            _emit(ext, kf, rel, repo, text, m.start(), m.group(2), members, enums,
                  kind="copy", via=".copy")
        for m in _LOCAL_VAL.finditer(text):
            _emit(ext, kf, rel, repo, text, m.end(), "", members, enums,
                  kind="local", via=f"val {m.group(1)}")
        for m in _OPAQUE.finditer(text):
            line = text.count("\n", 0, m.start()) + 1
            ext.stats["status_opaque_writes"] += 1
            del line


def _status_enums(ext) -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for fqn, d in ext.decl_by_fqn.items():
        if d.kind != "enum" or d.name in CLASSIFICATION:
            continue
        if not _STATUS_NAME.search(d.name):
            continue
        entries = [e[0] for e in d.enum_entries]
        if len(entries) >= 2:
            out[d.name] = entries
    return out


def _argument_extent(text: str, offset: int, cap: int = 600) -> str:
    """From the `status =` match to the end of that argument.

    Stops at a comma or closing paren at depth 0, so a conditional
    (`status = if (x) A else B`) keeps both branches and nothing else.
    """
    depth = 0
    for j in range(offset, min(len(text), offset + cap)):
        ch = text[j]
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            if depth == 0:
                return text[offset:j]
            depth -= 1
        elif ch == "," and depth == 0:
            return text[offset:j]
        elif ch == "\n" and depth == 0 and j > offset + 2:
            return text[offset:j]
    return text[offset: offset + cap]


def _emit(ext, kf, rel, repo, text, offset, value, members, enums, kind, via) -> None:
    """Record one write. The value may be an if/when, so collect every literal in it."""
    line = text.count("\n", 0, offset) + 1
    window = _argument_extent(text, offset)
    head = window.lstrip()
    if value in members:
        # `status = OrderStatus.PAID` — the literal is right here.
        lits = [value]
    elif head.startswith(("if", "when")):
        # A conditional value genuinely has several outcomes; take all its branches.
        lits = [v for v in re.findall(
            r"\b([A-Z][A-Za-z0-9]*\.[A-Z][A-Z0-9_]*)\b", window) if v in members]
    else:
        # `status = to` — the literal is not here. Looking for one nearby invents it.
        ext.stats["status_opaque_writes"] += 1
        return
    if not lits:
        return
    owner = ""
    for d in kf.decls:
        if d.line <= line <= (d.end_line or d.line):
            owner = d.fqn
    for lit in dict.fromkeys(lits):
        enum_name, member = lit.split(".", 1)
        sid = nid("status", f"{enum_name}.{member}")
        ext.g.node(sid, "status", lit, repo="", attrs={"enum": enum_name,
                                                       "member": member})
        src = nid("kt", owner) if owner and nid("kt", owner) in ext.g.nodes else \
            nid(M.REPO, repo)
        ext.g.add_edge(src, sid, "sets_status", file=rel, line=line,
                       attrs={"kind": kind, "via": via,
                              **({"initial": True} if kind == "create" else {})})
        ext.stats["status_writes"] += 1
