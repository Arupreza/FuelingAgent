"""Staleness detection and the parse cache.

A stale graph is the tool's worst failure mode: it answers confidently and wrongly,
and nothing about the answer looks off. So every query pays ~80ms to stat the source
tree and compare a fingerprint, and the same walk yields the changed-file list that
makes an incremental rebuild cheap.
"""
from __future__ import annotations

import hashlib
import json
import pickle
from pathlib import Path

from .workspace import KOTLIN_EXT, PY_EXT, TS_EXT, walk_files

def _stamp(p: Path) -> tuple[int, int]:
    st = p.stat()
    return st.st_mtime_ns, st.st_size


def scan(root: Path) -> dict[str, tuple[int, int]]:
    """path -> (mtime_ns, size) for every input the graph is derived from."""
    out: dict[str, tuple[int, int]] = {}
    for ext in (KOTLIN_EXT, TS_EXT, PY_EXT):
        for f in walk_files(root, ext):
            try:
                out[str(f.relative_to(root))] = _stamp(f)
            except OSError:
                pass
    # The doc layer reads CLAUDE.md, the cron layer reads Helm templates, and the
    # legacy-route layer reads CI workflows. A fingerprint that ignores them lets an
    # edit to those go unnoticed while the tool answers from a stale index.
    for extra in ("CLAUDE.md",):
        f = root / extra
        if f.exists():
            try:
                out[str(f.relative_to(root))] = _stamp(f)
            except OSError:
                pass
    for pat in ("*/CLAUDE.md", "*/helm/*/values.yaml",
                "*/helm/*/templates/jobs/*.yaml"):
        for f in root.glob(pat):
            try:
                out[str(f.relative_to(root))] = _stamp(f)
            except OSError:
                pass

    for repo in root.iterdir():
        if not repo.is_dir() or repo.name.startswith("."):
            continue
        for pat in ("gradle/libs.versions.toml", "package.json",
                    "settings.gradle.kts", "build.gradle.kts"):
            f = repo / pat
            if f.exists():
                try:
                    out[str(f.relative_to(root))] = _stamp(f)
                except OSError:
                    pass
        for f in repo.glob("*/build.gradle.kts"):
            try:
                out[str(f.relative_to(root))] = _stamp(f)
            except OSError:
                pass
    return out


def digest(stamps: dict[str, tuple[int, int]]) -> str:
    h = hashlib.sha1()
    for path in sorted(stamps):
        m, s = stamps[path]
        h.update(f"{path}:{m}:{s}\n".encode())
    return h.hexdigest()[:16]


def diff(old: dict, new: dict) -> tuple[list[str], list[str], list[str]]:
    """(added, modified, removed) — mtime+size, not content hashing.

    A content hash would be stricter, but hashing 21MB on every query costs more
    than the mistake it would catch: an edit that preserves both mtime and size.
    """
    added = [p for p in new if p not in old]
    removed = [p for p in old if p not in new]
    modified = [p for p in new if p in old and tuple(old[p]) != tuple(new[p])]
    return added, modified, removed


class Manifest:
    def __init__(self, path: Path):
        self.path = path

    def load(self) -> dict:
        if not self.path.exists():
            return {}
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def save(self, stamps: dict, extra: dict | None = None) -> None:
        self.path.write_text(json.dumps({
            "digest": digest(stamps),
            "files": {k: list(v) for k, v in stamps.items()},
            **(extra or {}),
        }, separators=(",", ":")), encoding="utf-8")

    def status(self, root: Path) -> dict:
        """Compare the tree against the manifest without rebuilding anything."""
        prev = self.load()
        if not prev:
            return {"state": "missing", "added": [], "modified": [], "removed": []}
        now = scan(root)
        if digest(now) == prev.get("digest"):
            return {"state": "fresh", "added": [], "modified": [], "removed": [],
                    "stamps": now}
        old = {k: tuple(v) for k, v in (prev.get("files") or {}).items()}
        a, m, r = diff(old, now)
        return {"state": "stale", "added": a, "modified": m, "removed": r,
                "stamps": now}


def parser_version() -> str:
    """Fingerprint of the parser code itself.

    A cache keyed only on file content survives a change to the parsers, and then
    replays objects that predate a new field — which fails at attribute access, far
    from the cause. Keying on the parser source too makes that impossible.
    """
    h = hashlib.sha1()
    here = Path(__file__).parent
    for f in sorted((here / "parsers").glob("*.py")):
        try:
            h.update(f.read_bytes())
        except OSError:
            pass
    return h.hexdigest()[:12]


class ParseCache:
    """Parsed files, keyed by path+stamp+parser version. Parsing is ~85% of build."""

    def __init__(self, path: Path):
        self.path = path
        self.data: dict[str, tuple[tuple[int, int], object]] = {}
        self.version = parser_version()

    def load(self) -> None:
        if not self.path.exists():
            return
        try:
            with open(self.path, "rb") as fh:
                blob = pickle.load(fh)
            if isinstance(blob, dict) and blob.get("__version__") == self.version:
                self.data = blob.get("files", {})
            else:
                self.data = {}      # parsers changed; every entry is suspect
        except Exception:
            self.data = {}

    def save(self) -> None:
        tmp = self.path.with_suffix(".tmp")
        with open(tmp, "wb") as fh:
            pickle.dump({"__version__": self.version, "files": self.data},
                        fh, protocol=5)
        tmp.replace(self.path)

    def get(self, rel: str, stamp: tuple[int, int]):
        hit = self.data.get(rel)
        if hit is not None and tuple(hit[0]) == tuple(stamp):
            return hit[1]
        return None

    def put(self, rel: str, stamp: tuple[int, int], parsed) -> None:
        self.data[rel] = (stamp, parsed)

    def prune(self, live: set[str]) -> None:
        for k in [k for k in self.data if k not in live]:
            del self.data[k]
