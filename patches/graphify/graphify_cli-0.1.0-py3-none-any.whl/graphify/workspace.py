"""Workspace discovery: repos, modules, services, and the file walk.

Nothing here is workspace-specific beyond the default exclude list -- repos and
modules are discovered from build files, not hardcoded, so a repo cloned into the
workspace tomorrow is picked up with no code change.
"""
from __future__ import annotations

import os
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

EXCLUDE_DIRS = {
    "build", "node_modules", ".git", ".gradle", ".idea", ".venv", "venv",
    "docker-data", "dist", "__pycache__", ".kotlin", ".expo", "out",
    "generated", ".next", "coverage", ".dart_tool", "Pods",
    # Eclipse/JDT output. A `bin/` can hold gitignored copies of a module's own
    # sources; parsing them duplicates declarations and invents edges.
    "bin",
}

KOTLIN_EXT = {".kt"}
TS_EXT = {".ts", ".tsx"}
PY_EXT = {".py"}


@dataclass
class Module:
    """A Gradle module or an npm workspace package."""
    repo: str
    name: str                       # gradle path without leading colon, or pkg name
    path: str                       # workspace-relative
    kind: str = "gradle"            # gradle | npm | python
    artifact: str = ""              # published maven coordinate name, if any
    npm_package: str = ""           # published npm package name, if any
    deps: list[str] = field(default_factory=list)          # raw dependency tokens
    project_deps: list[str] = field(default_factory=list)  # ":other-module"


@dataclass
class Repo:
    name: str
    path: str
    kinds: set[str] = field(default_factory=set)   # kotlin | ts | python | helm
    modules: dict[str, Module] = field(default_factory=dict)
    version: str = ""
    git_head: str = ""
    is_git: bool = False


def _prune(dirnames: list[str]) -> None:
    dirnames[:] = [d for d in dirnames
                   if d not in EXCLUDE_DIRS and d != ".git"
                   and not d.startswith(".git/")]


def walk_files(root: Path, exts: set[str], within: Path | None = None):
    """Yield source files under `root`, pruning build/vendor directories."""
    base = within or root
    for dirpath, dirnames, filenames in os.walk(base):
        _prune(dirnames)
        for fn in filenames:
            if os.path.splitext(fn)[1] in exts:
                yield Path(dirpath) / fn


_INCLUDE_RE = re.compile(r'include\s*\(\s*((?:"[^"]+"\s*,?\s*)+)\)', re.S)
_INCLUDE_ONE_RE = re.compile(r'"([^"]+)"')
_ROOT_VERSION_RE = re.compile(r'^\s*version\s*=\s*"([^"]+)"', re.M)


def _read(p: Path) -> str:
    try:
        return p.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def discover(root: Path) -> dict[str, Repo]:
    """Every immediate subdirectory that looks like a repo, plus its modules."""
    repos: dict[str, Repo] = {}
    for child in sorted(root.iterdir()):
        if not child.is_dir() or child.name in EXCLUDE_DIRS or child.name.startswith("."):
            continue
        marker = any((child / m).exists() for m in
                     ("settings.gradle.kts", "settings.gradle", "package.json",
                      "pyproject.toml", "build.gradle.kts", "Chart.yaml", ".git"))
        if not marker:
            continue
        repo = Repo(name=child.name, path=str(child.relative_to(root)))
        repo.is_git = (child / ".git").exists()
        if repo.is_git:
            try:
                repo.git_head = subprocess.run(
                    ["git", "-C", str(child), "rev-parse", "--short", "HEAD"],
                    capture_output=True, text=True, timeout=10).stdout.strip()
            except Exception:
                pass

        settings = child / "settings.gradle.kts"
        if settings.exists():
            repo.kinds.add("kotlin")
            txt = _read(settings)
            names: list[str] = []
            for blob in _INCLUDE_RE.findall(txt):
                names.extend(_INCLUDE_ONE_RE.findall(blob))
            for m in re.finditer(r'include\s*\(\s*"([^"]+)"\s*\)', txt):
                names.append(m.group(1))
            for raw in dict.fromkeys(names):
                mod_name = raw.lstrip(":")
                mod_path = child / mod_name.replace(":", "/")
                repo.modules[mod_name] = Module(
                    repo=repo.name, name=mod_name,
                    path=str(mod_path.relative_to(root)) if mod_path.exists() else "",
                    kind="gradle")
            rb = child / "build.gradle.kts"
            if rb.exists():
                m = _ROOT_VERSION_RE.search(_read(rb))
                if m:
                    repo.version = m.group(1)

        pkg = child / "package.json"
        if pkg.exists():
            repo.kinds.add("ts")
        if (child / "pyproject.toml").exists():
            repo.kinds.add("python")
        if list(child.glob("helm/*/Chart.yaml")) or (child / "Chart.yaml").exists():
            repo.kinds.add("helm")
        if not repo.kinds:
            # A docs-only repo still deserves a node.
            repo.kinds.add("docs")
        repos[repo.name] = repo
    return repos


def repo_of(rel_path: str) -> str:
    return rel_path.split("/", 1)[0] if "/" in rel_path else rel_path


def module_of(repo: Repo, rel_path: str) -> str:
    """Longest module path prefix that contains `rel_path`."""
    best, best_len = "", -1
    for m in repo.modules.values():
        if m.path and rel_path.startswith(m.path + "/") and len(m.path) > best_len:
            best, best_len = m.name, len(m.path)
    return best


def source_set(rel_path: str) -> str:
    """commonMain / jvmMain / jsMain / commonTest ... from a KMP path."""
    m = re.search(r"/src/([A-Za-z0-9]+)/", rel_path)
    return m.group(1) if m else ""


def is_test(rel_path: str) -> bool:
    ss = source_set(rel_path)
    return "test" in ss.lower() or "/test/" in rel_path or rel_path.endswith("Test.kt")
