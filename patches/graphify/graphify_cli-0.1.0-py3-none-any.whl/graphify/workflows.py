"""Workflow state machines — the layer root CLAUDE.md maintains by hand.

There is no state-machine framework here. A workflow advances by exactly three
mechanisms, and each has to be recognised separately:

  1. SYNCHRONOUS  — a `when(step)` branch calls the class's own `invoke(NextStep(...))`.
                    The call is unqualified, so it looks like a free function.
  2. ASYNCHRONOUS — the branch publishes a job and returns; the workflow re-enters
                    later from a message handler.
  3. RE-ENTRY     — a RoutingKey branch (or a job-response use case) constructs a step
                    and calls the workflow with it.

Nothing persists the step object itself; ItemHistory rows are the durable state.
"""
from __future__ import annotations

import re

from . import model as M
from .extract import nid

_SEALED_STEP = re.compile(r"^[A-Za-z]+WorkflowStep$")
_WHEN_ENTRY = re.compile(r"\bis\s+([A-Za-z]+WorkflowStep)\.([A-Za-z0-9_]+)\s*->")
# The recursive advance. Unqualified `invoke(` — a receiver means something else.
_SELF_INVOKE = re.compile(r"(?<![.\w])invoke\s*\(\s*([A-Za-z]+WorkflowStep)\.([A-Za-z0-9_]+)\s*\(")
_STEP_CTOR = re.compile(r"\b([A-Za-z]+WorkflowStep)\.([A-Za-z0-9_]+)\s*\(")
_BROKER_SEND = re.compile(r"\b(?:rabbitMQService|messageBroker|apiMessageBroker)\.(send[A-Za-z0-9]*)\s*\(")
_ARM_DELEGATE = re.compile(r"^(?:return\s+)?(handle[A-Za-z0-9_]*)\s*\(")
_PRIVATE_FN = r"private\s+suspend\s+fun\s+{name}\s*\("
_HISTORY_WRITE = re.compile(r"type\s*=\s*ItemHistoryType\.([A-Z][A-Z0-9_]*)")
_RK_BRANCH = re.compile(r"RoutingKey\.([A-Z][A-Z0-9_]*)\.key\s*->")


def _arm_body(text: str, arm_end: int, max_chars: int = 20000) -> str:
    """Body of a single `when` arm, correctly bounded.

    The naive approach -- find the next `{` after `->` -- silently steals the NEXT
    arm's block whenever this arm is a one-line delegation (`is X -> handleX(step)`),
    which shifts an entire workflow's edges by one. So: if a brace opens before any
    other token, brace-match it; otherwise stop at the next arm or the closing brace
    of the enclosing `when`.
    """
    i = arm_end
    while i < len(text) and text[i] in " \t":
        i += 1
    if i < len(text) and text[i] == "{":
        depth = 0
        for j in range(i, min(len(text), i + max_chars)):
            if text[j] == "{":
                depth += 1
            elif text[j] == "}":
                depth -= 1
                if depth == 0:
                    return text[arm_end: j + 1]
        return text[arm_end: arm_end + max_chars]
    # Expression arm: runs until the next arm at depth 0, or until the `when` closes.
    depth = 0
    for j in range(i, min(len(text), i + max_chars)):
        ch = text[j]
        if ch in "{([":
            depth += 1
        elif ch in "})]":
            depth -= 1
            if depth < 0:
                return text[arm_end: j]
        elif depth == 0 and text.startswith("is ", j) and _ARM_HEAD.match(text, j):
            return text[arm_end: j]
    return text[arm_end: arm_end + max_chars]


_ARM_HEAD = re.compile(r"is\s+[A-Za-z_][A-Za-z0-9_.]*\s*->")


def _block_after(text: str, idx: int, max_chars: int = 20000) -> str:
    """Brace block following `idx` -- used for a named function body, not a when arm."""
    i = text.find("{", idx)
    if i < 0:
        return text[idx: idx + 400]
    depth = 0
    for j in range(i, min(len(text), i + max_chars)):
        if text[j] == "{":
            depth += 1
        elif text[j] == "}":
            depth -= 1
            if depth == 0:
                return text[idx: j + 1]
    return text[idx: idx + max_chars]


def link_workflows(ext) -> None:
    steps = _index_steps(ext)
    if not steps:
        return
    broker_keys = _broker_key_map(ext)
    writers = _history_writers(ext)
    _link_transitions(ext, steps, broker_keys, writers)
    _link_reentry(ext, steps)


def _history_writers(ext) -> dict[str, list[str]]:
    """class simple name -> ItemHistoryTypes it writes.

    A workflow step never writes history itself; it calls a use case that does. So the
    honest attribution is one hop out, and only from a real write position -- a
    `type = ItemHistoryType.X` named argument -- never from a read or a comparison.
    """
    out: dict[str, list[str]] = {}
    for rel, kf in ext.kt_files.items():
        if "/usecases/" not in rel and "/workflows/" not in rel:
            continue
        try:
            text = (ext.root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if "ItemHistoryType." not in text:
            continue
        found = sorted(set(_HISTORY_WRITE.findall(text)))
        if not found:
            continue
        for d in kf.decls:
            if not d.parent:
                out.setdefault(d.name, [])
                out[d.name] = sorted(set(out[d.name]) | set(found))
                # the interface too, since arms call through it
                for sp in d.supers:
                    out.setdefault(sp.name, [])
                    out[sp.name] = sorted(set(out[sp.name]) | set(found))
    return out


def _index_steps(ext) -> dict[str, set[str]]:
    """sealed WorkflowStep -> its variant names, and a node per variant."""
    out: dict[str, set[str]] = {}
    for fqn, d in ext.decl_by_fqn.items():
        if not _SEALED_STEP.match(d.name) or "sealed" not in d.modifiers:
            continue
        rel = ext.file_of_fqn.get(fqn, "")
        variants = set()
        for other_fqn, od in ext.decl_by_fqn.items():
            if od.parent.split(".")[-1] == d.name and any(
                    s.name == d.name for s in od.supers):
                variants.add(od.name)
        out[d.name] = variants
        node = ext.g.nodes.get(nid("kt", fqn))
        if node is not None:
            node.attrs["workflow"] = True
            node.attrs["variants"] = sorted(variants)
        ext.stats["workflows"] += 1
        ext.stats["workflow_variants"] += len(variants)
        del rel
    return out


def _broker_key_map(ext) -> dict[str, str]:
    """send<Name> -> routing key wire name, read from the broker impls."""
    out: dict[str, str] = {}
    for fqn, d in ext.decl_by_fqn.items():
        if not any(s.name == "RabbitMQMessageBroker" for s in d.supers):
            continue
        for fn in d.functions:
            if not fn.name.startswith("send"):
                continue
            for c in fn.calls:
                if c.callee == "publish":
                    m = re.search(r"RoutingKey\.([A-Z][A-Z0-9_]*)", c.args or "")
                    if m:
                        out[fn.name] = m.group(1)
                        break
    return out


def _link_transitions(ext, steps, broker_keys, writers) -> None:
    for rel, kf in ext.kt_files.items():
        impls = [d for d in kf.decls if d.name.endswith("WorkflowImpl")]
        if not impls:
            continue
        try:
            text = (ext.root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for d in impls:
            for m in _WHEN_ENTRY.finditer(text):
                sealed, variant = m.group(1), m.group(2)
                if sealed not in steps:
                    continue
                line = text.count("\n", 0, m.start()) + 1
                body = _arm_body(text, m.end())

                # ItemAnalysis delegates to a private handler; without following the
                # hop its whole transition graph reads as empty. Read the delegate
                # from THIS arm, never from whatever text happens to follow.
                dm = _ARM_DELEGATE.match(body.strip())
                if dm:
                    fm = re.search(_PRIVATE_FN.format(name=re.escape(dm.group(1))), text)
                    if fm:
                        body = _block_after(text, fm.end())

                src_fqn = ext._resolve(f"{sealed}.{variant}", kf, d.fqn)
                if not src_fqn:
                    continue
                src = nid("kt", src_fqn)

                for sm in _SELF_INVOKE.finditer(body):
                    if sm.group(1) != sealed:
                        continue
                    dst_fqn = ext._resolve(f"{sealed}.{sm.group(2)}", kf, d.fqn)
                    if dst_fqn and dst_fqn != src_fqn:
                        ext.g.add_edge(src, nid("kt", dst_fqn), "step_next",
                                       file=rel, line=line, attrs={"mode": "sync"})
                        ext.stats["workflow_sync_edges"] += 1

                for bm in _BROKER_SEND.finditer(body):
                    key = broker_keys.get(bm.group(1))
                    if not key:
                        continue
                    rid = nid(M.ROUTING_KEY, _wire(ext, key))
                    if rid in ext.g.nodes:
                        ext.g.add_edge(src, rid, "step_awaits", file=rel, line=line,
                                       attrs={"via": bm.group(1)})
                        ext.stats["workflow_async_edges"] += 1

                # direct writes (rare) plus writes by the use cases this arm calls
                hist = set(_HISTORY_WRITE.findall(body))
                via: dict[str, str] = {}
                for cm in re.finditer(r"\b([a-z][A-Za-z0-9]*)\s*\(", body):
                    field = cm.group(1)
                    ptype = next((p.type.split("<")[0] for p in d.ctor_params
                                  if p.name == field), None)
                    if not ptype:
                        continue
                    for t in writers.get(ptype, ()):
                        hist.add(t)
                        via[t] = ptype
                if hist:
                    node = ext.g.nodes.get(src)
                    if node is not None:
                        node.attrs["writes_history"] = sorted(
                            set(node.attrs.get("writes_history", [])) | hist)
                        if via:
                            node.attrs["writes_history_via"] = via


def _wire(ext, const: str) -> str:
    for n in ext.g.by_kind(M.ROUTING_KEY):
        if n.attrs.get("const") == const:
            return n.name
    return const.lower().replace("_", ".")


def _link_reentry(ext, steps) -> None:
    """Which routing key resumes which workflow step."""
    for rel, kf in ext.kt_files.items():
        if not any(d.name.endswith(("MessageHandler", "UseCase", "UseCaseImpl"))
                   for d in kf.decls):
            continue
        try:
            text = (ext.root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if "WorkflowStep." not in text:
            continue
        for m in _RK_BRANCH.finditer(text):
            const = m.group(1)
            body = _block_after(text, m.end(), 2500)
            line = text.count("\n", 0, m.start()) + 1
            for sm in _STEP_CTOR.finditer(body):
                if sm.group(1) not in steps:
                    continue
                dst_fqn = ext._resolve(f"{sm.group(1)}.{sm.group(2)}", kf, "")
                if not dst_fqn:
                    continue
                rid = nid(M.ROUTING_KEY, _wire(ext, const))
                if rid in ext.g.nodes:
                    ext.g.add_edge(rid, nid("kt", dst_fqn), "resumes",
                                   file=rel, line=line)
                    ext.stats["workflow_reentry_edges"] += 1
