"""Test → subject-under-test mapping.

The naming convention (`FooTest.kt` tests `Foo`) is a starting point, not the answer:
129 of 507 tests would be mis-attributed by it, because `FooUseCaseTest` almost always
exercises `FooUseCaseImpl` rather than the interface. So the constructed class inside
the test body wins over the filename, and anything still ambiguous is left UNRESOLVED
rather than guessed.
"""
from __future__ import annotations

import re
from collections import Counter

from . import model as M
from .extract import nid
from .parsers.kotlin import new_parser, parse_kotlin
from .workspace import KOTLIN_EXT, walk_files

_TEST_SRC = re.compile(r"/src/(jvmTest|test|commonTest|linuxTest|macosTest|mingwTest)/kotlin/")
_BACKTICK_FN = re.compile(r"fun\s+`([^`]{4,140})`\s*\(")
_MOCK = {"mockk", "spyk", "every", "coEvery", "verify", "coVerify", "runTest",
         "assertEquals", "assertTrue", "assertFalse", "assertNull", "assertNotNull",
         "listOf", "setOf", "mapOf", "Pair", "Triple", "slot", "capture"}


def link_tests(ext) -> None:
    parser = new_parser()
    for repo in ext.repos.values():
        if "kotlin" not in repo.kinds:
            continue
        for path in walk_files(ext.root, KOTLIN_EXT, ext.root / repo.path):
            rel = str(path.relative_to(ext.root))
            if not _TEST_SRC.search(rel):
                continue
            try:
                st = path.stat()
                stamp = (st.st_mtime_ns, st.st_size)
            except OSError:
                continue
            # Use the shared parse cache: re-parsing 507 test files was 4.5s of an
            # otherwise ~4s warm build.
            cached = ext.cache.get(rel, stamp) if ext.cache else None
            if cached is None:
                try:
                    src = path.read_bytes()
                except OSError:
                    continue
                cached = parse_kotlin(rel, src, parser)
                if ext.cache:
                    ext.cache.put(rel, stamp, cached)
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            _one_file(ext, cached, rel, repo.name, text)


def _one_file(ext, kf, rel: str, repo: str, text: str) -> None:
    top = next((d for d in kf.decls if not d.parent), None)
    if top is None:
        return
    cases = [f.name for d in kf.decls for f in d.functions
             if any(a.name == "Test" for a in f.annotations)]
    prose = _BACKTICK_FN.findall(text)
    if not cases and not top.name.endswith("Test"):
        ext.stats["test_helpers"] += 1
        return

    # Candidate subjects: capitalised constructor calls in the test body, minus the
    # mocking vocabulary. Frequency breaks ties.
    ctors = Counter()
    for d in kf.decls:
        for c in d.calls:
            if c.callee and c.callee[0].isupper() and c.callee not in _MOCK:
                ctors[c.callee] += 1
    stem = top.name[:-4] if top.name.endswith("Test") else top.name

    subject = None
    for cand in (f"{stem}Impl", stem):          # Impl first: the test builds the impl
        if cand in ctors:
            subject = cand
            break
    if subject is None and ctors:
        best, n = ctors.most_common(1)[0]
        # Only trust frequency when the name is related to the test's own name.
        if best.startswith(stem) or stem.startswith(best):
            subject = best
    if subject is None:
        for cand in (f"{stem}Impl", stem):
            if ext._resolve(cand, kf, "") :
                subject = cand
                break

    # Resolve first: a name we cannot map to a declaration is NOT resolved, and
    # recording it as such inflates the coverage number doctor reports.
    fqn = ext._resolve(subject, kf, "") if subject else None
    tid = nid("test", rel)
    ext.g.node(tid, "test", top.name, repo=repo, file=rel, line=top.line,
               attrs={"cases": len(cases),
                      "descriptions": [p for p in prose][:24],
                      "resolved": bool(fqn)})
    ext.stats["test_files"] += 1
    ext.stats["test_cases"] += len(cases)
    if not fqn:
        ext.stats["test_unresolved"] += 1
        return
    ext.g.add_edge(tid, nid("kt", fqn), "tests", file=rel, line=top.line,
                   attrs={"cases": len(cases)})
    ext.stats["test_mapped"] += 1
