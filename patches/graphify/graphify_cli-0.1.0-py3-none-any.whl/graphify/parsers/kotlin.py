"""Kotlin structural extraction via tree-sitter.

Deliberately convention-agnostic: it reports what the source *says* (declarations,
supertypes, annotations, constructor parameters, call sites). Every ControlResell
convention -- @Zodable meaning "wire contract", XxxImpl meaning "binds Xxx" --
is applied a layer up, in the extractors. That split keeps this file correct even
when the house style shifts.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

import tree_sitter_kotlin as tsk
from tree_sitter import Language, Parser

_LANG = Language(tsk.language())


def new_parser() -> Parser:
    return Parser(_LANG)


# --------------------------------------------------------------------------
# data shapes
# --------------------------------------------------------------------------
@dataclass
class KtAnn:
    name: str
    args: str = ""            # raw text inside (...), "" when the annotation is bare

    def first_string(self) -> str | None:
        """The first string literal argument, unquoted -- e.g. @SerialName("X")."""
        s = self.args
        i = s.find('"')
        if i < 0:
            return None
        j = s.find('"', i + 1)
        return s[i + 1:j] if j > i else None


@dataclass
class KtParam:
    name: str
    type: str                 # rendered type, generics included
    nullable: bool = False
    has_default: bool = False
    modifiers: list[str] = field(default_factory=list)
    doc: str = ""             # KDoc written above this property


@dataclass
class KtSuper:
    name: str                 # bare name, generics stripped
    type_args: list[str] = field(default_factory=list)
    is_constructor_call: bool = False   # `: Foo()` -> a class; `: Foo` -> an interface


@dataclass
class KtCall:
    callee: str               # the final identifier being called
    receiver: str = ""        # text left of the last dot, "" for an unqualified call
    line: int = 0
    args: str = ""            # raw text inside (...), truncated


@dataclass
class KtGuard:
    """A precondition that can stop a function early.

    Most "why didn't the AI reply / why didn't it republish" questions resolve to one
    of these, so the condition text is kept verbatim rather than summarised.
    """
    kind: str                 # if_return | elvis_return | require | check | throw
    condition: str
    line: int
    result: str = ""          # what it returns/throws when the guard trips
    # `return@mapNotNull` skips ONE element and carries on; calling that "the workflow
    # stopped" points an investigation at the wrong place entirely.
    scope: str = "function"   # function | element | handler


@dataclass
class KtFun:
    name: str
    line: int
    params: list[KtParam] = field(default_factory=list)
    returns: str = ""
    modifiers: list[str] = field(default_factory=list)
    annotations: list[KtAnn] = field(default_factory=list)
    calls: list[KtCall] = field(default_factory=list)
    guards: list[KtGuard] = field(default_factory=list)
    doc: str = ""
    stub: str = ""            # "todo" | "empty" | "always_errors" | ""


@dataclass
class KtDecl:
    name: str
    kind: str                 # class | interface | object | enum | annotation_class
    line: int
    end_line: int = 0
    fqn: str = ""
    parent: str = ""          # enclosing declaration name, for nested types
    modifiers: list[str] = field(default_factory=list)
    annotations: list[KtAnn] = field(default_factory=list)
    supers: list[KtSuper] = field(default_factory=list)
    ctor_params: list[KtParam] = field(default_factory=list)
    properties: list[KtParam] = field(default_factory=list)
    functions: list[KtFun] = field(default_factory=list)
    enum_entries: list[tuple[str, str]] = field(default_factory=list)  # (name, args)
    doc: str = ""             # KDoc written above the declaration
    calls: list[KtCall] = field(default_factory=list)   # calls in the body, incl. members
    nested: list[str] = field(default_factory=list)

    def ann(self, name: str) -> KtAnn | None:
        for a in self.annotations:
            if a.name == name:
                return a
        return None

    def has_ann(self, *names: str) -> bool:
        got = {a.name for a in self.annotations}
        return any(n in got for n in names)


@dataclass
class KtEmission:
    """A site that produces a message a human might later quote back at you."""
    kind: str                 # log_error|log_warn|log_info|log_debug|throw|error_call|
                              # precondition|mcp_result
    segments: list[str]       # literal runs; interpolation holes removed
    line: int
    exception: str = ""       # class thrown, when this is a throw
    owner: str = ""           # enclosing declaration
    interpolated: bool = False


@dataclass
class KtFile:
    path: str
    package: str = ""
    imports: list[str] = field(default_factory=list)
    # `import a.b.*` -- the star is a separate token, so the qualified identifier alone
    # cannot be told apart from a plain import of a class called `b`.
    star_imports: list[str] = field(default_factory=list)
    decls: list[KtDecl] = field(default_factory=list)
    top_functions: list[KtFun] = field(default_factory=list)
    top_calls: list[KtCall] = field(default_factory=list)
    typealiases: list[tuple[str, str]] = field(default_factory=list)
    emissions: list[KtEmission] = field(default_factory=list)
    parse_errors: int = 0


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _txt(src: bytes, n) -> str:
    return src[n.start_byte:n.end_byte].decode("utf8", "replace")


def _child(n, *types):
    for c in n.children:
        if c.type in types:
            return c
    return None


def _children(n, *types):
    return [c for c in n.children if c.type in types]


def _clean_kdoc(raw: str) -> str:
    """`/** … */` -> plain prose. Leading stars, tags and blank runs dropped."""
    body = raw.strip()
    if not body.startswith("/**"):
        return ""
    body = body[3:]
    if body.endswith("*/"):
        body = body[:-2]
    out: list[str] = []
    for line in body.split("\n"):
        line = line.strip()
        if line.startswith("*"):
            line = line[1:].strip()
        if line.startswith("@"):        # @param / @return / @see -- structural, not prose
            continue
        if line or (out and out[-1]):
            out.append(line)
    return " ".join(x for x in out if x).strip()


def _doc_before(node, src: bytes) -> str:
    """KDoc immediately preceding `node`, skipping annotations and blank lines."""
    prev = node.prev_sibling
    while prev is not None:
        if prev.type in ("comment", "block_comment", "line_comment", "multiline_comment"):
            text = _txt(src, prev)
            if text.lstrip().startswith("/**"):
                return _clean_kdoc(text)
            prev = prev.prev_sibling
            continue
        if not prev.is_named:
            prev = prev.prev_sibling
            continue
        return ""
    return ""


def _name_of(n, src: bytes) -> str:
    c = _child(n, "identifier", "simple_identifier", "type_identifier")
    return _txt(src, c) if c else ""


def _render_type(n, src: bytes) -> tuple[str, bool]:
    """(rendered type text, nullable). Whitespace/newlines collapsed."""
    if n is None:
        return "", False
    nullable = n.type == "nullable_type"
    t = " ".join(_txt(src, n).split())
    return t.rstrip("?") if nullable else t, nullable


def _bare(type_text: str) -> str:
    """`Map<String, Foo>` -> `Map`; `a.b.Foo<X>` -> `a.b.Foo`."""
    i = type_text.find("<")
    return (type_text[:i] if i >= 0 else type_text).strip().rstrip("?")


def _type_args(user_type_node, src: bytes) -> list[str]:
    ta = _child(user_type_node, "type_arguments")
    if ta is None:
        return []
    out = []
    for proj in _children(ta, "type_projection"):
        out.append(" ".join(_txt(src, proj).split()))
    return out


def _modifiers(n, src: bytes) -> tuple[list[str], list[KtAnn]]:
    mods_node = _child(n, "modifiers")
    if mods_node is None:
        return [], []
    mods, anns = [], []
    for c in mods_node.children:
        if c.type == "annotation":
            ci = _child(c, "constructor_invocation")
            if ci is not None:
                ut = _child(ci, "user_type")
                va = _child(ci, "value_arguments")
                anns.append(KtAnn(_bare(_txt(src, ut)) if ut else "",
                                  _txt(src, va) if va else ""))
            else:
                ut = _child(c, "user_type")
                if ut is not None:
                    anns.append(KtAnn(_bare(_txt(src, ut))))
                else:   # use-site targets: @field:Foo, @get:Bar
                    anns.append(KtAnn(_txt(src, c).lstrip("@").split("(")[0].split(":")[-1]))
        else:
            mods.append(_txt(src, c).strip())
    return mods, anns


def _params(container, src: bytes, node_type: str) -> list[KtParam]:
    out = []
    if container is None:
        return out
    for p in _children(container, node_type):
        mods, _ = _modifiers(p, src)
        name = _name_of(p, src)
        tnode = _child(p, "user_type", "nullable_type", "function_type")
        ttext, nullable = _render_type(tnode, src)
        # A default exists when there is an `=` among the direct children.
        has_def = any(c.type == "=" for c in p.children)
        out.append(KtParam(name=name, type=ttext, nullable=nullable,
                           has_default=has_def, modifiers=mods,
                           doc=_doc_before(p, src)))
    return out


# Calls whose full argument text carries graph information (a routing-key list, a
# publish target). Everything else is truncated -- argument text is only ever used
# as a hint, and keeping it all would balloon memory across ~100k call sites.
_KEEP_FULL_ARGS = {"listOf", "setOf", "mapOf", "publish", "queueBind", "startConsuming"}


def _collect_calls(node, src: bytes, out: list[KtCall], limit: int = 4000) -> None:
    """Every call_expression under `node`, without descending into nested types."""
    stack = [node]
    while stack and len(out) < limit:
        n = stack.pop()
        for c in n.children:
            if c.type in ("class_declaration", "object_declaration"):
                continue          # nested declarations are walked separately
            if c.type == "call_expression":
                head = c.children[0] if c.children else None
                recv, callee = "", ""
                if head is not None:
                    if head.type == "navigation_expression":
                        full = _txt(src, head)
                        if "." in full:
                            recv, callee = full.rsplit(".", 1)
                        else:
                            callee = full
                        recv = " ".join(recv.split())
                    else:
                        callee = _txt(src, head)
                callee = _bare(callee.strip())
                va = _child(c, "value_arguments")
                cap = 4000 if callee in _KEEP_FULL_ARGS else 200
                args = " ".join(_txt(src, va).split())[:cap] if va else ""
                if callee:
                    out.append(KtCall(callee=callee, receiver=recv,
                                      line=c.start_point[0] + 1, args=args))
            stack.append(c)


_PRECONDITION_FNS = {"require", "check", "requireNotNull", "checkNotNull"}
# Calls that do not constitute "doing the work" of a handler.
_TRIVIAL_CALLS = {"println", "print", "error", "TODO", "emptyList", "emptyMap",
                  "listOf", "setOf", "mapOf", "Unit", "require", "check"}
# Labels whose `return@label` continues the loop with the next element.
_ELEMENT_LABELS = {"map", "mapNotNull", "forEach", "filter", "flatMap", "onEach",
                   "associate", "associateBy", "sumOf", "any", "all", "none",
                   "firstOrNull", "find", "groupBy", "partition", "mapIndexed",
                   "repeat", "collect", "forEachIndexed", "takeWhile", "dropWhile"}
# These return from a lambda or a coroutine, not from the enclosing function. Calling
# them "what stops it early" points an investigation at the wrong scope.
_BLOCK_LABELS = {"launch", "async", "also", "apply", "let", "run", "use", "runCatching",
                 "supervisorScope", "coroutineScope", "flow", "buildList", "buildString"}
# Ktor route-handler labels: the request ends, the enclosing function does not.
_HANDLER_LABELS = {"get", "post", "put", "delete", "patch", "webSocket", "sse",
                   "handle", "addTool"}


def _return_scope(text: str) -> str:
    """Classify a return by its label. `return@withContext` really does exit the
    function; `return@forEach` only ends one iteration."""
    m = re.match(r"\s*return@(\w+)", text)
    if not m:
        return "function"
    label = m.group(1)
    if label in _ELEMENT_LABELS:
        return "element"
    if label in _HANDLER_LABELS:
        return "handler"
    if label in _BLOCK_LABELS:
        return "block"
    return "function"


def _norm(text: str, limit: int = 160) -> str:
    out = " ".join(text.split())
    return out[:limit] + ("…" if len(out) > limit else "")


def _has_return(node) -> bool:
    stack = [node]
    while stack:
        n = stack.pop()
        if n.type in ("return_expression", "throw_expression"):
            return True
        if n.type in ("lambda_literal", "function_declaration"):
            continue     # a return inside a lambda exits the lambda, not the function
        stack.extend(n.children)
    return False


def _has_nonlocal_return(node, src: bytes) -> bool:
    """A BARE `return` inside an inline stdlib lambda exits the enclosing function.

    The mirror of the labelled case: `return@run` ends the block, a bare `return`
    inside `run {}`/`let {}` does not, because those are inline. So the usual rule
    (ignore returns inside lambdas) is exactly wrong here.
    """
    stack = [node]
    while stack:
        n = stack.pop()
        if n.type == "return_expression":
            text = _txt(src, n).strip()
            if not text.startswith("return@"):
                return True
        if n.type == "function_declaration":
            continue
        stack.extend(n.children)
    return False


def _collect_guards(node, src: bytes, out: list) -> None:
    """Early exits: `if (c) return`, `x ?: return`, `require(c)`, `check(c)`."""
    stack = [node]
    while stack and len(out) < 60:
        n = stack.pop()
        for c in n.children:
            if c.type == "function_declaration":
                continue
            if c.type == "if_expression":
                kids = [k for k in c.children if k.is_named]
                if len(kids) >= 2 and _has_return(kids[1]):
                    res = _txt(src, kids[1])
                    out.append(KtGuard("if_return", _norm(_txt(src, kids[0])),
                                       c.start_point[0] + 1, _norm(res, 60),
                                       _return_scope(res)))
            elif c.type == "binary_expression" and "?:" in _txt(src, c):
                left = c.children[0] if c.children else None
                cond = _norm(_txt(src, left)) if left is not None else ""
                ret = next((k for k in c.children
                            if k.type in ("return_expression", "throw_expression")), None)
                if ret is not None:
                    rtxt = _txt(src, ret)
                    out.append(KtGuard("elvis_return", cond, c.start_point[0] + 1,
                                       _norm(rtxt, 60), _return_scope(rtxt)))
                else:
                    # `?: error("…")` and `?: run { … return }` are exits too. The
                    # first is 140 sites; both are call_expressions, not returns, so a
                    # rule keyed on return_expression never sees them.
                    rhs = next((k for k in reversed(c.children) if k.is_named), None)
                    if rhs is not None and rhs.type == "call_expression":
                        head = rhs.children[0] if rhs.children else None
                        name = _txt(src, head) if head is not None else ""
                        if name in ("error", "TODO"):
                            out.append(KtGuard("elvis_throw", cond,
                                               c.start_point[0] + 1,
                                               _norm(_txt(src, rhs), 60)))
                        elif name in ("run", "let", "also", "apply") and \
                                _has_nonlocal_return(rhs, src):
                            out.append(KtGuard("elvis_block", cond,
                                               c.start_point[0] + 1,
                                               _norm(_txt(src, rhs), 60)))
            elif c.type == "call_expression":
                head = c.children[0] if c.children else None
                name = _txt(src, head) if head is not None else ""
                if name in _PRECONDITION_FNS:
                    va = _child(c, "value_arguments")
                    out.append(KtGuard(name, _norm(_txt(src, va)) if va else "",
                                       c.start_point[0] + 1))
            stack.append(c)


def _fun(n, src: bytes) -> KtFun:
    mods, anns = _modifiers(n, src)
    params = _params(_child(n, "function_value_parameters"), src, "parameter")
    ret_node = None
    seen_params = False
    for c in n.children:
        if c.type == "function_value_parameters":
            seen_params = True
        elif seen_params and c.type in ("user_type", "nullable_type"):
            ret_node = c
            break
    ret, _ = _render_type(ret_node, src)
    f = KtFun(name=_name_of(n, src), line=n.start_point[0] + 1, params=params,
              returns=ret, modifiers=mods, annotations=anns,
              doc=_doc_before(n, src))
    body = _child(n, "function_body")
    if body is not None:
        _collect_calls(body, src, f.calls)
        _collect_guards(body, src, f.guards)
        raw = _txt(src, body)
        # A stub is defined by doing no real work, not by how it is marked. Etsy's
        # unimplemented handlers carry only a `// TODO` comment; conversely a real
        # implementation may contain a TODO branch and is not a stub.
        real = [c for c in f.calls
                if c.callee not in _TRIVIAL_CALLS and not c.callee.startswith("log")]
        if not real:
            if re.search(r"\bTODO\s*\(|NotImplementedError", raw):
                f.stub = "todo"
            elif len(" ".join(raw.strip("{} \n\t").split())) < 3:
                f.stub = "empty"
        # A handler can be fully implemented-looking and still be unimplemented: it
        # constructs a response whose ONLY outcome is an error. That is exactly the
        # shape root CLAUDE.md Trap #4 warns about for etsy/shopify.
        elif re.search(r"\berror\s*=", raw) and not re.search(
                r"\b(response|result)\s*=(?!\s*null)", raw):
            responses = re.findall(r"JobResponse\.\w+\s*\(", raw)
            if responses and raw.count("error =") >= len(responses):
                f.stub = "always_errors"
    return f


_CLASS_KEYWORDS = {"class": "class", "interface": "interface", "object": "object"}


def _decl(n, src: bytes, package: str, parent: str = "") -> list[KtDecl]:
    """Build a KtDecl for `n` plus, recursively, every declaration nested in it."""
    mods, anns = _modifiers(n, src)
    name = _name_of(n, src)
    if not name:
        return []

    if n.type == "object_declaration":
        kind = "object"
    elif "enum" in mods:
        kind = "enum"
    elif "annotation" in mods:
        kind = "annotation_class"
    else:
        kind = "class"
        for c in n.children:
            if not c.is_named and c.type in _CLASS_KEYWORDS:
                kind = _CLASS_KEYWORDS[c.type]
                break

    supers: list[KtSuper] = []
    ds = _child(n, "delegation_specifiers")
    if ds is not None:
        for spec in _children(ds, "delegation_specifier"):
            ci = _child(spec, "constructor_invocation")
            ut = _child(ci, "user_type") if ci is not None else _child(spec, "user_type")
            if ut is None:
                continue
            supers.append(KtSuper(name=_bare(_txt(src, ut)),
                                  type_args=_type_args(ut, src),
                                  is_constructor_call=ci is not None))

    pc = _child(n, "primary_constructor")
    ctor = _params(_child(pc, "class_parameters") if pc else None, src, "class_parameter")

    fqn = f"{package}.{parent}.{name}" if parent else (f"{package}.{name}" if package else name)
    d = KtDecl(name=name, kind=kind, line=n.start_point[0] + 1,
               end_line=n.end_point[0] + 1, fqn=fqn, parent=parent,
               modifiers=mods, annotations=anns, supers=supers, ctor_params=ctor,
               doc=_doc_before(n, src))

    body = _child(n, "class_body", "enum_class_body")
    results = [d]
    if body is not None:
        for e in _children(body, "enum_entry"):
            va = _child(e, "value_arguments")
            d.enum_entries.append((_name_of(e, src),
                                   " ".join(_txt(src, va).split()) if va else ""))
        for f in _children(body, "function_declaration"):
            fn = _fun(f, src)
            d.functions.append(fn)
            d.calls.extend(fn.calls)
        for p in _children(body, "property_declaration"):
            vd = _child(p, "variable_declaration")
            if vd is not None:
                pm, _ = _modifiers(p, src)
                tnode = _child(vd, "user_type", "nullable_type")
                ttext, nullable = _render_type(tnode, src)
                d.properties.append(KtParam(name=_name_of(vd, src), type=ttext,
                                            nullable=nullable, modifiers=pm,
                                            doc=_doc_before(p, src)))
            _collect_calls(p, src, d.calls)
        for c in _children(body, "companion_object"):
            _collect_calls(c, src, d.calls)
        for nested_node in _children(body, "class_declaration", "object_declaration"):
            kids = _decl(nested_node, src, package, parent=(f"{parent}.{name}" if parent else name))
            if kids:
                d.nested.append(kids[0].name)
            results.extend(kids)
    return results


_LOG_RECEIVER = re.compile(r"(?i)(^|\.)log(ger)?$")
_LOG_LEVELS = {"error", "warn", "info", "debug", "trace"}


def _raw_segments(node, src: bytes) -> tuple[list[str], bool, bool]:
    """(segments, starts_with_literal, ends_with_literal) — un-normalised."""
    segs: list[str] = []
    cur: list[str] = []
    pending_ident = False
    first_kind = last_kind = None
    for ch in node.children:
        if ch.type == "interpolation":
            first_kind = first_kind or "hole"
            last_kind = "hole"
            if cur:
                segs.append("".join(cur))
                cur = []
            continue
        if ch.type == "escape_sequence":
            raw = _txt(src, ch)
            cur.append({"\\n": "\n", "\\t": "\t", "\\r": "",
                        '\\"': '"', "\\\\": "\\", "\\$": "$"}.get(raw, ""))
            first_kind = first_kind or "lit"
            last_kind = "lit"
            continue
        if ch.type != "string_content":
            continue
        text = _txt(src, ch)
        if text == "$":
            first_kind = first_kind or "hole"
            last_kind = "hole"
            if cur:
                segs.append("".join(cur))
                cur = []
            pending_ident = True
            continue
        if pending_ident:
            pending_ident = False
            m = re.match(r"[A-Za-z_][A-Za-z0-9_]*(\??\.[A-Za-z_][A-Za-z0-9_]*)*", text)
            text = text[m.end():] if m else text
            if not text:
                continue
        first_kind = first_kind or "lit"
        last_kind = "lit"
        cur.append(text)
    if cur:
        segs.append("".join(cur))
    return segs, first_kind == "lit", last_kind == "lit"


def _string_segments(node, src: bytes) -> list[str]:
    """Literal runs of a Kotlin string, with interpolation holes removed.

    Two shapes must be handled. `${expr}` is a proper `interpolation` node. A bare
    `$ident` is NOT: the grammar emits it as two `string_content` children, the first
    of which is exactly "$" and the second of which starts with the identifier glued
    to the following literal text. Missing that fuses a variable name into the text
    and the segment never matches anything.
    """
    segs: list[str] = []
    cur: list[str] = []
    pending_ident = False
    for ch in node.children:
        if ch.type == "interpolation":
            if cur:
                segs.append("".join(cur))
                cur = []
            continue
        if ch.type == "escape_sequence":
            raw = _txt(src, ch)
            cur.append({"\\n": "\n", "\\t": "\t", "\\r": "",
                        '\\"': '"', "\\\\": "\\", "\\$": "$"}.get(raw, ""))
            continue
        if ch.type != "string_content":
            continue
        text = _txt(src, ch)
        if text == "$":
            if cur:
                segs.append("".join(cur))
                cur = []
            pending_ident = True
            continue
        if pending_ident:
            pending_ident = False
            # strip the identifier glued to the front of this run
            m = re.match(r"[A-Za-z_][A-Za-z0-9_]*(\??\.[A-Za-z_][A-Za-z0-9_]*)*", text)
            text = text[m.end():] if m else text
        cur.append(text)
    if cur:
        segs.append("".join(cur))
    return [" ".join(x.split()) for x in segs if len(" ".join(x.split())) >= 3]


def _arg_segments(arg_node, src: bytes) -> tuple[list[str], bool]:
    """(literal runs, whether the message had any hole).

    Holes come in three shapes here: `${expr}`, a bare `$ident`, and SLF4J `{}`.
    """
    had_hole = False
    stack = [arg_node]
    strings = []
    while stack:
        n = stack.pop(0)
        if n.type in ("string_literal", "multiline_string_literal"):
            strings.append(n)
            continue
        stack.extend(n.children)

    out: list[str] = []
    prev_ended_literal = False
    for sn in sorted(strings, key=lambda n: n.start_byte):
        segs, starts_lit, ends_lit = _raw_segments(sn, src)
        raw_text = _txt(src, sn)
        if "interpolation" in {c.type for c in sn.children} or "$" in raw_text:
            had_hole = True
        if segs and out and prev_ended_literal and starts_lit:
            out[-1] = out[-1] + segs[0]     # contiguous across the `+`
            out.extend(segs[1:])
        else:
            out.extend(segs)
        prev_ended_literal = ends_lit if segs else prev_ended_literal
    flat: list[str] = []
    for seg in out:
        # `logger.warn("failed for {} on {}", a, b)` — SLF4J placeholders are holes.
        if "{}" in seg:
            had_hole = True
            flat.extend(seg.split("{}"))
        else:
            flat.append(seg)
    segs = [" ".join(x.split()) for x in flat if len(" ".join(x.split())) >= 3]
    return segs, had_hole


def _collect_emissions(root, src: bytes, kf: "KtFile") -> None:
    # `error(...)` is shadowed by a local helper in a few files; there it is an
    # MCP tool result shown to a user, which is the opposite classification.
    mcp_helpers: set[str] = set()
    for n in _walk_named(root):
        if n.type != "function_declaration":
            continue
        body = _child(n, "function_body")
        if body is None:
            continue
        txt = _txt(src, body)
        if "CallToolResult" in txt and "isError" in txt:
            nm = _name_of(n, src)
            if nm:
                mcp_helpers.add(nm)
    shadowed_error = "error" in mcp_helpers

    for n in _walk_named(root):
        line = n.start_point[0] + 1
        if n.type == "throw_expression":          # NOT jump_expression
            payload = next((c for c in n.children if c.is_named), None)
            if payload is None or payload.type != "call_expression":
                continue                          # a bare rethrow emits nothing
            head = payload.children[0] if payload.children else None
            exc = _txt(src, head) if head is not None else ""
            va = _child(payload, "value_arguments")
            segs: list[str] = []
            hole = False          # a throw with no arguments never enters the loop
            if va is not None:
                for a in _children(va, "value_argument"):
                    segs, hole = _arg_segments(a, src)
                    if segs:
                        break                     # message is sometimes arg 1
            kf.emissions.append(KtEmission("throw", segs, line, exception=_bare(exc),
                                           interpolated=hole))
            continue

        if n.type != "call_expression":
            continue
        head = n.children[0] if n.children else None
        if head is None:
            continue
        callee_text = _txt(src, head)
        va = _child(n, "value_arguments")

        if head.type == "navigation_expression" and "." in callee_text:
            recv, method = callee_text.rsplit(".", 1)
            if method in _LOG_LEVELS and _LOG_RECEIVER.search(recv.strip()):
                segs, hole = [], False
                if va is not None:
                    for a in _children(va, "value_argument"):
                        segs, hole = _arg_segments(a, src)
                        if segs:
                            break
                if segs:
                    kf.emissions.append(KtEmission(f"log_{method}", segs, line,
                                                   interpolated=hole))
            continue

        if callee_text in mcp_helpers and callee_text != "error" and va is not None:
            segs, hole = [], False
            for a in _children(va, "value_argument"):
                segs, hole = _arg_segments(a, src)
                if segs:
                    break
            if segs:
                kf.emissions.append(KtEmission("mcp_result", segs, line,
                                               interpolated=hole))
            continue

        if callee_text == "error" and va is not None:
            segs, hole = [], False
            for a in _children(va, "value_argument"):
                segs, hole = _arg_segments(a, src)
                if segs:
                    break
            if segs:
                kf.emissions.append(KtEmission(
                    "mcp_result" if shadowed_error else "error_call", segs, line,
                    exception="" if shadowed_error else "IllegalStateException",
                    interpolated=hole))


def _walk_named(root):
    stack = [root]
    while stack:
        n = stack.pop()
        if n.is_named:
            yield n
        stack.extend(n.children)


def parse_kotlin(path: str, src: bytes, parser: Parser | None = None) -> KtFile:
    parser = parser or new_parser()
    tree = parser.parse(src)
    root = tree.root_node

    kf = KtFile(path=path)
    ph = _child(root, "package_header")
    if ph is not None:
        qi = _child(ph, "qualified_identifier")
        kf.package = _txt(src, qi) if qi else ""
    for imp in _children(root, "import"):
        qi = _child(imp, "qualified_identifier")
        if qi is None:
            continue
        name = _txt(src, qi)
        if _txt(src, imp).rstrip().endswith("*"):
            kf.star_imports.append(name)
        else:
            kf.imports.append(name)
    for ta in _children(root, "type_alias"):
        ut = _child(ta, "user_type", "function_type", "nullable_type")
        kf.typealiases.append((_name_of(ta, src), _render_type(ut, src)[0]))
    for n in _children(root, "class_declaration", "object_declaration"):
        kf.decls.extend(_decl(n, src, kf.package))
    for f in _children(root, "function_declaration"):
        kf.top_functions.append(_fun(f, src))
    for p in _children(root, "property_declaration"):
        _collect_calls(p, src, kf.top_calls)

    _collect_emissions(root, src, kf)

    errs = 0
    stack = [root]
    while stack:
        n = stack.pop()
        if n.type == "ERROR" or n.is_missing:
            errs += 1
        stack.extend(n.children)
    kf.parse_errors = errs
    return kf
