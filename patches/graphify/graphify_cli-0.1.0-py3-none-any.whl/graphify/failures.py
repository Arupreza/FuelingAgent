"""The failure index: from a message someone reports, back to the line that emits it.

The hard part looked like string interpolation, but measurement showed it is benign
here: every interpolated message in the corpus carries at least one literal run of 8+
characters, so a rendered string always has an anchor to match against.

Stored beside the graph rather than inside it — 1,200+ message sites with their
segments would bloat every query that does not need them.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

# Emission kinds a person could plausibly quote back at you.
USER_FACING = {"mcp_result", "throw", "error_call"}


def build_index(ext, out_path: Path) -> dict:
    """One record per emission site, with the enclosing declaration resolved."""
    records: list[dict] = []
    for rel, kf in ext.kt_files.items():
        if not kf.emissions:
            continue
        repo = rel.split("/", 1)[0]
        # line -> innermost declaration, so a message can name its owner
        spans = sorted(((d.line, d.end_line or d.line, d.name, d.fqn)
                        for d in kf.decls), key=lambda x: x[0])
        for em in kf.emissions:
            owner = owner_fqn = ""
            for start, end, name, fqn in spans:
                if start <= em.line <= end:
                    owner, owner_fqn = name, fqn
            records.append({
                "kind": em.kind,
                "segments": em.segments,
                "file": rel,
                "line": em.line,
                "repo": repo,
                "owner": owner,
                "owner_fqn": owner_fqn,
                "exception": em.exception,
                "interpolated": em.interpolated,
                # Honest definition: only an MCP result is certainly shown to a
                # person. A throw may surface as an HTTP body or may be swallowed,
                # so it is marked "maybe" rather than promised.
                "user_visible": ("yes" if em.kind == "mcp_result"
                                 else "maybe" if em.kind in USER_FACING else "no"),
            })
    payload = {"messages": records}
    out_path.write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
    ext.stats["message_sites"] = len(records)
    # A message with ONE segment can still be interpolated (a single trailing hole),
    # so counting multi-segment records undercounts by about half.
    ext.stats["message_interpolated"] = sum(
        1 for r in records if r.get("interpolated"))
    return payload


_WS = re.compile(r"\s+")


def _norm(s: str) -> str:
    return _WS.sub(" ", s).strip().lower()


def search(index: dict, query: str, limit: int = 10) -> list[dict]:
    """Rank emission sites by how much of their literal text the query contains.

    Scoring is deliberately conservative: a hit needs one literal run of at least 6
    characters, so a common fragment cannot drag in unrelated sites.
    """
    q = _norm(query)
    if not q:
        return []
    scored = []
    for rec in index.get("messages", []):
        segs = [_norm(s) for s in rec["segments"] if len(s) >= 3]
        if not segs:
            continue
        matched = [s for s in segs if s and s in q]
        anchor = max((len(s) for s in matched), default=0)
        if anchor < 6:
            # fall back to the reverse direction: the user quoted a fragment
            matched = [s for s in segs if s and (q in s or s.startswith(q[:40]))]
            anchor = max((len(s) for s in matched), default=0)
            if anchor < 6:
                continue
        score = sum(len(s) for s in matched) + 20 * (len(matched) > 1)
        coverage = min(1.0, sum(len(s) for s in matched) / max(len(q), 1))
        scored.append({**rec, "score": score, "matched": matched,
                       "coverage": round(coverage, 2)})
    scored.sort(key=lambda r: -r["score"])
    return scored[:limit]
