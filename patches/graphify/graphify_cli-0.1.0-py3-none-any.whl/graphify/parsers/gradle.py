"""Gradle / npm / python build-file parsing -> the module and artifact graph.

Three things get extracted:
  1. version catalogues (gradle/libs.versions.toml) -> alias -> (coordinate, version)
  2. build.gradle.kts dependency references          -> module -> alias | project(":x")
  3. package.json                                    -> npm package -> dependency ranges

The catalogue alias mangling is the fiddly part: Gradle turns the TOML key
`controlresell-connector-consumer` into the accessor `libs.controlresell.connector.consumer`,
so the accessor has to be un-mangled back to the key before it can be looked up.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

try:
    import tomllib          # 3.11+
except ModuleNotFoundError:
    import tomli as tomllib  # 3.10


@dataclass
class CatalogEntry:
    alias: str
    group: str
    artifact: str
    version: str = ""
    version_ref: str = ""

    @property
    def coordinate(self) -> str:
        return f"{self.group}:{self.artifact}"


@dataclass
class Catalog:
    path: str
    versions: dict[str, str] = field(default_factory=dict)
    libraries: dict[str, CatalogEntry] = field(default_factory=dict)
    plugins: dict[str, str] = field(default_factory=dict)

    def by_accessor(self, accessor: str) -> CatalogEntry | None:
        """`controlresell.connector.consumer` -> the `controlresell-connector-consumer` entry.

        Gradle allows dots and dashes to be interchanged in the TOML key, so try
        every dash/dot split of the accessor rather than assuming one shape.
        """
        parts = accessor.split(".")
        for i in range(len(parts), 0, -1):
            for sep in ("-", "."):
                key = sep.join(parts[:i])
                if key in self.libraries:
                    return self.libraries[key]
        key = accessor.replace(".", "-")
        return self.libraries.get(key)


def parse_catalog(path: Path, rel: str) -> Catalog:
    cat = Catalog(path=rel)
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return cat
    cat.versions = {k: str(v) for k, v in (data.get("versions") or {}).items()
                    if isinstance(v, (str, int, float))}
    for alias, spec in (data.get("libraries") or {}).items():
        group = artifact = version = vref = ""
        if isinstance(spec, str):                       # "g:a:v" shorthand
            bits = spec.split(":")
            if len(bits) >= 2:
                group, artifact = bits[0], bits[1]
            if len(bits) >= 3:
                version = bits[2]
        elif isinstance(spec, dict):
            mod = spec.get("module")
            if mod and ":" in mod:
                group, artifact = mod.split(":", 1)
            else:
                group, artifact = spec.get("group", ""), spec.get("name", "")
            v = spec.get("version")
            if isinstance(v, str):
                version = v
            elif isinstance(v, dict):
                vref = v.get("ref", "")
                version = v.get("require", "") or v.get("strictly", "")
            if "version.ref" in spec:
                vref = spec["version.ref"]
        if vref and not version:
            version = cat.versions.get(vref, "")
        if group or artifact:
            cat.libraries[alias] = CatalogEntry(alias, group, artifact, version, vref)
    for alias, spec in (data.get("plugins") or {}).items():
        pid = spec.get("id", "") if isinstance(spec, dict) else str(spec)
        cat.plugins[alias] = pid
    return cat


_LIBS_REF = re.compile(r"\blibs\.((?:[A-Za-z0-9_]+\.)*[A-Za-z0-9_]+)")
_PROJECT_REF = re.compile(r'project\s*\(\s*"(:[^"]+)"\s*\)')
_SOURCESET = re.compile(r"^\s*(?:val\s+)?([A-Za-z][A-Za-z0-9]*)\s*(?:by\s+getting|\{)", re.M)
_CONFIG = re.compile(
    r"\b(api|implementation|compileOnly|runtimeOnly|testImplementation|"
    r"ksp|kspCommonMainMetadata|shadow)\s*\(", re.M)


@dataclass
class BuildFile:
    path: str
    module: str = ""
    lib_refs: list[tuple[str, int, str]] = field(default_factory=list)   # accessor, line, config
    project_refs: list[tuple[str, int, str]] = field(default_factory=list)
    plugin_refs: list[str] = field(default_factory=list)
    group: str = ""
    version: str = ""
    npm_package: str = ""       # Zodable-generated package name, when declared here


_GROUP = re.compile(r'^\s*group\s*=\s*"([^"]+)"', re.M)
_VERSION = re.compile(r'^\s*version\s*=\s*"([^"]+)"', re.M)
# Only inside a `zodable { ... }` block: the Apollo plugin also writes
# `packageName.set("dev.shopify")`, which is a Kotlin package, not an npm package.
_ZODABLE_BLOCK = re.compile(r"\bzodable\s*\{", re.M)
_PKG_NAME = re.compile(r'packageName\s*(?:\.set\s*\(|=)\s*"([^"]+)"')


def parse_build_file(path: Path, rel: str) -> BuildFile:
    bf = BuildFile(path=rel)
    try:
        txt = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return bf
    lines = txt.split("\n")

    def config_at(offset: int) -> str:
        """Nearest enclosing dependency configuration on the same line."""
        line_start = txt.rfind("\n", 0, offset) + 1
        seg = txt[line_start:offset]
        m = None
        for m in _CONFIG.finditer(seg):
            pass
        return m.group(1) if m else ""

    for m in _LIBS_REF.finditer(txt):
        acc = m.group(1)
        line = txt.count("\n", 0, m.start()) + 1
        if acc.startswith("plugins."):
            bf.plugin_refs.append(acc[len("plugins."):])
        else:
            bf.lib_refs.append((acc, line, config_at(m.start())))
    for m in _PROJECT_REF.finditer(txt):
        line = txt.count("\n", 0, m.start()) + 1
        bf.project_refs.append((m.group(1), line, config_at(m.start())))

    g = _GROUP.search(txt)
    if g:
        bf.group = g.group(1)
    v = _VERSION.search(txt)
    if v:
        bf.version = v.group(1)
    zb = _ZODABLE_BLOCK.search(txt)
    if zb:
        depth, end = 0, len(txt)
        for i in range(zb.end() - 1, len(txt)):
            if txt[i] == "{":
                depth += 1
            elif txt[i] == "}":
                depth -= 1
                if depth == 0:
                    end = i
                    break
        z = _PKG_NAME.search(txt, zb.end(), end)
        if z:
            bf.npm_package = z.group(1)
    del lines
    return bf


def parse_package_json(path: Path, rel: str) -> dict:
    try:
        d = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return {}
    deps = {}
    for key in ("dependencies", "devDependencies", "peerDependencies"):
        for k, v in (d.get(key) or {}).items():
            deps[k] = {"range": v, "scope": key}
    return {
        "path": rel,
        "name": d.get("name", ""),
        "version": d.get("version", ""),
        "private": bool(d.get("private")),
        "workspaces": d.get("workspaces") or [],
        "deps": deps,
        "scripts": list((d.get("scripts") or {}).keys()),
    }
