"""Durable, self-verifying knowledge about this workspace.

The expensive part of working here is not reading code — it is re-deriving the same
conventions every session: how a browser slave registers a handler, why Exposed does
not snake_case a table name, that `return@mapNotNull` is not an exit. That knowledge
was verified once, at real cost, and then thrown away.

A claim here is atomic, carries its evidence, and carries a CHECK that is re-evaluated
on every build. Checks are declarative data, never executable code: a claim can go
STALE, but it can never run something.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

FRESH, STALE, UNCHECKED = "fresh", "stale", "unchecked"


@dataclass
class Claim:
    id: str
    claim: str                       # one fact, stated plainly
    topic: str                       # slug for `graphify know <topic>`
    kind: str = "convention"         # convention | gotcha | count | contract | process
    evidence: list[str] = field(default_factory=list)   # "path:line"
    check: dict | None = None        # declarative predicate, see CHECK_OPS
    source: str = ""                 # where the claim came from
    detail: str = ""                 # the how/why, when it does not fit in `claim`
    status: str = UNCHECKED
    note: str = ""                   # why a check failed


# --------------------------------------------------------------------------
# check evaluation — data only, no code execution
# --------------------------------------------------------------------------
CHECK_OPS = {
    "file_exists",      # {file}
    "file_contains",    # {file, text} | {file, regex}
    "count",            # {kind, eq|gte|lte}            nodes of a kind
    "node_exists",      # {name, kind?}
    "attr_eq",          # {name, attr, value}
    "edge_exists",      # {src_name, dst_name, kind?}
    "stat",             # {key, eq|gte|lte}             build statistic
    "all", "any", "not",
}


class Checker:
    def __init__(self, root: Path, graph, stats: dict):
        self.root = root
        self.g = graph
        self.stats = stats or {}
        self._by_name: dict[str, list] = {}
        if graph is not None:
            for n in graph.nodes.values():
                self._by_name.setdefault(n.name, []).append(n)

    def run(self, check: dict | None) -> tuple[str, str]:
        if not check:
            return UNCHECKED, ""
        try:
            ok, why = self._eval(check)
        except Exception as exc:            # a malformed check is a stale claim
            return STALE, f"check error: {type(exc).__name__}: {exc}"
        return (FRESH, "") if ok else (STALE, why)

    def _eval(self, c: dict) -> tuple[bool, str]:
        op = c.get("op")
        if op not in CHECK_OPS:
            return False, f"unknown op {op!r}"

        if op == "all":
            for sub in c["checks"]:
                ok, why = self._eval(sub)
                if not ok:
                    return False, why
            return True, ""
        if op == "any":
            whys = []
            for sub in c["checks"]:
                ok, why = self._eval(sub)
                if ok:
                    return True, ""
                whys.append(why)
            return False, " / ".join(w for w in whys if w)
        if op == "not":
            ok, _ = self._eval(c["check"])
            return (not ok), "expected the inner check to fail"

        if op == "file_exists":
            p = self.root / c["file"]
            return (p.exists(), "" if p.exists() else f"missing {c['file']}")

        if op == "file_contains":
            p = self.root / c["file"]
            if not p.exists():
                return False, f"missing {c['file']}"
            text = p.read_text(encoding="utf-8", errors="replace")
            if "regex" in c:
                hit = re.search(c["regex"], text) is not None
                return hit, "" if hit else f"{c['file']} no longer matches /{c['regex']}/"
            hit = c["text"] in text
            return hit, "" if hit else f"{c['file']} no longer contains {c['text']!r}"

        if op == "count":
            n = sum(1 for x in self.g.nodes.values() if x.kind == c["kind"])
            return self._compare(n, c, f"{c['kind']} count")

        if op == "stat":
            v = self.stats.get(c["key"])
            if v is None:
                return False, f"no build stat {c['key']!r}"
            return self._compare(v, c, c["key"])

        if op == "node_exists":
            hits = [n for n in self._by_name.get(c["name"], [])
                    if not c.get("kind") or n.kind == c["kind"]]
            return bool(hits), "" if hits else f"no node named {c['name']!r}"

        if op == "attr_eq":
            for n in self._by_name.get(c["name"], []):
                if n.attrs.get(c["attr"]) == c["value"]:
                    return True, ""
            return False, (f"{c['name']}.{c['attr']} is not {c['value']!r}")

        if op == "edge_exists":
            srcs = {n.id for n in self._by_name.get(c["src_name"], [])}
            dsts = {n.id for n in self._by_name.get(c["dst_name"], [])}
            for e in self.g.edges:
                if e.src in srcs and e.dst in dsts and \
                        (not c.get("kind") or e.kind == c["kind"]):
                    return True, ""
            return False, f"no edge {c['src_name']} -> {c['dst_name']}"
        return False, "unreachable"

    @staticmethod
    def _compare(value, c: dict, label: str) -> tuple[bool, str]:
        for key, ok, word in (("eq", value == c.get("eq"), "=="),
                              ("gte", value >= c.get("gte", 0), ">="),
                              ("lte", value <= c.get("lte", 0), "<=")):
            if key in c:
                return ok, "" if ok else f"{label} is {value}, expected {word} {c[key]}"
        return False, f"{label}: no comparison given"


# --------------------------------------------------------------------------
# store
# --------------------------------------------------------------------------
class Knowledge:
    def __init__(self, path: Path):
        self.path = path
        self.claims: dict[str, Claim] = {}

    def load(self) -> "Knowledge":
        if self.path.exists():
            try:
                raw = json.loads(self.path.read_text(encoding="utf-8"))
                for c in raw.get("claims", []):
                    self.claims[c["id"]] = Claim(**c)
            except Exception:
                pass
        return self

    def save(self) -> None:
        self.path.write_text(json.dumps(
            {"claims": [asdict(c) for c in self.claims.values()]},
            indent=1, ensure_ascii=False), encoding="utf-8")

    def add(self, c: Claim) -> None:
        prev = self.claims.get(c.id)
        if prev is not None:
            # keep a hand-written check when re-seeding from transcripts
            c.check = c.check or prev.check
        self.claims[c.id] = c

    def verify(self, checker: Checker) -> dict[str, int]:
        counts = {FRESH: 0, STALE: 0, UNCHECKED: 0}
        for c in self.claims.values():
            c.status, c.note = checker.run(c.check)
            counts[c.status] += 1
        return counts

    def search(self, topic: str) -> list[Claim]:
        """Rank by how directly a claim answers the query.

        A topic query should lead with the conventions that define the topic, not
        with a gotcha that merely mentions one of its type names — so an on-topic
        claim whose own text carries the query term outranks one that does not.
        """
        t = topic.lower().strip()
        if not t:
            return sorted(self.claims.values(),
                          key=lambda c: (c.topic, c.kind != "convention", c.id))
        scored: list[tuple[tuple, Claim]] = []
        for c in self.claims.values():
            in_topic = t in c.topic.lower()
            in_claim = t in c.claim.lower()
            in_detail = t in (c.detail or "").lower()
            if not (in_topic or in_claim or in_detail
                    or t in " ".join(c.evidence).lower()):
                continue
            if in_claim:
                tier = 0                       # the claim itself is about this
            elif in_topic and in_detail:
                tier = 1
            elif in_topic:
                tier = 2
            else:
                tier = 3
            # within a tier, conventions before gotchas, then longer detail first
            scored.append(((tier, c.kind != "convention", -len(c.detail or "")), c))
        return [c for _, c in sorted(scored, key=lambda x: (x[0], x[1].id))]
