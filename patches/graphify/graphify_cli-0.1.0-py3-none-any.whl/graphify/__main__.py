"""`python -m graphify` — same entry point as the installed `graphify` command."""
import sys

from .cli import main

if __name__ == "__main__":
    sys.exit(main())
