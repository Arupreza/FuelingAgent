"""Cross-service messaging edges: who publishes and who consumes each routing key.

This is the layer that turns 15 independently-deployed repos into one picture.
It is convention-driven by necessity -- the RabbitMQ topology is expressed in
Kotlin call sites, not in any manifest -- so every rule here is anchored to a
verified idiom and degrades to "no edge" rather than to a guessed one.
"""
from __future__ import annotations

import re
from collections import Counter, defaultdict
from pathlib import Path

from . import model as M
from .extract import nid

# The five typed broker facades. Every AMQP publish in the workspace goes
# through a `send<Name>` method on one of them.
BROKER_SUPER = "RabbitMQMessageBroker"
FACTORY_SUPER = "RabbitMQFactoryImpl"

_RK_ENUM_FQN_SUFFIX = "models.application.RoutingKey"

_RK_TOKEN = re.compile(r"\bRoutingKey\.([A-Z][A-Z0-9_]*)")
_RK_BRANCH = re.compile(r"\bRoutingKey\.([A-Z][A-Z0-9_]*)\.key\s*->")
_DECODE = re.compile(r"decodeFromString<\s*([A-Za-z_][A-Za-z0-9_.]*)")
_SERVICE_TOKEN = re.compile(r"\bService\.([A-Z][A-Z0-9_]*)\b")
_SEND_CALL = re.compile(r"\bsend[A-Z][A-Za-z0-9]*")
_JOB_CTOR = re.compile(r"\b(JobPayload|JobResponse)\.([A-Za-z][A-Za-z0-9]*)\s*\(")
# connector-slave dispatches AccountsDeclare / AccountsRestart with a plain
# `if (request.payload is JobPayload.X)` guard rather than a `when` arm.
_IS_VARIANT = re.compile(r"\bis\s+(JobPayload|JobResponse)\.([A-Za-z][A-Za-z0-9]*)\b")
_HELM_RK = re.compile(r'"routing_key"\s*:\s*"([a-z0-9._]+)"')
_PY_PUBLISH = re.compile(r"routing_key\s*=\s*[\"']([a-z0-9._]+)[\"']")
_PY_HANDLERS = re.compile(r"[\"']([a-z]+(?:\.[a-z_]+)+)[\"']\s*:")


def _svc_id(name: str) -> str:
    return nid(M.SERVICE, name)


def link_messaging(ext) -> None:
    rk_by_const, rk_by_wire = _index_routing_keys(ext)
    services = _index_services(ext)
    methods = _index_brokers(ext, rk_by_const)
    _link_publishers(ext, methods, services, rk_by_const)
    _link_subscriptions(ext, services, rk_by_const)
    _link_dispatch(ext, services, rk_by_const)
    _link_job_variants(ext, services)
    _link_indirect_responses(ext, services, rk_by_const)
    _link_helm_crons(ext, rk_by_wire)
    _link_python(ext, rk_by_wire)
    _link_headers_exchange(ext, rk_by_const)
    _measure_publish_coverage(ext, methods)


def _link_headers_exchange(ext, rk_by_const) -> None:
    """Job dispatch reaches the slaves through the headers exchange.

    `platforms.jobs.request` is published to `controlresell-connector-consumer` with
    `platform` / `virtualMachineId` / `accountId` headers; the routing key rides along
    but is inert, so no queue *binds* it and the topic-level view shows the busiest
    path in the platform as having no consumer at all. Any service that dispatches
    JobPayload variants is consuming that exchange, so link it there.
    """
    rid = rk_by_const.get("PLATFORMS_JOBS_REQUEST")
    if not rid:
        return
    node = ext.g.nodes.get(rid)
    if node is not None:
        node.attrs["routed_by"] = "headers"
        node.attrs["exchange"] = "controlresell-connector-consumer"
    for e in list(ext.g.edges):
        if e.kind != M.HANDLES or e.attrs.get("via") != "task_dispatch":
            continue
        svc = ext.g.nodes.get(e.src)
        if svc is None or svc.kind != M.SERVICE:
            continue
        ext.g.add_edge(svc.id, rid, M.SUBSCRIBES, file=e.file, line=e.line,
                       attrs={"via": "headers", "exchange":
                              "controlresell-connector-consumer"})
        ext.stats["headers_subscribe_edges"] += 1


def _measure_publish_coverage(ext, methods) -> None:
    """How many real `send<Name>(` call sites became edges.

    A standing regression guard: a walk that misses a syntactic position (top-level
    route functions did, once) shows up here as a coverage drop rather than as a
    silently emptier graph.
    """
    if not methods:
        return
    names = set(methods)
    found = 0
    for rel, kf in ext.kt_files.items():
        try:
            text = (ext.root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for m in re.finditer(r"\.(send[A-Z][A-Za-z0-9]*)\s*\(", text):
            if m.group(1) in names:
                found += 1
    edges = ext.stats.get("publish_edges", 0)
    ext.stats["publish_call_sites_in_source"] = found
    ext.stats["publish_coverage_pct"] = round(100 * edges / found, 1) if found else 0.0


# ---------------------------------------------------------------- routing keys
def _index_routing_keys(ext) -> tuple[dict[str, str], dict[str, str]]:
    """RoutingKey enum -> a node per key. Returns (const->id, wire->id)."""
    by_const: dict[str, str] = {}
    by_wire: dict[str, str] = {}
    for fqn, d in ext.decl_by_fqn.items():
        if d.name != "RoutingKey" or d.kind != "enum":
            continue
        rel = ext.file_of_fqn.get(fqn, "")
        for const, args in d.enum_entries:
            m = re.search(r'"([^"]+)"', args or "")
            wire = m.group(1) if m else const.lower().replace("_", ".")
            parts = [a.strip() for a in (args or "").strip("()").split(",")]
            multiple = len(parts) > 1 and parts[1] == "true"
            priority = 0
            for p in parts[2:]:
                if p.isdigit():
                    priority = int(p)
            rid = nid(M.ROUTING_KEY, wire)
            ext.g.node(rid, M.ROUTING_KEY, wire, repo=rel.split("/", 1)[0], file=rel,
                       attrs={"const": const, "fanout": multiple, "priority": priority})
            by_const[const] = rid
            by_wire[wire] = rid
        break
    ext.stats["routing_keys"] = len(by_const)
    return by_const, by_wire


def _index_services(ext) -> dict[str, str]:
    """repo -> service node id, decided by the Service enum constant it uses most."""
    for fqn, d in ext.decl_by_fqn.items():
        if d.name == "Service" and d.kind == "enum":
            for const, _ in d.enum_entries:
                ext.g.node(_svc_id(const), M.SERVICE, const,
                           file=ext.file_of_fqn.get(fqn, ""),
                           attrs={"queue": "controlresell-" + const.lower().replace("_", "-"),
                                  "exchange": "controlresell"})
            break

    votes: dict[str, Counter] = defaultdict(Counter)
    for rel, kf in ext.kt_files.items():
        repo = rel.split("/", 1)[0]
        if repo == "controlresell-core":
            continue
        weight = 3 if ("/config/" in rel or "/di/" in rel or "Factory" in rel) else 1
        for d in kf.decls:
            for c in d.calls:
                for m in _SERVICE_TOKEN.finditer(f"{c.receiver}.{c.callee}({c.args})"):
                    votes[repo][m.group(1)] += weight
            for p in d.properties:
                for m in _SERVICE_TOKEN.finditer(p.type or ""):
                    votes[repo][m.group(1)] += 1

    # Declared Service constants, so a repo name can be matched against them.
    declared = {n.name for n in ext.g.by_kind(M.SERVICE)}

    def from_repo_name(repo: str) -> str | None:
        """`controlresell-connector-ebay` -> `CONNECTOR_EBAY`, when that constant exists."""
        cand = repo.replace("controlresell-", "").replace("-", "_").upper()
        return cand if cand in declared else None

    out: dict[str, str] = {}
    for repo, counter in votes.items():
        # Never let a *reference* to another service claim this repo's identity.
        best = counter.most_common(1)[0][0]
        out[repo] = _svc_id(best)
        ext.g.add_edge(nid(M.REPO, repo), _svc_id(best), "runs_as",
                       attrs={"votes": counter.most_common(4)})
    for repo, r in ext.repos.items():
        if repo in out:
            continue
        # The API slaves never name themselves through the Service enum -- their
        # identity is the ConsumerConfiguration they bind. Fall back to the repo name.
        byname = from_repo_name(repo)
        if byname and "kotlin" in r.kinds:
            out[repo] = _svc_id(byname)
            ext.g.add_edge(nid(M.REPO, repo), _svc_id(byname), "runs_as",
                           attrs={"inferred": "repo-name"})
        else:
            out.setdefault(repo, nid(M.REPO, repo))
    return out


# ------------------------------------------------------------------- publishers
def _index_brokers(ext, rk_by_const) -> dict[str, dict]:
    """`send<Name>` -> the routing key it publishes and the payload it carries."""
    methods: dict[str, dict] = {}
    by_broker: dict[tuple, dict] = {}     # (broker interface, method) -> info
    for fqn, d in ext.decl_by_fqn.items():
        if not any(s.name == BROKER_SUPER for s in d.supers):
            continue
        rel = ext.file_of_fqn.get(fqn, "")
        ext.stats["broker_impls"] += 1
        for fn in d.functions:
            if not fn.name.startswith("send"):
                continue
            consts: list[str] = []
            delayed = False
            exchange = ""
            for c in fn.calls:
                if c.callee in ("publish", "publishAt"):
                    consts += _RK_TOKEN.findall(c.args or "")
                    if c.callee == "publish" and c.args:
                        exchange = (c.args.lstrip("( ").split(",", 1)[0]).strip()
                    if c.callee == "publishAt":
                        delayed = True
                if c.callee == "publishAt":
                    delayed = True
            if not consts:
                continue
            payload = ""
            for p in fn.params:
                if p.name in ("payload", "message", "body", "request", "response"):
                    payload = p.type
                    break
            if not payload and fn.params:
                payload = fn.params[0].type
            # `exchangeName` is the shared topic exchange; anything else (a
            # ConsumerConfiguration exchange, the suspend exchange) is header-routed,
            # so the key deliberately has no topic subscriber.
            # `Service.X.exchange` IS the shared topic exchange (always the literal
            # "controlresell"), so only a ConsumerConfiguration/suspend exchange is
            # header-routed.
            headers = (bool(exchange) and "exchangeName" not in exchange
                       and ".exchange" not in exchange
                       and "Service." not in exchange)
            methods.setdefault(fn.name, {})
            methods[fn.name] = {
                "rk": consts[0], "payload": payload, "broker": d.name,
                "broker_fqn": fqn, "file": rel, "line": fn.line, "delayed": delayed,
                "exchange": exchange, "headers": headers,
            }
            # Also index per broker, so a call site can be attributed to the impl its
            # own injected field actually points at.
            for sup in d.supers:
                if sup.name.endswith("MessageBroker"):
                    by_broker[(sup.name, fn.name)] = methods[fn.name]
            by_broker[(d.name, fn.name)] = methods[fn.name]

            ext.stats["broker_send_methods"] += 1
    methods["__by_broker__"] = by_broker
    return methods


def _call_sources(ext, kf, rel):
    """(node id, broker field names, calls) for every place code can live in a file.

    Ktor route files carry no class at all -- they are top-level
    `fun Route.xxxRoutes(deps) = with(deps) { ... }` -- so a walk over declarations
    alone misses every publish made from a route.
    """
    for d in kf.decls:
        yield (nid("kt", d.fqn),
               {p.name for p in d.ctor_params
                if p.type and p.type.endswith("MessageBroker")},
               d.calls)
    repo = rel.split("/", 1)[0]
    for fn in kf.top_functions:
        if not fn.calls:
            continue
        fqn = f"{kf.package}.{fn.name}" if kf.package else fn.name
        key = ext._key(fqn, repo)
        yield (nid("kt", key),
               {p.name for p in fn.params
                if p.type and p.type.endswith("MessageBroker")},
               fn.calls)
    if kf.top_calls:
        yield (nid(M.REPO, repo), set(), kf.top_calls)


def _runs_handlers(ext, repo: str) -> bool:
    """Does this repo actually dispatch jobs, or does it merely link the library?"""
    for rel, kf in ext.kt_files.items():
        if not rel.startswith(repo + "/"):
            continue
        for d in kf.decls:
            if any(sp.name in ("TaskHandler", "HandleSlaveTaskUseCase",
                               "BrowserTaskHandler") for sp in d.supers):
                return True
            if d.name in ("DefaultTaskHandler", "DefaultTaskHandlerRouter"):
                return True
    return False


def _library_consumers(ext, services) -> dict[str, list[str]]:
    """module path prefix -> services that link that library module."""
    out: dict[str, list[str]] = {}
    for coord, owner in ext.artifact_owner.items():
        owner_repo, owner_mod = owner.split(":", 1)
        consumers = []
        for e in ext.g.edges:
            if e.kind != M.DEPENDS_ON:
                continue
            s_, d_ = ext.g.nodes.get(e.src), ext.g.nodes.get(e.dst)
            if not s_ or not d_ or d_.kind != M.ARTIFACT:
                continue
            if d_.attrs.get("coordinate") == coord and s_.repo != owner_repo:
                svc = services.get(s_.repo)
                # Pinning a library is not running it. vinted-ws pins
                # connector-consumer but consumes no job queue, so crediting it with
                # the library's publishes invents a service-to-service edge.
                if svc and svc not in consumers and _runs_handlers(ext, s_.repo):
                    consumers.append(svc)
        if consumers:
            mod = ext.repos[owner_repo].modules.get(owner_mod)
            if mod and mod.path:
                out[mod.path] = consumers
    return out


def _link_publishers(ext, methods, services, rk_by_const) -> None:
    """Every call site of a `send<Name>` becomes a PUBLISHES edge."""
    libs = _library_consumers(ext, services)
    for rel, kf in ext.kt_files.items():
        repo = rel.split("/", 1)[0]
        svc = services.get(repo, nid(M.REPO, repo))
        # Code in a library module runs inside whichever services link it.
        lib_svcs = next((v for k, v in libs.items() if rel.startswith(k + "/")), None)
        by_broker = methods.get("__by_broker__", {})
        for src, broker_fields, calls in _call_sources(ext, kf, rel):
            if src not in ext.g.nodes:
                continue
            # field name -> declared broker interface, for precise attribution
            field_types = {}
            for dcl in kf.decls:
                for prm in dcl.ctor_params:
                    if prm.type and prm.type.endswith("MessageBroker"):
                        field_types[prm.name] = prm.type
            d = type("D", (), {"fqn": src.split(":", 1)[1]})()
            for c in calls:
                info = methods.get(c.callee)
                if not info:
                    continue
                recv = c.receiver.split(".")[-1] if c.receiver else ""
                iface = field_types.get(recv)
                if iface and (iface, c.callee) in by_broker:
                    info = by_broker[(iface, c.callee)]
                # A bare call with no broker receiver is almost always a
                # same-named helper, so require the receiver to look like one.
                if c.receiver and broker_fields and c.receiver.split(".")[-1] not in broker_fields:
                    if "roker" not in c.receiver and "abbit" not in c.receiver:
                        continue
                rid = rk_by_const.get(info["rk"])
                if not rid:
                    continue
                variant = ""
                jm = _JOB_CTOR.search(c.args or "")
                if jm:
                    variant = f"{jm.group(1)}.{jm.group(2)}"
                attrs = {"via": c.callee, "payload": info["payload"],
                         "broker": info["broker"]}
                if info.get("headers"):
                    attrs["headers_exchange"] = info.get("exchange", "")
                if variant:
                    attrs["variant"] = variant
                if info["delayed"]:
                    attrs["delayed"] = True
                # A publish to a headers exchange (the per-account suspend queue, the
                # slave consumer exchange) carries the routing key but is not routed by
                # it, so it must not show up as topic fan-in.
                kind = "publishes_headers" if info.get("headers") else M.PUBLISHES
                if lib_svcs:
                    for ls in lib_svcs:
                        ext.g.add_edge(ls, rid, kind, file=rel, line=c.line,
                                       attrs={**attrs, "via_library": rel.split("/")[1]})
                else:
                    ext.g.add_edge(svc, rid, kind, file=rel, line=c.line, attrs=attrs)
                ext.g.add_edge(src, rid, "publishes_from", file=rel, line=c.line,
                               attrs={"via": c.callee})
                ext.stats["publish_edges"] += 1
                if info["payload"]:
                    tgt = ext._resolve(info["payload"].split("<")[0], kf, d.fqn)
                    if tgt:
                        ext.g.add_edge(rid, nid("kt", tgt), M.CARRIES,
                                       attrs={"direction": "publish"})
                if variant:
                    tgt = ext._resolve(variant, kf, d.fqn)
                    if tgt:
                        ext.g.add_edge(rid, nid("kt", tgt), M.CARRIES,
                                       file=rel, line=c.line,
                                       attrs={"direction": "publish", "variant": True})


# ----------------------------------------------------------------- subscribers
def _link_subscriptions(ext, services, rk_by_const) -> None:
    """`private val keys = listOf(RoutingKey.…)` in a factory IS the binding set."""
    for fqn, d in ext.decl_by_fqn.items():
        if not any(s.name == FACTORY_SUPER for s in d.supers):
            continue
        rel = ext.file_of_fqn.get(fqn, "")
        repo = rel.split("/", 1)[0]
        svc = services.get(repo, nid(M.REPO, repo))
        ext.stats["rabbit_factories"] += 1
        # Line numbers inside the key list, so a subscribe edge points at the entry
        # rather than at the `listOf(` that opens it.
        key_lines: dict[str, int] = {}
        try:
            for i, ln in enumerate((ext.root / rel).read_text(
                    encoding="utf-8", errors="replace").split("\n"), 1):
                for const in _RK_TOKEN.findall(ln):
                    key_lines.setdefault(const, i)
        except OSError:
            pass
        seen: set[str] = set()
        for c in d.calls:
            if c.callee not in ("listOf", "setOf"):
                continue
            for const in _RK_TOKEN.findall(c.args or ""):
                if const in seen:
                    continue
                seen.add(const)
                rid = rk_by_const.get(const)
                if rid:
                    ext.g.add_edge(svc, rid, M.SUBSCRIBES, file=rel,
                                   line=key_lines.get(const, c.line),
                                   attrs={"via": "queueBind", "factory": d.name})
                    ext.stats["subscribe_edges"] += 1
        if seen:
            ext.g.add_edge(svc, nid("kt", fqn), "binds_via", file=rel, line=d.line)


def _link_dispatch(ext, services, rk_by_const) -> None:
    """`when (routingKey) { RoutingKey.X.key -> decodeFromString<T>(body) }`.

    Read from source rather than the AST: the branch-to-decode association is a
    textual adjacency inside a `when`, and matching it directly is both simpler
    and less brittle than modelling Kotlin's when-expression shape.
    """
    for rel, kf in ext.kt_files.items():
        if not any(d.name.endswith(("MessageHandler", "TaskHandler", "TaskHandlerRouter"))
                   for d in kf.decls):
            continue
        try:
            text = (ext.root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if "RoutingKey." not in text:
            continue
        lines = text.split("\n")
        repo = rel.split("/", 1)[0]
        svc = services.get(repo, nid(M.REPO, repo))
        for m in _RK_BRANCH.finditer(text):
            const = m.group(1)
            rid = rk_by_const.get(const)
            if not rid:
                continue
            line = text.count("\n", 0, m.start()) + 1
            window = "\n".join(lines[line - 1: line + 6])
            dm = _DECODE.search(window)
            payload = dm.group(1) if dm else ""
            ext.g.add_edge(svc, rid, M.SUBSCRIBES, file=rel, line=line,
                           attrs={"via": "dispatch", "payload": payload})
            ext.stats["dispatch_edges"] += 1
            owner = _decl_at(kf, line)
            if owner:
                ext.g.add_edge(nid("kt", owner.fqn), rid, "handles_key",
                               file=rel, line=line, attrs={"payload": payload})
                # Which use case THIS branch invokes. Without it every key appears to
                # trigger everything the dispatcher can reach -- DefaultMessageHandler
                # holds 37 dependencies and 41 branches, so the answer collapses to
                # "all of them" and is worse than no answer at all.
                # Every injected dependency the branch calls, not just the first: a
                # branch that fans out to two use cases would otherwise lose one, and
                # `explain`'s "triggered by" would miss that key entirely.
                deps = {p.name: p.type for p in owner.ctor_params if p.name}
                seen_fields: set[str] = set()
                for ln in _branch_lines(lines, line):
                    for cm in re.finditer(r"\b([a-z][A-Za-z0-9]*)\s*\(", ln):
                        nm = cm.group(1)
                        if nm not in deps or nm in seen_fields:
                            continue
                        seen_fields.add(nm)
                        tgt = ext._resolve(deps[nm].split("<")[0], kf, owner.fqn)
                        if tgt:
                            ext.g.add_edge(rid, nid("kt", tgt), "dispatches_to",
                                           file=rel, line=line,
                                           attrs={"handler_field": nm})
                            ext.stats["dispatch_target_edges"] += 1
            if payload:
                tgt = ext._resolve(payload.split("<")[0], kf, "")
                if tgt:
                    ext.g.add_edge(rid, nid("kt", tgt), M.CARRIES, file=rel, line=line,
                                   attrs={"direction": "consume"})


_NEXT_BRANCH = re.compile(r"RoutingKey\.[A-Z][A-Z0-9_]*\.key\s*->")


def _branch_lines(lines: list[str], start: int, cap: int = 40) -> list[str]:
    """The lines of ONE `when (routingKey)` arm.

    A fixed window is wrong in both directions: too small and a branch's real handler
    falls outside it, too large and the next branch's handler is attributed here. Stop
    at the next arm, or when the arm's own braces close.
    """
    out: list[str] = []
    depth = 0
    opened = False
    for i in range(start - 1, min(len(lines), start - 1 + cap)):
        ln = lines[i]
        if i > start - 1 and _NEXT_BRANCH.search(ln):
            break
        out.append(ln)
        depth += ln.count("{") - ln.count("}")
        if ln.count("{"):
            opened = True
        if opened and depth <= 0 and i > start - 1:
            break
    return out


def _decl_at(kf, line: int):
    """Innermost declaration whose line range contains `line`."""
    best = None
    for d in kf.decls:
        if d.line <= line <= (d.end_line or d.line):
            if best is None or d.line > best.line:
                best = d
    return best


def _link_job_variants(ext, services) -> None:
    """`is JobPayload.X ->` in a slave dispatcher = that slave consumes X."""
    for rel, kf in ext.kt_files.items():
        if not any("TaskHandler" in d.name or "TaskHandlerRouter" in d.name
                   for d in kf.decls):
            continue
        try:
            text = (ext.root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        repo = rel.split("/", 1)[0]
        svc = services.get(repo, nid(M.REPO, repo))
        for m in _IS_VARIANT.finditer(text):
            variant = f"{m.group(1)}.{m.group(2)}"
            line = text.count("\n", 0, m.start()) + 1
            tgt = ext._resolve(variant, kf, "")
            if not tgt:
                continue
            ext.g.add_edge(svc, nid("kt", tgt), M.HANDLES, file=rel, line=line,
                           attrs={"via": "task_dispatch"})
            owner = _decl_at(kf, line)
            if owner:
                ext.g.add_edge(nid("kt", owner.fqn), nid("kt", tgt), M.HANDLES,
                               file=rel, line=line, attrs={"via": "when_branch"})
            ext.stats["variant_dispatch_edges"] += 1


def _link_indirect_responses(ext, services, rk_by_const) -> None:
    """Browser slaves never touch a broker: they call `respondUseCase(JobResponse.X(...))`.

    RespondUseCaseImpl (connector-slave) is what actually publishes, so without
    this hop a browser connector looks like it never answers a job at all.
    """
    rid = rk_by_const.get("PLATFORMS_JOBS_RESPONSE")
    if not rid:
        return
    for rel, kf in ext.kt_files.items():
        repo = rel.split("/", 1)[0]
        svc = services.get(repo, nid(M.REPO, repo))
        for d in kf.decls:
            src = nid("kt", d.fqn)
            if src not in ext.g.nodes:
                continue
            for c in d.calls:
                if c.callee not in ("respondUseCase", "respond") and \
                        not c.callee.startswith("Respond"):
                    continue
                jm = _JOB_CTOR.search(c.args or "")
                if not jm or jm.group(1) != "JobResponse":
                    continue
                variant = f"JobResponse.{jm.group(2)}"
                ext.g.add_edge(svc, rid, M.PUBLISHES, file=rel, line=c.line,
                               attrs={"via": "respondUseCase", "variant": variant,
                                      "indirect": True})
                ext.g.add_edge(src, rid, "publishes_from", file=rel, line=c.line,
                               attrs={"via": "respondUseCase"})
                ext.stats["indirect_publish_edges"] += 1
                tgt = ext._resolve(variant, kf, d.fqn)
                if tgt:
                    ext.g.add_edge(rid, nid("kt", tgt), M.CARRIES, file=rel, line=c.line,
                                   attrs={"direction": "publish", "variant": True})


# --------------------------------------------------------------- other producers
def _link_helm_crons(ext, rk_by_wire) -> None:
    """K8s CronJobs publish over the RabbitMQ management API, not through Kotlin."""
    core = ext.root / "controlresell-core" / "helm" / "controlresell" / "templates" / "jobs"
    if not core.is_dir():
        return
    for f in sorted(core.glob("*.yaml")):
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        keys = set(_HELM_RK.findall(text))
        if not keys:
            continue
        rel = str(f.relative_to(ext.root))
        cid = nid(M.SERVICE, f"cron/{f.stem}")
        ext.g.node(cid, M.SERVICE, f"cron:{f.stem}", repo="controlresell-core",
                   file=rel, attrs={"kind": "cronjob"})
        for k in keys:
            rid = rk_by_wire.get(k)
            if rid:
                ext.g.add_edge(cid, rid, M.PUBLISHES, file=rel,
                               attrs={"via": "rabbitmq-http-api"})
                ext.stats["cron_publish_edges"] += 1


def _link_python(ext, rk_by_wire) -> None:
    """controlresell-vision speaks the same bus with raw string routing keys."""
    consumer = ext.root / "controlresell-vision" / "app" / "mq" / "consumer.py"
    if not consumer.exists():
        return
    rel = str(consumer.relative_to(ext.root))
    text = consumer.read_text(encoding="utf-8", errors="replace")
    svc = _svc_id("VISION")
    ext.g.node(svc, M.SERVICE, "VISION", repo="controlresell-vision")
    ext.g.add_edge(nid(M.REPO, "controlresell-vision"), svc, "runs_as")
    for m in _PY_PUBLISH.finditer(text):
        rid = rk_by_wire.get(m.group(1))
        if rid:
            ext.g.add_edge(svc, rid, M.PUBLISHES, file=rel,
                           line=text.count("\n", 0, m.start()) + 1,
                           attrs={"via": "aio-pika", "lang": "python"})
            ext.stats["py_publish_edges"] += 1
    hm = re.search(r"HANDLERS[^=]*=\s*\{(.*?)\n\}", text, re.S)
    if hm:
        for key in _PY_HANDLERS.findall(hm.group(1)):
            rid = rk_by_wire.get(key)
            if rid:
                ext.g.add_edge(svc, rid, M.SUBSCRIBES, file=rel,
                               attrs={"via": "HANDLERS", "lang": "python"})
                ext.stats["py_subscribe_edges"] += 1
