"""Build the workspace graph from source.

Pass 1 declares every type so that pass 2 can resolve references. Resolution is
import-directed: a bare `Foo` is resolved against the file's own import list
first, then its package, then a global simple-name index. That ordering is what
keeps cross-repo edges honest -- there are several `Account`, `Order` and `Lot`
types in this workspace that mean entirely different things.
"""
from __future__ import annotations

import re
from collections import defaultdict
from pathlib import Path

from . import model as M
from .model import Graph, Node
from .parsers.kotlin import KtDecl, KtFile, new_parser, parse_kotlin
from .parsers.gradle import parse_build_file, parse_catalog, parse_package_json
from .parsers.typescript import new_parsers, parse_typescript
from .freshness import ParseCache
from .workspace import (KOTLIN_EXT, PY_EXT, TS_EXT, Repo, discover, is_test,
                       module_of, source_set, walk_files)

# --- ControlResell conventions ------------------------------------------
# Marks a type as crossing a service boundary. @Zodable additionally means the
# type is code-generated into the TypeScript npm packages the app consumes.
CONTRACT_ANNS = ("Zodable", "Serializable")
GENERATED_ANN = "Zodable"
# @Resource marks a Ktor type-safe route template. Those classes are @Serializable
# too, so without this exclusion 177 route nodes masquerade as wire DTOs.
ROUTE_ANN = "Resource"

# Supertypes whose type argument names the JobPayload variant a class handles.
HANDLER_SUPERS = {
    "TaskHandler", "HandleSlaveTaskUseCase", "HandleTaskUseCase",
    "HandleJobUseCase", "SlaveTaskHandler",
    # the connector-slave runtime's own base class
    "BrowserTaskHandler",
}
KOIN_SCOPES = {"single", "factory", "scoped", "singleOf", "factoryOf", "worker"}

_ID_SAFE = re.compile(r"[^A-Za-z0-9_.:<>,$|-]")


def nid(kind: str, name: str) -> str:
    return f"{kind}:{_ID_SAFE.sub('_', name)}"


class Extractor:
    def __init__(self, root: Path, include_tests: bool = False, verbose: bool = False,
                 cache: ParseCache | None = None):
        self.root = root
        # Parsing is ~85% of build time and most files are unchanged between runs.
        self.cache = cache
        self.g = Graph()
        self.include_tests = include_tests
        self.verbose = verbose
        self.repos: dict[str, Repo] = {}
        # Vendored third-party sources: parsed for completeness, excluded from the
        # contract inventory so they do not drown the ControlResell surface.
        self.vendor_repos = {"kdriver"}
        self.kt_files: dict[str, KtFile] = {}
        self.decl_by_fqn: dict[str, KtDecl] = {}
        self.file_of_fqn: dict[str, str] = {}
        self.simple_index: dict[str, list[str]] = defaultdict(list)
        self.catalogs: dict[str, object] = {}
        self.artifact_owner: dict[str, str] = {}   # coordinate -> "repo:module"
        # repo -> repos it may legally reference, derived from what it actually pins.
        # Symbol resolution is constrained to this so a fallback match cannot invent
        # an edge to a repo the build could never see.
        self.repo_allows: dict[str, set[str]] = defaultdict(set)
        self.published: dict[str, str] = {}        # "group:artifact" -> repo
        self.dup_fqns: set[str] = set()
        self.keys_by_fqn: dict[str, list[str]] = defaultdict(list)
        self.npm_owner: dict[str, str] = {}
        self.stats = defaultdict(int)
        self.ts_index: dict[str, str] = {}
        self.ts_symbol_use: dict[str, list[tuple[str, int, str]]] = defaultdict(list)

    # -- utilities --------------------------------------------------------
    def rel(self, p: Path) -> str:
        return str(p.relative_to(self.root))

    def log(self, *a):
        if self.verbose:
            print(*a)

    # =====================================================================
    # phase 1 - structure
    # =====================================================================
    def scan_workspace(self) -> None:
        self.repos = discover(self.root)
        for r in self.repos.values():
            self.g.node(nid(M.REPO, r.name), M.REPO, r.name, repo=r.name,
                        file=r.path,
                        attrs={"kinds": sorted(r.kinds), "version": r.version,
                               "git_head": r.git_head, "modules": len(r.modules)})
            for m in r.modules.values():
                self.g.node(nid(M.MODULE, f"{r.name}:{m.name}"), M.MODULE, m.name,
                            repo=r.name, module=m.name, file=m.path)
                self.g.add_edge(nid(M.REPO, r.name),
                                nid(M.MODULE, f"{r.name}:{m.name}"), M.CONTAINS)

    def _close_allows(self) -> None:
        """Make the visibility allow-list transitive.

        Gradle `api` dependencies are visible to downstream consumers, so
        connector-vinted legitimately sees kdriver through connector-slave. Treating
        the list as direct-only would reject those references and lose real edges.
        """
        changed = True
        rounds = 0
        while changed and rounds < 12:
            changed = False
            rounds += 1
            for repo, allows in list(self.repo_allows.items()):
                grown = set(allows)
                for a in allows:
                    grown |= self.repo_allows.get(a, set())
                if grown != allows:
                    self.repo_allows[repo] = grown
                    changed = True

    def _collect_pins(self) -> None:
        """Direct repo -> repo visibility, read from every module's build file."""
        for repo in self.repos.values():
            rpath = self.root / repo.path
            cat_path = rpath / "gradle" / "libs.versions.toml"
            cat = parse_catalog(cat_path, self.rel(cat_path)) if cat_path.exists() else None
            self.repo_allows[repo.name].add(repo.name)
            if not cat:
                continue
            for mod in repo.modules.values():
                if not mod.path:
                    continue
                bgk = self.root / mod.path / "build.gradle.kts"
                if not bgk.exists():
                    continue
                for acc, _line, _cfg in parse_build_file(bgk, self.rel(bgk)).lib_refs:
                    entry = cat.by_accessor(acc)
                    if not entry:
                        continue
                    owner = self.published.get(entry.coordinate)
                    if owner:
                        self.repo_allows[repo.name].add(owner)

    def _index_published(self) -> None:
        """Every maven coordinate a workspace repo publishes, regardless of group.

        Needed because not everything here is `com.controlresell` -- kdriver publishes
        under `dev.kdriver`, and its consumers are legitimate.
        """
        for repo in self.repos.values():
            root_build = self.root / repo.path / "build.gradle.kts"
            group = ""
            if root_build.exists():
                m = re.search(r'^\s*group\s*=\s*"([^"]+)"',
                              root_build.read_text(encoding="utf-8", errors="replace"), re.M)
                if m:
                    group = m.group(1)
            for mod in repo.modules.values():
                artifact = Path(mod.path).name if mod.path else mod.name
                if group and artifact:
                    self.published[f"{group}:{artifact}"] = repo.name

    def scan_build_files(self) -> None:
        """Catalogues, module dependencies, published artifacts, npm packages."""
        self._index_published()
        self._collect_pins()
        self._close_allows()
        for repo in self.repos.values():
            rpath = self.root / repo.path
            cat_path = rpath / "gradle" / "libs.versions.toml"
            cat = parse_catalog(cat_path, self.rel(cat_path)) if cat_path.exists() else None
            if cat:
                self.catalogs[repo.name] = cat

            # Which gradle module publishes which maven artifact.
            for mod in repo.modules.values():
                if not mod.path:
                    continue
                bgk = self.root / mod.path / "build.gradle.kts"
                if not bgk.exists():
                    continue
                bf = parse_build_file(bgk, self.rel(bgk))
                artifact_name = Path(mod.path).name
                if "maven" in " ".join(bf.plugin_refs) or "publishing" in bgk.read_text(
                        encoding="utf-8", errors="replace"):
                    # kdriver publishes under dev.kdriver; never assume the group.
                    group = next((k.split(":", 1)[0] for k, v in self.published.items()
                                  if v == repo.name and k.endswith(f":{artifact_name}")),
                                 "com.controlresell")
                    coord = f"{group}:{artifact_name}"
                    mod.artifact = coord
                    self.artifact_owner[coord] = f"{repo.name}:{mod.name}"
                    a = self.g.node(nid(M.ARTIFACT, coord), M.ARTIFACT, artifact_name,
                                    repo=repo.name, module=mod.name, file=self.rel(bgk),
                                    attrs={"coordinate": coord,
                                           "version": bf.version or repo.version})
                    self.g.add_edge(nid(M.MODULE, f"{repo.name}:{mod.name}"),
                                    a.id, "publishes_artifact", file=self.rel(bgk))
                if bf.npm_package:
                    n = self.g.node(nid(M.NPM, bf.npm_package), M.NPM, bf.npm_package,
                                    repo=repo.name, module=mod.name, file=self.rel(bgk))
                    self.npm_owner[bf.npm_package] = f"{repo.name}:{mod.name}"
                    self.g.add_edge(nid(M.MODULE, f"{repo.name}:{mod.name}"),
                                    n.id, "publishes_npm", file=self.rel(bgk))

                src_id = nid(M.MODULE, f"{repo.name}:{mod.name}")
                self.repo_allows[repo.name].add(repo.name)
                for acc, line, cfg in bf.lib_refs:
                    entry = cat.by_accessor(acc) if cat else None
                    if not entry:
                        continue
                    owner = self.published.get(entry.coordinate)
                    if owner:
                        self.repo_allows[repo.name].add(owner)
                    if entry.group != "com.controlresell":
                        continue
                    coord = entry.coordinate
                    dst = self.g.node(nid(M.ARTIFACT, coord), M.ARTIFACT,
                                      coord.split(":")[1],
                                      attrs={"coordinate": coord})
                    self.g.add_edge(src_id, dst.id, M.DEPENDS_ON,
                                    file=self.rel(bgk), line=line,
                                    attrs={"version": entry.version, "config": cfg,
                                           "alias": entry.alias})
                    self.stats["artifact_deps"] += 1
                for proj, line, cfg in bf.project_refs:
                    other = proj.lstrip(":")
                    if other in repo.modules:
                        self.g.add_edge(src_id, nid(M.MODULE, f"{repo.name}:{other}"),
                                        M.DEPENDS_ON, file=self.rel(bgk), line=line,
                                        attrs={"config": cfg, "kind": "project"})
                        mod.project_deps.append(other)

            # (closure is applied after every repo has been read; see _close_allows)
            for allowed in sorted(self.repo_allows.get(repo.name, set())):
                if allowed != repo.name and allowed in self.repos:
                    self.g.add_edge(nid(M.REPO, repo.name), nid(M.REPO, allowed),
                                    M.DEPENDS_ON, attrs={"via": "maven"})

            # npm packages declared in this repo
            for pj in [rpath / "package.json"] + list(rpath.glob("*/*/package.json")):
                if not pj.exists() or "node_modules" in str(pj):
                    continue
                info = parse_package_json(pj, self.rel(pj))
                if not info or not info.get("name"):
                    continue
                pkg_id = nid(M.NPM, info["name"])
                self.g.node(pkg_id, M.NPM, info["name"], repo=repo.name,
                            file=info["path"],
                            attrs={"version": info["version"], "private": info["private"]})
                self.g.add_edge(nid(M.REPO, repo.name), pkg_id, M.CONTAINS)
                for dep, meta in info["deps"].items():
                    if not dep.startswith("controlresell"):
                        continue
                    dep_id = nid(M.NPM, dep)
                    self.g.node(dep_id, M.NPM, dep)
                    self.g.add_edge(pkg_id, dep_id, M.DEPENDS_ON, file=info["path"],
                                    attrs={"range": meta["range"], "scope": meta["scope"]})
                    self.stats["npm_deps"] += 1

    # =====================================================================
    # phase 2 - kotlin declarations
    # =====================================================================
    def scan_kotlin(self) -> None:
        """Parse every file first, then declare.

        The two phases exist because a handful of fully-qualified names are declared
        in more than one repo — two services carrying their own copy of the same
        `…infrastructure.redis.RedisService`, say. Those must not collapse into a single
        node, and that can only be known once everything has been parsed.
        """
        parser = new_parser()
        order: list[tuple] = []
        owners: dict[str, set[str]] = defaultdict(set)
        for repo in self.repos.values():
            if "kotlin" not in repo.kinds:
                continue
            for path in walk_files(self.root, KOTLIN_EXT, self.root / repo.path):
                rel = self.rel(path)
                if not self.include_tests and is_test(rel):
                    self.stats["kt_skipped_test"] += 1
                    continue
                try:
                    st = path.stat()
                    stamp = (st.st_mtime_ns, st.st_size)
                except OSError:
                    continue
                kf = self.cache.get(rel, stamp) if self.cache else None
                if kf is None:
                    try:
                        kf = parse_kotlin(rel, path.read_bytes(), parser)
                    except OSError:
                        continue
                    if self.cache:
                        self.cache.put(rel, stamp, kf)
                    self.stats["kt_parsed"] += 1
                else:
                    self.stats["kt_cached"] += 1
                self.kt_files[rel] = kf
                self.stats["kt_files"] += 1
                self.stats["kt_parse_errors"] += 1 if kf.parse_errors else 0
                mod = module_of(repo, rel)
                order.append((kf, repo, mod, rel))
                for d in kf.decls:
                    # Key by repo AND module: connector-vinted declares
                    # HandlePostsGetUseCase as an interface in one module and a class
                    # in another, under one fully-qualified name.
                    owners[d.fqn].add(f"{repo.name}/{mod}")

        self.dup_fqns = {f for f, rs in owners.items() if len(rs) > 1}
        self.stats["duplicate_fqns"] = len(self.dup_fqns)
        for kf, repo, mod, rel in order:
            for d in kf.decls:
                self._declare(d, kf, repo, mod, rel)
            self._declare_top_functions(kf, repo, mod, rel)

    def _declare_top_functions(self, kf: KtFile, repo: Repo, mod: str, rel: str) -> None:
        """Top-level functions that actually do something get a node of their own."""
        for fn in kf.top_functions:
            if not fn.calls or not fn.name:
                continue
            fqn = f"{kf.package}.{fn.name}" if kf.package else fn.name
            key = self._key(fqn, repo.name, mod)
            self.g.node(nid("kt", key), M.FUNCTION, fn.name, repo=repo.name, module=mod,
                        file=rel, line=fn.line,
                        attrs={"top_level": True, "package": kf.package,
                               "params": [p.type for p in fn.params][:8]})
            self.file_of_fqn[key] = rel
            self.keys_by_fqn[fqn].append(key)
            self.simple_index[fn.name].append(key)
            if mod:
                self.g.add_edge(nid(M.MODULE, f"{repo.name}:{mod}"), nid("kt", key),
                                M.CONTAINS)
            self.stats["kt_top_functions"] += 1

    def _key(self, fqn: str, repo: str, mod: str = "") -> str:
        """Node key: qualified by repo/module only when the FQN is ambiguous."""
        return f"{repo}/{mod}|{fqn}" if fqn in self.dup_fqns else fqn

    def _key_for(self, fqn: str, from_rel: str) -> str | None:
        """Resolve an FQN to a declared key, preferring the caller's own repo."""
        if fqn in self.decl_by_fqn:
            return fqn
        cands = self.keys_by_fqn.get(fqn)
        if not cands:
            return None
        src_repo = from_rel.split("/", 1)[0] if from_rel else ""
        for c in cands:
            if c.split("|", 1)[0].split("/", 1)[0] == src_repo:
                return c
        return cands[0]

    def _declare(self, d: KtDecl, kf: KtFile, repo: Repo, mod: str, rel: str) -> None:
        fqn = self._key(d.fqn, repo.name, mod)
        is_route = d.has_ann(ROUTE_ANN)
        is_contract = d.has_ann(*CONTRACT_ANNS) and not is_route
        generated = d.has_ann(GENERATED_ANN)
        kind = M.CLASS
        if d.kind == "interface":
            kind = M.INTERFACE
        elif d.kind == "enum":
            kind = M.ENUM
        elif d.kind == "object":
            kind = M.OBJECT
        if is_contract and d.kind in ("class", "object"):
            kind = M.DTO
        if is_route:
            kind = M.HTTP_ROUTE
        if d.parent and any(s.name == d.parent.split(".")[-1] for s in d.supers):
            kind = M.VARIANT          # a sealed-hierarchy member

        attrs = {
            "modifiers": d.modifiers,
            "annotations": [a.name for a in d.annotations],
            "source_set": source_set(rel),
            "package": kf.package,
        }
        # The team documents heavily (7.8k KDoc blocks); carrying it turns a purely
        # structural node into one that can say what the thing is for.
        if d.doc:
            attrs["doc"] = d.doc[:600]
        fn_docs = {f.name: f.doc for f in d.functions if f.doc}
        if fn_docs:
            attrs["fn_docs"] = {k: v[:280] for k, v in list(fn_docs.items())[:24]}
        # Preconditions that stop this class early. Most "why didn't X happen"
        # questions bottom out in one of these.
        guards = [{"fn": f.name, "kind": gd.kind, "cond": gd.condition,
                   "line": gd.line, "result": gd.result, "scope": gd.scope}
                  for f in d.functions for gd in f.guards]
        # Function-scope exits first: those are the ones that stop the work.
        guards.sort(key=lambda x: (x["scope"] != "function", x["line"]))
        if guards:
            attrs["guards"] = guards[:30]
        if is_route:
            r = d.ann(ROUTE_ANN)
            attrs["template"] = (r.first_string() if r else "") or ""
            for p in d.ctor_params:
                if p.name == "parent":
                    attrs["parent_resource"] = p.type
        if is_contract:
            attrs["contract"] = True
            attrs["generated_ts"] = generated
            # Published contract modules are the only ones another service compiles
            # against; a @Serializable elsewhere is an internal model (a marketplace
            # API shape, a CDP binding) that never crosses a ControlResell boundary.
            attrs["contract_surface"] = mod.endswith(("-commons", "-api"))
            # A @Serializable that is not @Zodable still crosses services (it is a
            # RabbitMQ body) but never reaches TypeScript.
            attrs["jvm_only"] = not generated
            attrs["fields"] = [
                {"n": p.name, "t": p.type, "null": p.nullable, "def": p.has_default,
                 **({"doc": p.doc[:200]} if p.doc else {})}
                for p in d.ctor_params if p.name
            ]
        sn = d.ann("SerialName")
        if sn:
            v = sn.first_string()
            if v:
                attrs["serial_name"] = v
        if d.kind == "enum":
            attrs["entries"] = [e[0] for e in d.enum_entries]
        if "sealed" in d.modifiers:
            attrs["sealed"] = True
        if not is_contract and d.ctor_params:
            attrs["ctor"] = [{"n": p.name, "t": p.type} for p in d.ctor_params if p.name]
        if d.functions:
            attrs["functions"] = [f.name for f in d.functions][:30]
        # Only a handler whose own `invoke` does nothing counts as a stub.
        inv = [f for f in d.functions if f.name == "invoke"]
        if inv and all(f.stub for f in inv):
            attrs["stub"] = inv[0].stub

        self.g.node(nid("kt", fqn), kind, d.name, repo=repo.name, module=mod,
                    file=rel, line=d.line, attrs=attrs)
        self.decl_by_fqn[fqn] = d
        self.file_of_fqn[fqn] = rel
        self.simple_index[d.name].append(fqn)
        self.keys_by_fqn[d.fqn].append(fqn)
        if mod:
            self.g.add_edge(nid(M.MODULE, f"{repo.name}:{mod}"), nid("kt", fqn),
                            M.CONTAINS)
        self.stats["kt_decls"] += 1

    # =====================================================================
    # phase 3 - resolve references into edges
    # =====================================================================
    def _allowed(self, from_rel: str, fqn: str) -> bool:
        """May a file in one repo legally reference a type declared in another?

        `controlresell-connector-vinted` and `-vinted-ws` share the
        `com.controlresell.connector.vinted` package prefix, so package-based
        resolution silently jumps between them unless the build graph says no.
        """
        src_repo = from_rel.split("/", 1)[0] if from_rel else ""
        dst_rel = self.file_of_fqn.get(fqn, "")
        dst_repo = dst_rel.split("/", 1)[0] if dst_rel else ""
        if not src_repo or not dst_repo or src_repo == dst_repo:
            return True
        allows = self.repo_allows.get(src_repo)
        return dst_repo in allows if allows else True

    def _resolve(self, simple: str, kf: KtFile, from_fqn: str = "") -> str | None:
        """Resolve a bare type name to an FQN, import list first."""
        simple = simple.strip()
        if not simple or simple[0].islower():
            return None
        rel = kf.path
        head = simple.split(".")[0]
        # 1. explicit import
        for imp in kf.imports:
            if imp.rsplit(".", 1)[-1] == head:
                cand = imp if "." not in simple else f"{imp}.{simple.split('.', 1)[1]}"
                k = self._key_for(cand, rel)
                if k:
                    return k
                if "." not in simple:
                    k = self._key_for(imp, rel)
                    if k:
                        return k
        # 1b. The file explicitly imports this simple name, but the import points
        # outside the workspace (java.awt.Color, org.opencv.core.Rect). The name is
        # taken -- falling through to a same-package or global match would resolve it
        # to an unrelated workspace type of the same name.
        for imp in kf.imports:
            if imp.rsplit(".", 1)[-1] == head and not imp.startswith("com.controlresell"):
                if self._key_for(imp, rel) is None:
                    return None

        # 2. same package (covers nested `Outer.Inner` too)
        if kf.package:
            k = self._key_for(f"{kf.package}.{simple}", rel)
            if k and self._allowed(rel, k):
                return k
        # 3. enclosing type, for a nested reference from a sibling
        if from_fqn and "." in from_fqn:
            k = self._key_for(f"{from_fqn.rsplit('.', 1)[0]}.{simple}", rel)
            if k and self._allowed(rel, k):
                return k
        # 4. Globally unique simple name -- the weakest rule, so it is switched off
        # for files carrying a wildcard import from outside the workspace
        # (`import org.opencv.core.*` makes any bare `Rect` ambiguous).
        # A wildcard import from outside the workspace makes any bare name ambiguous
        # (`import org.opencv.core.*` and a `Rect` in kdriver). Suppress only the
        # cross-repo match: a same-repo fallback is still trustworthy, and blanket
        # suppression would discard ~1.8k good edges over `kotlinx.coroutines.*`.
        ext_star = any(not i.startswith("com.controlresell") for i in kf.star_imports)
        src_repo = rel.split("/", 1)[0] if rel else ""

        def ok(cand: str) -> bool:
            if not self._allowed(rel, cand):
                return False
            if not ext_star:
                return True
            dst = self.file_of_fqn.get(cand, "")
            return dst.split("/", 1)[0] == src_repo

        hits = self.simple_index.get(simple.split(".")[-1] if "." in simple else simple, [])
        if len(hits) == 1 and ok(hits[0]):
            return hits[0]
        if simple in self.simple_index and len(self.simple_index[simple]) == 1:
            cand = self.simple_index[simple][0]
            if ok(cand):
                return cand
        return None

    def link_contract_imports(self) -> None:
        """An import of a contract type is a use of it.

        Supertypes, constructor parameters and call sites miss a type used only inside
        a function body or as an extension receiver — which is most of how `JobPost`
        and friends are actually consumed. The import list catches those exactly,
        because Kotlin requires the import to be there.
        """
        for rel, kf in self.kt_files.items():
            if not kf.imports:
                continue
            # Only top-level declarations. Attaching to nested ones multiplies a single
            # import by the number of sealed variants in the file (~12x on JobPayload).
            holders = [nid("kt", d.fqn) for d in kf.decls
                       if not d.parent and nid("kt", d.fqn) in self.g.nodes]
            if not holders:
                repo = rel.split("/", 1)[0]
                holders = [nid(M.REPO, repo)]
            for imp in kf.imports:
                key = self._key_for(imp, rel)
                if not key or not self._allowed(rel, key):
                    continue
                node = self.g.nodes.get(nid("kt", key))
                if node is None or not node.attrs.get("contract"):
                    continue
                for h in holders:
                    if h == nid("kt", key):
                        continue
                    self.g.add_edge(h, nid("kt", key), M.REFERENCES,
                                    file=rel, attrs={"via": "import"})
                    self.stats["import_reference_edges"] += 1

    def link_kotlin(self) -> None:
        for rel, kf in self.kt_files.items():
            for d in kf.decls:
                src = nid("kt", d.fqn)
                if src not in self.g.nodes:
                    continue
                # supertypes
                for s in d.supers:
                    dst_fqn = self._resolve(s.name, kf, d.fqn)
                    kind = M.EXTENDS if s.is_constructor_call else M.IMPLEMENTS
                    if dst_fqn:
                        self.g.add_edge(src, nid("kt", dst_fqn), kind,
                                        file=rel, line=d.line,
                                        attrs={"type_args": s.type_args} if s.type_args else {})
                        self.stats["super_edges"] += 1
                    # handler-of-payload: TaskHandler<JobPayload.PostsBoost>
                    if s.name in HANDLER_SUPERS and s.type_args:
                        for ta in s.type_args:
                            t = self._resolve(ta, kf, d.fqn)
                            if t:
                                self.g.add_edge(src, nid("kt", t), M.HANDLES,
                                                file=rel, line=d.line,
                                                attrs={"via": s.name})
                                self.stats["handles_edges"] += 1
                # constructor injection
                for p in d.ctor_params:
                    base = p.type.split("<")[0]
                    dst_fqn = self._resolve(base, kf, d.fqn)
                    if dst_fqn and dst_fqn != d.fqn:
                        self.g.add_edge(src, nid("kt", dst_fqn), M.INJECTS,
                                        file=rel, line=d.line,
                                        attrs={"param": p.name, "type": p.type})
                        self.stats["inject_edges"] += 1
                # Function signatures. Every use case here is `operator fun invoke(...)`,
                # so a domain type most often flows through a parameter or return type
                # rather than through a constructor -- without this, `impact` misses
                # the dominant path.
                for fn in d.functions:
                    sig_types = [p.type for p in fn.params if p.type]
                    if fn.returns:
                        sig_types.append(fn.returns)
                    for t in sig_types:
                        for atom in _type_atoms(t):
                            dst_fqn = self._resolve(atom, kf, d.fqn)
                            if dst_fqn and dst_fqn != d.fqn:
                                self.g.add_edge(src, nid("kt", dst_fqn), M.REFERENCES,
                                                file=rel, line=fn.line,
                                                attrs={"via": "signature",
                                                       "fn": fn.name})
                                self.stats["signature_edges"] += 1

                # DTO field types -> other DTOs
                node = self.g.nodes[src]
                if node.attrs.get("contract"):
                    for p in d.ctor_params:
                        for t in _type_atoms(p.type):
                            dst_fqn = self._resolve(t, kf, d.fqn)
                            if dst_fqn and dst_fqn != d.fqn and \
                                    self.g.nodes.get(nid("kt", dst_fqn), Node("", "", "")).attrs.get("contract"):
                                self.g.add_edge(src, nid("kt", dst_fqn), M.FIELD_OF,
                                                file=rel, line=d.line,
                                                attrs={"field": p.name})
                # Call edges. Two shapes, because use cases are `operator fun invoke`
                # interfaces: a dependency call reads `getItemUseCase(id)` -- a bare
                # lowercase identifier that is really a constructor parameter -- while
                # a direct construction reads `GetItemUseCaseImpl(...)`.
                symtab: dict[str, str] = {}
                for p in d.ctor_params:
                    if not p.name or not p.type:
                        continue
                    t = self._resolve(p.type.split("<")[0], kf, d.fqn)
                    if t:
                        symtab[p.name] = t
                for p in d.properties:
                    if p.name and p.type:
                        t = self._resolve(p.type.split("<")[0], kf, d.fqn)
                        if t:
                            symtab.setdefault(p.name, t)
                for c in d.calls:
                    if not c.callee:
                        continue
                    if c.callee[0].isupper():
                        dst_fqn = self._resolve(c.callee, kf, d.fqn)
                        via = "construct"
                    elif not c.receiver and c.callee in symtab:
                        dst_fqn = symtab[c.callee]
                        via = "invoke"
                    elif c.receiver and c.receiver.split(".")[-1] in symtab:
                        dst_fqn = symtab[c.receiver.split(".")[-1]]
                        via = f"method:{c.callee}"
                    else:
                        continue
                    if dst_fqn and dst_fqn != d.fqn:
                        self.g.add_edge(src, nid("kt", dst_fqn), M.CALLS,
                                        file=rel, line=c.line, attrs={"via": via})
                        self.stats[f"call_edges_{via.split(':')[0]}"] += 1

    # =====================================================================
    # phase 4 - dependency injection bindings
    # =====================================================================
    def scan_koin(self) -> None:
        """Koin `single<Iface> { Impl(...) }` -> a BINDS edge.

        Only files that plausibly hold a DI module are re-parsed, which keeps
        this pass cheap; a binding declared elsewhere is simply not indexed.
        """
        from .parsers.koin import extract_bindings
        parser = new_parser()
        for rel, kf in self.kt_files.items():
            name = Path(rel).name
            if not (name.endswith("Module.kt") or "/di/" in rel or "/koin/" in rel.lower()):
                continue
            try:
                src = (self.root / rel).read_bytes()
            except OSError:
                continue
            repo_name = rel.split("/", 1)[0]
            repo = self.repos.get(repo_name)
            mod = module_of(repo, rel) if repo else ""
            module_id = nid(M.MODULE, f"{repo_name}:{mod}") if mod else nid(M.REPO, repo_name)
            for b in extract_bindings(src, parser):
                impl_fqn = self._resolve(b.impl, kf)
                iface_fqn = self._resolve(b.interface, kf) if b.interface else None
                self.stats["koin_bindings"] += 1
                if iface_fqn and impl_fqn:
                    self.g.add_edge(nid("kt", iface_fqn), nid("kt", impl_fqn), M.BINDS,
                                    file=rel, line=b.line,
                                    attrs={"scope": b.scope, "args": b.args,
                                           "qualifier": b.qualifier})
                    self.stats["bind_edges"] += 1
                if impl_fqn:
                    self.g.add_edge(module_id, nid("kt", impl_fqn), "wires",
                                    file=rel, line=b.line, attrs={"scope": b.scope})

    # =====================================================================
    # phase 5 - typescript client
    # =====================================================================
    def scan_typescript(self) -> None:
        """App-side consumption of the generated contract packages.

        An import of `Template` from 'controlresell' is the app end of a wire
        contract, so it is linked straight back to the Kotlin declaration that
        generated it -- which is what makes "who consumes this DTO" answerable
        across the language boundary.
        """
        pts, ptsx = new_parsers()
        for repo in self.repos.values():
            if "ts" not in repo.kinds:
                continue
            for path in walk_files(self.root, TS_EXT, self.root / repo.path):
                rel = self.rel(path)
                if not self.include_tests and (".test." in rel or ".spec." in rel):
                    continue
                try:
                    st = path.stat()
                    stamp = (st.st_mtime_ns, st.st_size)
                except OSError:
                    continue
                tf = self.cache.get(rel, stamp) if self.cache else None
                if tf is None:
                    try:
                        tf = parse_typescript(rel, path.read_bytes(),
                                              ptsx if rel.endswith(".tsx") else pts,
                                              tsx=rel.endswith(".tsx"))
                    except OSError:
                        continue
                    if self.cache:
                        self.cache.put(rel, stamp, tf)
                    self.stats["ts_parsed"] += 1
                else:
                    self.stats["ts_cached"] += 1
                self.stats["ts_files"] += 1
                declared: list[str] = []
                for d in tf.decls:
                    if not d.exported and d.kind not in ("class", "interface"):
                        continue
                    n = self.g.node(nid("ts", f"{rel}#{d.name}"),
                                    M.INTERFACE if d.kind == "interface" else M.CLASS,
                                    d.name, repo=repo.name, file=rel, line=d.line,
                                    attrs={"lang": "ts", "kind": d.kind,
                                           "methods": d.methods[:40]})
                    self.g.add_edge(nid(M.REPO, repo.name), n.id, M.CONTAINS)
                    declared.append(n.id)
                    for base in d.extends + d.implements:
                        hit = self.ts_index.get(base)
                        if hit:
                            self.g.add_edge(n.id, hit, M.IMPLEMENTS, file=rel, line=d.line)
                    self.ts_index[d.name] = n.id
                for imp in tf.imports:
                    if not imp.source.startswith("controlresell"):
                        continue
                    pkg_id = nid(M.NPM, imp.source)
                    self.g.node(pkg_id, M.NPM, imp.source)
                    # `declared` holds the ids actually emitted for this file; using
                    # decls[0] blindly produced edges from nodes that never existed.
                    holder = declared[0] if declared else nid(M.REPO, repo.name)
                    self.g.add_edge(holder, pkg_id, M.DEPENDS_ON, file=rel, line=imp.line,
                                    attrs={"names": imp.names[:20], "type_only": imp.type_only})
                    for sym in imp.names:
                        self.ts_symbol_use[sym].append((rel, imp.line, holder))
                    self.stats["ts_contract_imports"] += 1

    def link_typescript_contracts(self) -> None:
        """Bridge TS symbol names to the Kotlin declarations they were generated from."""
        for sym, uses in self.ts_symbol_use.items():
            base = sym[:-6] if sym.endswith("Schema") else sym
            hits = self.simple_index.get(base, [])
            targets = [h for h in hits
                       if self.g.nodes.get(nid("kt", h), Node("", "", "")).attrs.get("generated_ts")]
            if len(targets) != 1:
                if len(targets) > 1:
                    self.stats["ts_ambiguous"] += 1
                else:
                    self.stats["ts_unmatched"] += 1
                continue
            kt_id = nid("kt", targets[0])
            for rel, line, holder in uses:
                self.g.add_edge(holder, kt_id, M.REFERENCES, file=rel, line=line,
                                attrs={"symbol": sym})
                self.stats["ts_reference_edges"] += 1

    # =====================================================================
    # phase 6 - python services
    # =====================================================================
    def scan_python(self) -> None:
        """FastAPI route declarations, so vision's HTTP surface is on the graph."""
        import ast as _ast
        for repo in self.repos.values():
            if "python" not in repo.kinds:
                continue
            for path in walk_files(self.root, PY_EXT, self.root / repo.path):
                rel = self.rel(path)
                try:
                    tree = _ast.parse(path.read_text(encoding="utf-8", errors="replace"))
                except (SyntaxError, OSError):
                    continue
                self.stats["py_files"] += 1
                for node in _ast.walk(tree):
                    if not isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef)):
                        continue
                    for dec in node.decorator_list:
                        if not isinstance(dec, _ast.Call):
                            continue
                        fn = dec.func
                        if not isinstance(fn, _ast.Attribute):
                            continue
                        method = fn.attr.lower()
                        if method not in ("get", "post", "put", "patch", "delete"):
                            continue
                        route = ""
                        if dec.args and isinstance(dec.args[0], _ast.Constant):
                            route = str(dec.args[0].value)
                        if not route:
                            continue
                        rid = nid(M.HTTP_ROUTE, f"{repo.name}:{method.upper()} {route}")
                        self.g.node(rid, M.HTTP_ROUTE, f"{method.upper()} {route}",
                                    repo=repo.name, file=rel, line=node.lineno,
                                    attrs={"handler": node.name, "lang": "python",
                                           "path": route, "verb": method.upper()})
                        self.g.add_edge(nid(M.REPO, repo.name), rid, M.EXPOSES,
                                        file=rel, line=node.lineno)
                        self.stats["py_routes"] += 1


_ATOM = re.compile(r"[A-Za-z_][A-Za-z0-9_.]*")
_PRIMITIVES = {
    "String", "Int", "Long", "Double", "Float", "Boolean", "Byte", "Short", "Char",
    "Unit", "Any", "Nothing", "List", "Map", "Set", "Array", "Collection", "Pair",
    "Triple", "Instant", "LocalDate", "LocalDateTime", "Uuid", "UUID", "BigDecimal",
    "ByteArray", "Number", "Comparable", "Result",
}


def _type_atoms(t: str) -> list[str]:
    """Every capitalised identifier inside a rendered type, primitives dropped."""
    return [a for a in _ATOM.findall(t or "")
            if a and a[0].isupper() and a.split(".")[0] not in _PRIMITIVES]
