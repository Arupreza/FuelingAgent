"""Graph model: nodes, edges, and the container that owns them.

Everything the extractors produce lands here. The model is deliberately flat and
string-keyed so the whole graph serialises to JSON without custom encoders.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from typing import Any, Iterable, Iterator


# --- node kinds -------------------------------------------------------------
# Structural
REPO = "repo"
MODULE = "module"          # a gradle module / npm workspace package
ARTIFACT = "artifact"      # a published maven coordinate
NPM = "npm"                # a published npm package
SERVICE = "service"        # a deployable runtime service

# Code
CLASS = "class"
INTERFACE = "interface"
OBJECT = "object"
ENUM = "enum"
DTO = "dto"                # a wire contract (@Zodable / @Serializable)
VARIANT = "variant"        # a sealed-class variant (JobPayload.PostsCreate)
FUNCTION = "function"

# Contracts
ROUTING_KEY = "routing_key"
QUEUE = "queue"
HTTP_ROUTE = "http_route"
TABLE = "table"

# --- edge kinds -------------------------------------------------------------
DEPENDS_ON = "depends_on"      # module -> artifact/npm, repo -> repo
CONTAINS = "contains"          # repo -> module -> class
EXTENDS = "extends"
IMPLEMENTS = "implements"
INJECTS = "injects"            # class -> class, via constructor parameter
CALLS = "calls"                # function/class -> function/class
PUBLISHES = "publishes"        # service -> routing_key
SUBSCRIBES = "subscribes"      # service -> routing_key
CARRIES = "carries"            # routing_key -> dto
HANDLES = "handles"            # handler class -> sealed variant
EXPOSES = "exposes"            # service -> http_route
CALLS_HTTP = "calls_http"      # service -> service
REFERENCES = "references"      # ts symbol -> generated contract type
BINDS = "binds"                # koin: interface -> impl
FIELD_OF = "field_of"          # dto -> dto, via a property type


@dataclass
class Node:
    id: str                       # stable, unique: "kind:qualified.name"
    kind: str
    name: str                     # short display name
    repo: str = ""
    module: str = ""
    file: str = ""                # workspace-relative
    line: int = 0
    attrs: dict[str, Any] = field(default_factory=dict)

    def loc(self) -> str:
        return f"{self.file}:{self.line}" if self.file else ""


@dataclass
class Edge:
    src: str
    dst: str
    kind: str
    file: str = ""
    line: int = 0
    attrs: dict[str, Any] = field(default_factory=dict)

    def key(self) -> tuple:
        return (self.src, self.dst, self.kind, self.file, self.line)


class Graph:
    """Append-only store. Duplicate node ids merge; duplicate edges collapse."""

    def __init__(self) -> None:
        self.nodes: dict[str, Node] = {}
        self._edges: dict[tuple, Edge] = {}
        self.unresolved: list[Edge] = []   # edges whose dst was never declared
        self._by_src: dict[str, list[Edge]] | None = None
        self._by_dst: dict[str, list[Edge]] | None = None

    # -- writing ---------------------------------------------------------
    def add_node(self, node: Node) -> Node:
        prev = self.nodes.get(node.id)
        if prev is None:
            self.nodes[node.id] = node
            return node
        # Merge: prefer the entry that carries a source location.
        if not prev.file and node.file:
            prev.file, prev.line = node.file, node.line
            prev.repo = prev.repo or node.repo
            prev.module = prev.module or node.module
        for k, v in node.attrs.items():
            prev.attrs.setdefault(k, v)
        return prev

    def node(self, id: str, kind: str, name: str, **kw) -> Node:
        return self.add_node(Node(id=id, kind=kind, name=name, **kw))

    def add_edge(self, src: str, dst: str, kind: str, **kw) -> None:
        e = Edge(src=src, dst=dst, kind=kind, **kw)
        self._edges.setdefault(e.key(), e)
        self._by_src = self._by_dst = None      # invalidate; rebuilt lazily on read

    def _index(self) -> None:
        by_src: dict[str, list[Edge]] = {}
        by_dst: dict[str, list[Edge]] = {}
        for e in self._edges.values():
            by_src.setdefault(e.src, []).append(e)
            by_dst.setdefault(e.dst, []).append(e)
        self._by_src, self._by_dst = by_src, by_dst

    @property
    def edges(self) -> list[Edge]:
        return list(self._edges.values())

    # -- reading ---------------------------------------------------------
    def by_kind(self, *kinds: str) -> list[Node]:
        ks = set(kinds)
        return [n for n in self.nodes.values() if n.kind in ks]

    def out_edges(self, nid: str, *kinds: str) -> list[Edge]:
        if self._by_src is None:
            self._index()
        ks = set(kinds)
        return [e for e in self._by_src.get(nid, ()) if not ks or e.kind in ks]

    def in_edges(self, nid: str, *kinds: str) -> list[Edge]:
        if self._by_dst is None:
            self._index()
        ks = set(kinds)
        return [e for e in self._by_dst.get(nid, ()) if not ks or e.kind in ks]

    def resolve(self) -> None:
        """Move edges pointing at undeclared nodes onto `unresolved`.

        Cross-repo edges legitimately point at types declared in a *published
        artifact* rather than in any checked-out source, so an unresolved edge
        is information, not an error.
        """
        keep, drop = {}, []
        for k, e in self._edges.items():
            if e.dst in self.nodes:
                keep[k] = e
            else:
                drop.append(e)
        self._edges = keep
        self.unresolved = drop
        self._by_src = self._by_dst = None

    # -- serialising ------------------------------------------------------
    def to_dict(self, include_unresolved: bool = False) -> dict:
        d = {
            "nodes": [asdict(n) for n in self.nodes.values()],
            "edges": [asdict(e) for e in self._edges.values()],
        }
        if include_unresolved:
            d["unresolved"] = [asdict(e) for e in self.unresolved]
        return d

    def dump(self, path, compact: bool = True, include_unresolved: bool = False) -> int:
        payload = self.to_dict(include_unresolved)
        text = (json.dumps(payload, separators=(",", ":"))
                if compact else json.dumps(payload, indent=1))
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(text)
        return len(text)

    @classmethod
    def load(cls, path) -> "Graph":
        with open(path, encoding="utf-8") as fh:
            d = json.load(fh)
        g = cls()
        for n in d["nodes"]:
            g.nodes[n["id"]] = Node(**n)
        for e in d["edges"]:
            edge = Edge(**e)
            g._edges[edge.key()] = edge
        for e in d.get("unresolved", []):
            g.unresolved.append(Edge(**e))
        return g

    def stats(self) -> dict[str, Any]:
        nk: dict[str, int] = {}
        for n in self.nodes.values():
            nk[n.kind] = nk.get(n.kind, 0) + 1
        ek: dict[str, int] = {}
        for e in self._edges.values():
            ek[e.kind] = ek.get(e.kind, 0) + 1
        return {"nodes": len(self.nodes), "edges": len(self._edges),
                "by_node_kind": dict(sorted(nk.items(), key=lambda x: -x[1])),
                "by_edge_kind": dict(sorted(ek.items(), key=lambda x: -x[1])),
                "unresolved": len(self.unresolved)}
