"""Koin DI binding extraction.

Needs its own tree walk because the tree-sitter Kotlin grammar cannot resolve the
`single<Iface> { Impl() }` form: without type information `single<Iface>` is
indistinguishable from a chain of less-than comparisons, so the grammar emits

    binary_expression(binary_expression(identifier single, identifier Iface),
                      lambda_literal(call_expression(identifier Impl)))

That mis-parse is *deterministic*, so matching the shape recovers the binding
exactly. The parenthesised forms -- `single { Impl() }`, `single(named<X>()) { }`
-- parse correctly as call_expression and are handled alongside.
"""
from __future__ import annotations

from dataclasses import dataclass

import tree_sitter_kotlin as tsk
from tree_sitter import Language, Parser

_LANG = Language(tsk.language())

SCOPE_FNS = {"single", "factory", "scoped", "singleOf", "factoryOf", "worker", "viewModel"}


@dataclass
class Binding:
    scope: str            # single | factory | ...
    interface: str        # declared type argument, "" when untyped
    impl: str             # concrete class constructed in the lambda
    qualifier: str        # named<X>() / named("x") qualifier, when present
    args: int             # number of constructor arguments (get() count)
    line: int


def _txt(src: bytes, n) -> str:
    return src[n.start_byte:n.end_byte].decode("utf8", "replace")


def _first_ctor_in_lambda(node, src: bytes) -> tuple[str, int]:
    """First capitalised call inside a lambda body -- the implementation."""
    stack = [node]
    while stack:
        n = stack.pop(0)
        if n.type == "call_expression":
            head = n.children[0] if n.children else None
            if head is not None and head.type in ("identifier", "navigation_expression"):
                name = _txt(src, head).split(".")[-1]
                if name and name[0].isupper():
                    va = None
                    for c in n.children:
                        if c.type == "value_arguments":
                            va = c
                            break
                    nargs = 0
                    if va is not None:
                        nargs = sum(1 for c in va.children if c.type == "value_argument")
                    return name, nargs
        stack.extend(n.children)
    return "", 0


def extract_bindings(src: bytes, parser: Parser | None = None) -> list[Binding]:
    parser = parser or Parser(_LANG)
    tree = parser.parse(src)
    out: list[Binding] = []
    stack = [tree.root_node]
    while stack:
        n = stack.pop()

        # Shape A -- mis-parsed generic form: single<Iface> { Impl(...) }
        if n.type == "binary_expression" and len(n.children) >= 2:
            left = n.children[0]
            lam = next((c for c in n.children
                        if c.type in ("lambda_literal", "annotated_lambda")), None)
            if lam is not None and left.type == "binary_expression":
                kids = [c for c in left.children if c.is_named]
                if len(kids) == 2 and kids[0].type == "identifier":
                    scope = _txt(src, kids[0])
                    if scope in SCOPE_FNS:
                        iface = _txt(src, kids[1]).strip()
                        impl, nargs = _first_ctor_in_lambda(lam, src)
                        if impl:
                            out.append(Binding(scope, iface, impl, "", nargs,
                                               n.start_point[0] + 1))
                            continue

        # Shape B -- correctly parsed: single { Impl(...) } / single(named<X>()) { }
        if n.type == "call_expression":
            head = n.children[0] if n.children else None
            scope = ""
            qualifier = ""
            if head is not None and head.type == "identifier":
                scope = _txt(src, head)
            elif head is not None and head.type == "call_expression":
                h2 = head.children[0] if head.children else None
                if h2 is not None and h2.type == "identifier":
                    scope = _txt(src, h2)
                va = next((c for c in head.children if c.type == "value_arguments"), None)
                if va is not None:
                    qualifier = " ".join(_txt(src, va).split())[:80]
            if scope in SCOPE_FNS:
                lam = next((c for c in n.children
                            if c.type in ("annotated_lambda", "lambda_literal")), None)
                if lam is not None:
                    impl, nargs = _first_ctor_in_lambda(lam, src)
                    if impl:
                        out.append(Binding(scope, "", impl, qualifier, nargs,
                                           n.start_point[0] + 1))

        stack.extend(n.children)
    return out
