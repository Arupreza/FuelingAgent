"""The Exposed data layer — tables, columns, and the DTOs they map to.

Worth indexing precisely because this codebase has NO migration tool: the Table
object *is* the schema, and a DTO field with no matching column is an ALTER TABLE
nobody ran. Getting the SQL name right matters — Exposed keeps the CamelCase object
name verbatim when no explicit name is given, so snake_casing it silently invents
a table that does not exist.
"""
from __future__ import annotations

import re

from . import model as M
from .extract import nid

TABLE_BASES = {"Table", "LongIdTable", "UuidTable", "IntIdTable", "UUIDTable",
               "ULongIdTable", "UIntIdTable", "CompositeIdTable", "IdTable"}
ID_BASES = {"LongIdTable": ("long", "Long"), "UuidTable": ("uuid", "Uuid"),
            "IntIdTable": ("integer", "Int"), "UUIDTable": ("uuid", "Uuid")}

# The 14 builders actually in use; anything else is not a column.
BUILDERS = {
    "varchar": "String", "text": "String", "mediumText": "String", "long": "Long", "integer": "Int",
    "bool": "Boolean", "double": "Double", "decimal": "BigDecimal",
    "timestamp": "Instant", "date": "LocalDate", "uuid": "Uuid",
    "enumerationByName": "enum", "json": "json", "jsonPair": "Pair",
    "binary": "ByteArray", "float": "Float", "short": "Short", "blob": "ByteArray",
    "reference": "ref", "optReference": "ref",
}

_OBJ = re.compile(
    r"^\s*(?:internal\s+)?object\s+(\w+)\s*:\s*(\w*(?:Table|IdTable))\s*\(([^)\n]*)\)", re.M)
_COL_HEAD = re.compile(r"^[ \t]+(?:override\s+)?val\s+(\w+)\s*=\s*(\w+)\s*", re.M)


def _split_generic(text: str, i: int) -> tuple[str, int]:
    """Read a balanced <...> starting at i. Returns (inner, index after '>')."""
    if i >= len(text) or text[i] != "<":
        return "", i
    depth = 0
    for j in range(i, len(text)):
        if text[j] == "<":
            depth += 1
        elif text[j] == ">":
            depth -= 1
            if depth == 0:
                return text[i + 1: j], j + 1
    return "", i


def _columns(body: str):
    """Yield (prop, builder, type_arg, sql_name, tail) for each column declaration."""
    for m in _COL_HEAD.finditer(body):
        prop, builder = m.group(1), m.group(2)
        i = m.end()
        targ, i = _split_generic(body, i)
        while i < len(body) and body[i] in " \t":
            i += 1
        if i >= len(body) or body[i] != "(":
            continue
        j = body.find('"', i)
        if j < 0 or j > i + 4:          # first positional arg must be the SQL name
            continue
        k = body.find('"', j + 1)
        if k < 0:
            continue
        end = body.find("\n", k)
        yield prop, builder, targ, body[j + 1: k], body[k + 1: end if end > 0 else len(body)]
_CONST = re.compile(r"^\s+private\s+const\s+val\s+(\w+)\s*=\s*(\d+)", re.M)
_ENUM_KCLASS = re.compile(r",\s*(\w+)::class")
_MAPPER = re.compile(r"^\s*(?:private\s+|internal\s+)?fun\s+(?:ResultRow\.)?to(\w+)\s*\(", re.M)
# A mapper declared inside the Table object: it maps THAT table, by construction.
_MAPPER_IN_TABLE = re.compile(r"\bfun\s+(?:ResultRow\.)?to([A-Z]\w*)\s*\(")


def link_data_layer(ext) -> None:
    tables = _index_tables(ext)
    _link_mappers(ext, tables)   # fallback: mappers living outside the table object


def _sql_name(obj_name: str, args: str) -> tuple[str, bool]:
    """(sql table name, explicit?). Exposed does NOT snake_case an implicit name."""
    m = re.search(r'"([^"]+)"', args or "")
    if m:
        return m.group(1), True
    return (obj_name[:-5] if obj_name.endswith("Table") else obj_name), False


def _index_tables(ext) -> dict[tuple, str]:
    """Emit a table node per Exposed object. Keyed by (repo, object) — `Orders` exists
    in both backend and wholesale and means entirely different things."""
    out: dict[str, str] = {}
    for rel, kf in ext.kt_files.items():
        if "/tables/" not in rel and "/database/" not in rel and "Table" not in rel:
            continue
        try:
            text = (ext.root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if "Table(" not in text and "IdTable(" not in text:
            continue
        repo = rel.split("/", 1)[0]
        consts = {k: int(v) for k, v in _CONST.findall(text)}
        for om in _OBJ.finditer(text):
            obj, base, args = om.group(1), om.group(2), om.group(3)
            if base not in TABLE_BASES:
                continue
            sql, explicit = _sql_name(obj, args)
            line = text.count("\n", 0, om.start()) + 1
            body = _object_body(text, om.end())
            cols = []
            if base in ID_BASES:
                builder, ktype = ID_BASES[base]
                cols.append({"prop": "id", "col": "id", "type": ktype,
                             "builder": builder, "nullable": False, "pk": True,
                             "implicit": True})
            for prop, builder, targ, colname, tail in _columns(body):
                if builder not in BUILDERS:
                    continue      # `alias("X")` and friends are not columns
                ktype = targ or BUILDERS[builder]
                if builder == "enumerationByName" and not targ:
                    em = _ENUM_KCLASS.search(tail)
                    if em:
                        ktype = em.group(1)
                length = None
                lm = re.match(r"\s*,\s*(\w+)", tail)
                if lm:
                    tok = lm.group(1)
                    length = int(tok) if tok.isdigit() else consts.get(tok)
                cols.append({
                    "prop": prop, "col": colname, "type": ktype, "builder": builder,
                    "nullable": ".nullable()" in tail,
                    "default": bool(re.search(r"\.(default|defaultExpression|clientDefault)", tail)),
                    "unique": ".uniqueIndex(" in tail, "indexed": ".index(" in tail,
                    **({"length": length} if length else {}),
                    **({"references": rm.group(1)} if (rm := re.search(r"\.(?:opt)?[Rr]eferences?\(\s*(\w+)", tail)) else {}),
                })
            # `init { index(false, a, b); uniqueIndex(c) }` — 196 such statements
            # exist. Missing them makes an indexed column read as un-indexed.
            for im in re.finditer(r"\b(uniqueIndex|index)\s*\(([^)]*)\)", body):
                kind, args = im.group(1), im.group(2)
                refs = [r for r in re.findall(r"\b([a-z]\w*)\b", args)
                        if any(c["prop"] == r for c in cols)]
                composite = len(refs) > 1
                for ref in refs:
                    for c in cols:
                        if c["prop"] != ref:
                            continue
                        if kind == "uniqueIndex":
                            # a composite constraint is not uniqueness on one column
                            c["unique_with" if composite else "unique"] = (
                                [r for r in refs if r != ref] if composite else True)
                        else:
                            c["indexed"] = True
            pk = re.search(r"primaryKey\s*=\s*PrimaryKey\s*\(([^)]*)\)", body)
            if pk:
                for ref in re.findall(r"\b([a-z]\w*)\b", pk.group(1)):
                    for c in cols:
                        if c["prop"] == ref:
                            c["pk"] = True

            tid = nid(M.TABLE, f"{repo}:{sql}")
            mappers = sorted(set(_MAPPER_IN_TABLE.findall(body)))
            ext.g.node(tid, M.TABLE, sql, repo=repo, file=rel, line=line,
                       attrs={"object": obj, "base": base, "explicit_name": explicit,
                              "columns": cols, "column_count": len(cols),
                              **({"mappers": mappers} if mappers else {})})
            for dto_name in mappers:
                fqn = ext._resolve(dto_name, kf, "")
                if not fqn:
                    continue
                dto = ext.g.nodes.get(nid("kt", fqn))
                if dto is None or not dto.attrs.get("contract"):
                    continue
                ext.g.add_edge(tid, nid("kt", fqn), "maps_to", file=rel, line=line,
                               attrs={"mapper": f"to{dto_name}", "in_table": True})
                ext.stats["table_dto_edges"] += 1
                _flag_drift(ext, tid, dto)
            out[(repo, obj)] = tid
            ext.stats["tables"] += 1
            ext.stats["columns"] += len(cols)
    return out


def _object_body(text: str, start: int, cap: int = 12000) -> str:
    i = text.find("{", start)
    if i < 0:
        return ""
    depth = 0
    for j in range(i, min(len(text), i + cap)):
        if text[j] == "{":
            depth += 1
        elif text[j] == "}":
            depth -= 1
            if depth == 0:
                return text[i: j + 1]
    return text[i: i + cap]


def _fn_body(text: str, start: int, cap: int = 8000) -> str:
    """Body of a function, brace-form or expression-form.

    `fun toItem(row: ResultRow): Item = Item(...)` has no brace at all, so a
    brace-seeking extractor silently reads some later function instead.
    """
    i = start
    depth = 1                      # we start just after the opening paren of the params
    while i < len(text) and depth > 0 and i - start < 400:
        if text[i] == "(":
            depth += 1
        elif text[i] == ")":
            depth -= 1
        i += 1
    j = i
    while j < len(text) and text[j] in " \t\n:":
        j += 1
    # skip a declared return type
    while j < len(text) and (text[j].isalnum() or text[j] in "_.<>?,[] "):
        if text[j] in "={":
            break
        j += 1
    if j < len(text) and text[j] == "{":
        d = 0
        for k in range(j, min(len(text), j + cap)):
            if text[k] == "{":
                d += 1
            elif text[k] == "}":
                d -= 1
                if d == 0:
                    return text[j: k + 1]
        return text[j: j + cap]
    # expression body: run to the next top-level `fun`/`}` at column 0-ish
    nxt = re.search(r"\n(?:\s{0,4})(?:private |internal |suspend |override )*fun\b|\n\}",
                    text[j: j + cap])
    return text[j: j + (nxt.start() if nxt else cap)]


class _Missing:
    attrs: dict = {}


_NONE = _Missing()


def _link_mappers(ext, tables) -> None:
    """`fun toItem(...)` in a repository ties a Table to the DTO it produces.

    Also flags DTO fields with no matching column: with no migration tool, that gap
    is usually an ALTER TABLE that was never run.
    """
    for rel, kf in ext.kt_files.items():
        try:
            text = (ext.root / rel).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if "ResultRow" not in text and "toItem" not in text:
            if not _MAPPER.search(text):
                continue
        repo = rel.split("/", 1)[0]
        local = {obj: tid for (r, obj), tid in tables.items() if r == repo}
        if not local:
            continue
        for mm in _MAPPER.finditer(text):
            dto_name = mm.group(1)
            dto_fqn = ext._resolve(dto_name, kf, "")
            if not dto_fqn:
                continue
            dto = ext.g.nodes.get(nid("kt", dto_fqn))
            if dto is None or not dto.attrs.get("contract"):
                continue
            line = text.count("\n", 0, mm.start()) + 1
            # The in-table rule already covers 83 mappers correctly; this fallback is
            # only for a table that declares none of its own.
            fn_body = _fn_body(text, mm.end())
            # Only tables this mapper's own body reads, and only from this repo.
            # A mapper over a join legitimately reads several, so link all of them
            # and mark it -- what was wrong before was matching the whole FILE.
            used = [obj for obj in local
                    if re.search(rf"\b{re.escape(obj)}\s*[.\[]", fn_body)]
            if not used:
                ext.stats["mapper_unresolved"] += 1
                continue
            used = [o for o in used
                    if not ext.g.nodes.get(local[o], _NONE).attrs.get("mappers")]
            for obj in used:
                tid = local[obj]
                ext.g.add_edge(tid, nid("kt", dto_fqn), "maps_to",
                               file=rel, line=line,
                               attrs={"mapper": f"to{dto_name}",
                                      **({"join": True} if len(used) > 1 else {})})
                ext.stats["table_dto_edges"] += 1
                if len(used) == 1:
                    _flag_drift(ext, tid, dto)


def _flag_drift(ext, tid: str, dto) -> None:
    table = ext.g.nodes.get(tid)
    if table is None:
        return
    cols = {c["col"].lower().replace("_", "") for c in table.attrs.get("columns", [])}
    cols |= {c["prop"].lower() for c in table.attrs.get("columns", [])}
    missing = [f["n"] for f in dto.attrs.get("fields", [])
               if f["n"].lower() not in cols
               and f["n"].lower().replace("_", "") not in cols]
    if missing:
        table.attrs.setdefault("dto_only_fields", {})[dto.name] = missing[:12]
