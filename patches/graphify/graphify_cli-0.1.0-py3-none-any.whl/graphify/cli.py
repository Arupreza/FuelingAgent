"""graphify — a cross-repo dependency graph for the ControlResell workspace.

`build` walks every repo and writes graph.json plus ARCHITECTURE_GRAPH.md.
Every other subcommand answers a question against the built graph, so the usual
workflow is: build once, then ask -- never paste a source tree into a prompt.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from . import model as M
from .extract import nid
from .freshness import Manifest, ParseCache
from .model import Graph, Node

HERE = Path(__file__).resolve().parent
# The repo root when running from a checkout (src/graphify/ -> ..); meaningless when
# pip-installed, which is why nothing below depends on it existing.
CHECKOUT = HERE.parent.parent

# Optional seed for NEW claims (`build --reseed`): a directory of transcripts from
# prior investigations. Absent on almost every machine, so this stays empty by default.
TRANSCRIPTS = os.environ.get("GRAPHIFY_TRANSCRIPTS", "")

_REPO_MARKERS = ("settings.gradle.kts", "settings.gradle", "package.json",
                 "pyproject.toml", "Chart.yaml")


def _count_repos(d: Path) -> int:
    try:
        return sum(1 for c in d.iterdir()
                   if c.is_dir() and not c.name.startswith(".")
                   and any((c / m).exists() for m in _REPO_MARKERS))
    except OSError:
        return 0


def _find_workspace_root() -> Path:
    """The directory holding the repos.

    Two very different situations have to work. From a checkout, graphify sits beside
    the repos or inside one of them, so walking up from this file finds the workspace.
    Installed with pip, this file is in site-packages and walking up from it finds
    nothing at all -- there the workspace is wherever the user is standing, so the
    current directory is tried first.

    Getting this wrong is quiet -- a wrong root yields an empty graph, not an error --
    which is why `build` prints the root it chose and `GRAPHIFY_ROOT` can override it.
    """
    env = os.environ.get("GRAPHIFY_ROOT")
    if env:
        return Path(env).expanduser().resolve()
    cwd = Path.cwd().resolve()
    for cand in (cwd, *list(cwd.parents)[:4], *list(HERE.parents)[:4]):
        if _count_repos(cand) >= 2:
            return cand
    return cwd


DEFAULT_ROOT = _find_workspace_root()


def _state_dir(root: Path) -> Path:
    """Where derived data for THIS workspace goes.

    It used to sit next to the source, which was only ever right because there was one
    workspace. A pip install has a single copy of the source shared by every project on
    the machine, so two of them would overwrite each other's graph and each would then
    answer questions about the other's code -- silently, since a graph never looks wrong.
    Keying on the root's path makes that impossible.
    """
    env = os.environ.get("GRAPHIFY_CACHE")
    if env:
        return Path(env).expanduser().resolve()
    if (CHECKOUT / "src" / "graphify").is_dir():
        # A checkout keeps its own out/ so the repo stays self-contained.
        return CHECKOUT / "out"
    base = Path(os.environ.get("XDG_CACHE_HOME") or Path.home() / ".cache") / "graphify"
    return base / f"{root.name}-{hashlib.sha1(str(root).encode()).hexdigest()[:8]}"


def _kb_path(root: Path) -> Path:
    """Where the curated knowledge store lives.

    Deliberately NOT under `_state_dir`: that holds derived data safe to delete, and
    these claims are the one artifact that cannot be rebuilt from source. A checkout
    keeps its store in the repo so it can be committed and shared; anything else gets a
    per-workspace file next to the cache.
    """
    env = os.environ.get("GRAPHIFY_KB")
    if env:
        return Path(env).expanduser().resolve()
    local = CHECKOUT / "kb" / "claims.json"
    if local.exists():
        return local
    return _state_dir(root) / "knowledge.json"


OUT = _state_dir(DEFAULT_ROOT)
KB = _kb_path(DEFAULT_ROOT)


# --------------------------------------------------------------------- build
def cmd_build(args) -> int:
    from .extract import Extractor
    from .freshness import scan as fresh_scan
    from .messaging import link_messaging
    from .httproutes import link_http
    from .workflows import link_workflows
    from .datalayer import link_data_layer
    from .tests import link_tests
    from .statuses import link_statuses
    from .knowledge import Knowledge, Checker
    from .seed import harvest, derive
    from .failures import build_index
    from .docverify import build_file_index, check_docs
    from .emit import markdown

    root = Path(args.root).resolve()
    t0 = time.time()
    OUT.mkdir(parents=True, exist_ok=True)
    KB.parent.mkdir(parents=True, exist_ok=True)
    cache = ParseCache(OUT / "parse_cache.pkl")
    if not args.no_cache:
        cache.load()
    ext = Extractor(root, include_tests=args.include_tests, verbose=args.verbose,
                    cache=cache)

    steps = [
        ("workspace", ext.scan_workspace),
        ("build files", ext.scan_build_files),
        ("kotlin", ext.scan_kotlin),
        ("kotlin links", ext.link_kotlin),
        ("contract uses", ext.link_contract_imports),
        ("koin", ext.scan_koin),
        ("typescript", ext.scan_typescript),
        ("ts contracts", ext.link_typescript_contracts),
        ("python", ext.scan_python),
        ("messaging", lambda: link_messaging(ext)),
        ("http", lambda: link_http(ext)),
        ("workflows", lambda: link_workflows(ext)),
        ("data layer", lambda: link_data_layer(ext)),
        ("tests", lambda: link_tests(ext)),
        ("statuses", lambda: link_statuses(ext)),
    ]
    for name, fn in steps:
        s = time.time()
        fn()
        if not args.quiet:
            print(f"  {name:<14} {time.time() - s:5.2f}s", file=sys.stderr)

    build_index(ext, OUT / "messages.json")
    doc_claims = check_docs(root, ext.g,
                            {n.name for n in ext.g.by_kind(M.ROUTING_KEY)},
                            build_file_index(root))
    (OUT / "docs.json").write_text(json.dumps({"claims": doc_claims},
                                              separators=(",", ":")), encoding="utf-8")
    ext.stats["doc_claims"] = len(doc_claims)
    ext.stats["doc_drift"] = sum(1 for c in doc_claims if c["status"] == "drift")
    # Only file/routing-key/version-pin claims can ever REPORT drift; symbol and module
    # claims degrade to `unchecked`, so quoting the total overstates what was verified.
    ext.stats["doc_falsifiable"] = sum(
        1 for c in doc_claims
        if c["kind"] in ("file", "routing_key", "version_pin", "cardinality")
        and c["status"] != "unchecked")
    ext.g.resolve()

    cache.prune(set(ext.kt_files)
                | {k for k in cache.data if k.endswith((".ts", ".tsx"))}
                | {k for k in cache.data if "/src/" in k and "Test" in k})
    cache.save()
    stamps = fresh_scan(root)
    Manifest(OUT / "manifest.json").save(stamps, {"built_at": time.time()})
    elapsed = time.time() - t0

    size = ext.g.dump(OUT / "graph.json", compact=not args.pretty,
                      include_unresolved=True)
    meta = {
        "generated": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        "repos": len(ext.repos),
        "kt_files": ext.stats.get("kt_files", 0),
        "ts_files": ext.stats.get("ts_files", 0),
        "elapsed": elapsed,
        "unresolved": len(ext.g.unresolved),
        "stats": dict(ext.stats),
    }
    # Knowledge is re-verified on every build so a claim can go stale loudly
    # rather than being trusted forever.
    kb = Knowledge(KB).load()
    if args.reseed or not kb.claims:
        tdir = Path(TRANSCRIPTS)
        if tdir.is_dir():
            harvest(kb, tdir, root, ext.g)
        derive(kb, ext.g, dict(ext.stats))
    kstat = kb.verify(Checker(root, ext.g, dict(ext.stats)))
    kb.save()
    meta["knowledge"] = kstat
    (OUT / "meta.json").write_text(json.dumps(meta, indent=1), encoding="utf-8")

    md = markdown.render(ext.g, meta)
    target = Path(args.summary) if args.summary else root / "ARCHITECTURE_GRAPH.md"
    target.write_text(md, encoding="utf-8")

    if not args.quiet:
        st = ext.g.stats()
        print(f"\n  {st['nodes']:,} nodes  {st['edges']:,} edges  "
              f"({len(ext.g.unresolved):,} unresolved)  in {elapsed:.1f}s",
              file=sys.stderr)
        print(f"  parsed {ext.stats.get('kt_parsed', 0)} / cached "
              f"{ext.stats.get('kt_cached', 0)} Kotlin files", file=sys.stderr)
        print(f"  graph.json  {size / 1024:.0f} KB   {OUT / 'graph.json'}", file=sys.stderr)
        print(f"  summary     {len(md) / 1024:.0f} KB   {target}", file=sys.stderr)
        print(f"  knowledge   {len(kb.claims)} claims "
              f"({kstat['fresh']} verified, {kstat['stale']} stale)", file=sys.stderr)
        # The root is discovered, and a wrong one produces an empty graph rather than
        # an error -- so say which one was used, and say it loudly when it found nothing.
        nrepos = len(ext.repos)
        if nrepos < 2:
            print(f"\n\033[31m  only {nrepos} repo(s) found under {root}"
                  "\n  that is almost certainly the wrong workspace root — "
                  "set GRAPHIFY_ROOT to the directory holding the repos\033[0m",
                  file=sys.stderr)
        else:
            print(f"  workspace   {nrepos} repos under {root}", file=sys.stderr)
    return 0


# --------------------------------------------------------------------- helpers
def _check_fresh(auto: bool = True) -> None:
    """Never answer from a stale graph without saying so.

    Costs ~110ms to stat the source tree. Worth it: a stale graph is confidently
    wrong and nothing about the answer looks off, which is the failure mode most
    likely to waste an hour.
    """
    st = Manifest(OUT / "manifest.json").status(DEFAULT_ROOT)
    if st["state"] == "fresh":
        return
    if st["state"] == "missing":
        print("\033[33m  no freshness manifest — run `graphify build` to create one"
              "\033[0m", file=sys.stderr)
        return
    changed = len(st["added"]) + len(st["modified"]) + len(st["removed"])
    sample = (st["modified"] or st["added"] or st["removed"])[:3]
    if auto:
        print(f"\033[33m  graph is stale ({changed} files changed) — rebuilding…"
              f"\033[0m", file=sys.stderr)
        for f in sample:
            print(f"\033[90m    {f}\033[0m", file=sys.stderr)
        rc = main(["build", "-q"])
        if rc == 0:
            print("\033[32m  rebuilt\033[0m", file=sys.stderr)
        return
    print(f"\033[31m  WARNING: graph is STALE — {changed} source files have changed "
          f"since it was built. Answers below may be wrong. Run `graphify build`."
          f"\033[0m", file=sys.stderr)


def _load(check: bool = True) -> Graph:
    p = OUT / "graph.json"
    if not p.exists():
        print("no graph yet — run:  ./graphify build", file=sys.stderr)
        raise SystemExit(2)
    if check and not _NO_FRESHNESS[0]:
        _check_fresh(auto=_AUTO_REBUILD[0])
    return Graph.load(p)


_NO_FRESHNESS = [False]
_AUTO_REBUILD = [True]


def _find(g: Graph, term: str, kinds: tuple[str, ...] = (),
          strict: bool = False) -> list:
    """Match by exact name, then id suffix, then case-insensitive substring."""
    t = term.lower()
    pool = [n for n in g.nodes.values() if not kinds or n.kind in kinds]
    exact = [n for n in pool if n.name == term]
    ci = [n for n in pool if n.name.lower() == t and n not in exact]
    # For DISAMBIGUATION an exact hit settles it. For SEARCH it must not: one node
    # happening to be named `Republish` should not hide the other 38 that contain it.
    if strict and (exact or ci):
        return exact or ci
    suffix = [n for n in pool if n.id.endswith(term) or n.id.endswith("." + term)]
    # `strict` is for DISAMBIGUATION (`explain`), where a loose substring match would
    # confidently brief on an unrelated type. `find` is a search: it must return every
    # match, ranked, or it reports "0 matches" for a name that occurs nine times.
    cands = [n for n in pool if t in n.name.lower()]
    if strict:
        cands = [n for n in cands if len(t) >= 0.5 * len(n.name)]
    partial = sorted(cands, key=lambda n: (len(n.name), n.name))
    ordered: list = []
    for group in (exact, ci, suffix, partial):
        for n in group:
            if n not in ordered:
                ordered.append(n)
    return ordered


def _cut(text: str, n: int) -> str:
    """Truncate with a visible marker. Silently cutting `AccountPlatform.EBAY` to
    `Account` turns a guard into a different, and real, predicate."""
    return text if len(text) <= n else text[: n - 1] + "…"


def _loc(n) -> str:
    return f"{n.file}:{n.line}" if n.file and n.line else (n.file or "")


def _pick(g: Graph, term: str, kinds=()) -> list:
    hits = _find(g, term, kinds, strict=True)
    if not hits:
        print(f"\033[31mno symbol named {term!r} in the graph\033[0m", file=sys.stderr)
        # Real similarity, not substring: "Nope" is a substring of
        # "CrossOrigi-nOpe-nerPolicy", which is not a useful suggestion.
        import difflib
        near = difflib.get_close_matches(
            term, {n.name for n in g.nodes.values()}, n=5, cutoff=0.6)
        if near:
            print("  did you mean: " + ", ".join(near), file=sys.stderr)
        raise SystemExit(1)
    if len(hits) > 1:
        print(f"{len(hits)} matches for {term!r}:", file=sys.stderr)
        for h in hits[:20]:
            print(f"  {h.kind:<12} {h.name:<40} {_loc(h)}", file=sys.stderr)
        if len(hits) > 6:
            raise SystemExit(1)
    return hits


def _emit(payload, as_json: bool, render) -> int:
    if as_json:
        print(json.dumps(payload, indent=1, default=str))
    else:
        render(payload)
    return 0


# --------------------------------------------------------------------- queries
def cmd_key(args) -> int:
    g = _load()
    hits = [n for n in g.by_kind(M.ROUTING_KEY)
            if args.key in (n.name, n.attrs.get("const"))] or \
          [n for n in g.by_kind(M.ROUTING_KEY) if args.key.lower() in n.name.lower()]
    if not hits:
        print(f"no routing key matching {args.key!r}", file=sys.stderr)
        return 1
    out = []
    for k in hits:
        rec = {
            "key": k.name, "const": k.attrs.get("const"),
            "fanout": k.attrs.get("fanout"), "priority": k.attrs.get("priority"),
            "publishers": [], "subscribers": [], "payloads": [],
        }
        for e in g.in_edges(k.id, M.PUBLISHES, "publishes_headers"):
            n = g.nodes.get(e.src)
            if n:
                rec["publishers"].append({
                    "service": n.name, "at": f"{e.file}:{e.line}",
                    "exchange": "headers" if e.kind == "publishes_headers" else "topic",
                    **{x: e.attrs[x] for x in
                       ("via", "variant", "delayed", "via_library") if x in e.attrs}})
        for e in g.in_edges(k.id, M.SUBSCRIBES):
            n = g.nodes.get(e.src)
            if n:
                rec["subscribers"].append({"service": n.name, "at": f"{e.file}:{e.line}",
                                           "via": e.attrs.get("via")})
        for e in g.out_edges(k.id, M.CARRIES):
            n = g.nodes.get(e.dst)
            if n:
                rec["payloads"].append({"type": n.name, "declared_at": _loc(n),
                                        "direction": e.attrs.get("direction")})
        out.append(rec)

    def render(recs):
        for r in recs:
            print(f"\n\033[1m{r['key']}\033[0m  ({r['const']}"
                  f"{', fanout' if r['fanout'] else ''}"
                  f"{', priority ' + str(r['priority']) if r['priority'] else ''})")
            print(f"  publishers ({len(r['publishers'])} call sites):")
            bysvc = defaultdict(list)
            for p in r["publishers"]:
                bysvc[p["service"]].append(p)
            for svc, ps in sorted(bysvc.items()):
                variants = sorted({p["variant"] for p in ps if p.get("variant")})
                hdr = sum(1 for p in ps if p.get("exchange") == "headers")
                head = f"    {svc}  ({len(ps)} sites"
                head += f", {hdr} via headers exchange)" if hdr else ")"
                if variants:
                    head += "  " + ", ".join(variants[:6])
                    if len(variants) > 6:
                        head += f" +{len(variants) - 6}"
                print(head)
                for p in ps[:8]:
                    print(f"        {p['at']}")
                if len(ps) > 8:
                    print(f"        … {len(ps) - 8} more")
            print("  subscribers:")
            for s in {(x["service"], x["via"]): x for x in r["subscribers"]}.values():
                print(f"    {s['service']}  ({s['via']})  ← {s['at']}")
            if r["payloads"]:
                print("  payloads:")
                for p in {x["type"]: x for x in r["payloads"]}.values():
                    print(f"    {p['type']:<40} {p['declared_at']}")
    return _emit(out, args.json, render)


def cmd_contract(args) -> int:
    g = _load()
    hits = _pick(g, args.type, (M.DTO, M.VARIANT, M.ENUM, M.CLASS, M.INTERFACE))
    out = []
    for n in hits:
        rec = {
            "name": n.name, "kind": n.kind, "declared_at": _loc(n),
            "repo": n.repo, "module": n.module,
            "generated_ts": n.attrs.get("generated_ts"),
            "jvm_only": n.attrs.get("jvm_only"),
            "serial_name": n.attrs.get("serial_name"),
            "fields": n.attrs.get("fields", []),
            "entries": n.attrs.get("entries", []),
            "carried_on": [], "consumers": [], "produced_by": [],
        }
        for e in g.in_edges(n.id, M.CARRIES):
            k = g.nodes.get(e.src)
            if k:
                rec["carried_on"].append({"key": k.name,
                                          "direction": e.attrs.get("direction")})
        for e in g.in_edges(n.id, M.REFERENCES, M.FIELD_OF, M.INJECTS, M.CALLS, M.HANDLES):
            s = g.nodes.get(e.src)
            if s:
                rec["consumers"].append({"by": s.name, "kind": e.kind,
                                         "repo": s.repo, "at": f"{e.file}:{e.line}"})
        out.append(rec)

    def render(recs):
        for r in recs:
            print(f"\n\033[1m{r['name']}\033[0m  ({r['kind']})  {r['declared_at']}")
            tags = []
            if r["generated_ts"]:
                tags.append("→ TypeScript (@Zodable)")
            if r["jvm_only"]:
                tags.append("JVM-only (never reaches the app)")
            if r["serial_name"]:
                tags.append(f'wire discriminator "{r["serial_name"]}"')
            if tags:
                print("  " + " · ".join(tags))
            if r["fields"]:
                print(f"  fields ({len(r['fields'])}):")
                for f in r["fields"][:40]:
                    q = "?" if f.get("null") else " "
                    d = "  = default" if f.get("def") else ""
                    print(f"    {f['n']:<26} {f['t']}{q}{d}")
            if r["entries"]:
                print(f"  constants ({len(r['entries'])}): "
                      f"{', '.join(r['entries'][:24])}"
                      f"{' …' if len(r['entries']) > 24 else ''}")
            if r["carried_on"]:
                print("  carried on: " + ", ".join(
                    sorted({f"{c['key']} ({c['direction']})" for c in r["carried_on"]})))
            if r["consumers"]:
                byrepo = defaultdict(list)
                for c in r["consumers"]:
                    byrepo[c["repo"] or "?"].append(c)
                shown = sorted(byrepo.items(), key=lambda x: -len(x[1]))
                print(f"  consumed by {len(r['consumers'])} sites across "
                      f"{len(byrepo)} repos"
                      + (f" (listing {min(len(shown), 12)})" if len(shown) > 12 else "")
                      + ":")
                for repo, cs in shown[:12]:
                    names = sorted({c["by"] for c in cs})
                    print(f"    {repo:<34} {len(cs):>3}  "
                          f"{', '.join(names[:5])}{' …' if len(names) > 5 else ''}")
    return _emit(out, args.json, render)


def cmd_callers(args) -> int:
    g = _load()
    hits = _pick(g, args.symbol)
    depth = args.depth
    out = []
    for target in hits:
        seen = {target.id}
        frontier = [(target.id, 0)]
        levels = defaultdict(list)
        while frontier:
            nid_, d = frontier.pop(0)
            if d >= depth:
                continue
            for e in g.in_edges(nid_, M.CALLS, M.INJECTS, M.HANDLES, M.BINDS):
                if e.src in seen:
                    continue
                s = g.nodes.get(e.src)
                if not s or s.kind in (M.MODULE, M.REPO):
                    continue
                seen.add(e.src)
                levels[d + 1].append({"name": s.name, "kind": s.kind, "repo": s.repo,
                                      "edge": e.kind, "via": e.attrs.get("via", ""),
                                      "at": f"{e.file}:{e.line}"})
                frontier.append((e.src, d + 1))
        out.append({"target": target.name, "declared_at": _loc(target),
                    "levels": {str(k): v for k, v in sorted(levels.items())}})

    def render(recs):
        for r in recs:
            print(f"\n\033[1m{r['target']}\033[0m  {r['declared_at']}")
            for lvl, items in r["levels"].items():
                print(f"  ── {lvl} hop{'s' if lvl != '1' else ''} "
                      f"({len(items)}) ──")
                for c in sorted(items, key=lambda x: (x["repo"], x["name"]))[:40]:
                    via = f" via {c['via']}" if c["via"] else ""
                    print(f"    {c['name']:<44} {c['edge']}{via}  {c['at']}")
                if len(items) > 40:
                    print(f"    … {len(items) - 40} more")
    return _emit(out, args.json, render)


def cmd_impact(args) -> int:
    g = _load()
    hits = _pick(g, args.symbol)
    out = []
    for t in hits:
        repos, kinds, sites = defaultdict(int), defaultdict(int), []
        seen = {t.id}
        frontier = [t.id]
        hops = 0
        while frontier and hops < args.depth:
            nxt = []
            for nid_ in frontier:
                for e in g.in_edges(nid_):
                    if e.kind in (M.CONTAINS,) or e.src in seen:
                        continue
                    s = g.nodes.get(e.src)
                    if not s:
                        continue
                    seen.add(e.src)
                    repos[s.repo or s.kind] += 1
                    kinds[e.kind] += 1
                    if e.file:
                        sites.append(f"{s.name} — {e.kind} — {e.file}:{e.line}")
                    nxt.append(e.src)
            frontier = nxt
            hops += 1
        out.append({"target": t.name, "declared_at": _loc(t),
                    "reached": len(seen) - 1,
                    "by_repo": dict(sorted(repos.items(), key=lambda x: -x[1])),
                    "by_edge": dict(sorted(kinds.items(), key=lambda x: -x[1])),
                    "sample": sites[:30]})

    def render(recs):
        for r in recs:
            print(f"\n\033[1m{r['target']}\033[0m  {r['declared_at']}")
            print(f"  {r['reached']} nodes depend on this (≤{args.depth} hops)")
            print("  by repo:  " + ", ".join(f"{k}={v}" for k, v in r["by_repo"].items()))
            print("  by edge:  " + ", ".join(f"{k}={v}" for k, v in r["by_edge"].items()))
            if r["sample"]:
                print("  sample sites:")
                for s in r["sample"][:15]:
                    print("    " + s)
    return _emit(out, args.json, render)


def cmd_deps(args) -> int:
    g = _load()
    repo = args.repo
    node = g.nodes.get(f"repo:{repo}")
    if node is None:
        allr = sorted(n.name for n in g.by_kind(M.REPO))
        near = [n for n in allr if repo.lower() in n.lower()]
        print(f"unknown repo {repo!r}.", file=sys.stderr)
        print("available: " + ", ".join(near or allr), file=sys.stderr)
        return 1
    out_deps, in_deps = [], []
    for e in g.edges:
        if e.kind != M.DEPENDS_ON:
            continue
        s, d = g.nodes.get(e.src), g.nodes.get(e.dst)
        if not s or not d:
            continue
        if s.kind == M.REPO and d.kind == M.REPO:
            continue   # the repo-level roll-up; the artifact rows below say more
        if s.repo == repo and d.repo != repo:
            out_deps.append({"from": s.name, "to": d.name, "kind": d.kind,
                             "version": e.attrs.get("version") or e.attrs.get("range", ""),
                             "config": e.attrs.get("config", ""), "at": f"{e.file}:{e.line}"})
        if d.repo == repo and s.repo and s.repo != repo:
            in_deps.append({"from_repo": s.repo, "from": s.name, "to": d.name,
                            "version": e.attrs.get("version") or e.attrs.get("range", "")})
    rec = {"repo": repo, "version": node.attrs.get("version"),
           "head": node.attrs.get("git_head"), "depends_on": out_deps,
           "depended_on_by": in_deps}

    def render(r):
        print(f"\n\033[1m{r['repo']}\033[0m  v{r['version'] or '?'}  @{r['head'] or '?'}")
        print("\n  depends on:")
        for d in sorted({(x["to"], x["version"], x["config"]) for x in r["depends_on"]}):
            print(f"    {d[0]:<28} {d[1] or '':<12} {d[2]}")
        print("\n  depended on by:")
        for d in sorted({(x["from_repo"], x["to"], x["version"]) for x in r["depended_on_by"]}):
            print(f"    {d[0]:<38} wants {d[1]} {d[2]}")
    return _emit(rec, args.json, render)


def cmd_routes(args) -> int:
    g = _load()
    rs = [n for n in g.by_kind(M.HTTP_ROUTE)
          if (not args.repo or args.repo in n.repo) and n.attrs.get("path")
          and (n.attrs.get("verb") or n.attrs.get("literal")
               or n.attrs.get("handler"))]
    rows = sorted({(n.attrs.get("verb") or n.name.split(" ")[0] or "ANY",
                    n.attrs["path"], n.repo, _loc(n),
                    n.attrs.get("request_type", "")) for n in rs},
                  key=lambda r: (r[2], r[1], r[0]))
    out = [{"verb": r[0], "path": r[1], "repo": r[2], "at": r[3], "request": r[4]}
           for r in rows]

    def render(recs):
        cur = None
        for r in recs:
            if r["repo"] != cur:
                cur = r["repo"]
                print(f"\n\033[1m{cur}\033[0m")
            body = f"  ← {r['request']}" if r["request"] else ""
            print(f"  {r['verb']:<7} {r['path']:<54}{body}")
        print(f"\n  {len(recs)} routes")
    return _emit(out, args.json, render)


def cmd_root(args) -> int:
    """Answers the first question asked when a query comes back empty.

    The root is discovered by walking up from this file, so on a layout neither
    shape covers it can silently resolve to the wrong directory. Printing it on
    stdout also lets install.sh template the skill without duplicating the logic.
    """
    print(DEFAULT_ROOT)
    return 0


def cmd_stats(args) -> int:
    g = _load()
    meta = json.loads((OUT / "meta.json").read_text()) if (OUT / "meta.json").exists() else {}
    payload = {"generated": meta.get("generated"), **g.stats(),
               "extract_stats": meta.get("stats", {})}

    def render(p):
        print(f"generated {p.get('generated')}")
        print(f"\n{p['nodes']:,} nodes / {p['edges']:,} edges "
              f"/ {p['unresolved']:,} unresolved")
        print("\nnodes:")
        for k, v in p["by_node_kind"].items():
            print(f"  {k:<16} {v:>6,}")
        print("\nedges:")
        for k, v in p["by_edge_kind"].items():
            print(f"  {k:<20} {v:>6,}")
    return _emit(payload, args.json, render)


def cmd_explain(args) -> int:
    """One briefing per symbol: what it is, what it does, what it touches.

    Deliberately assembles from every layer at once — declaration, KDoc, contract
    shape, dependencies, callers, routing keys, handled payloads — because the point
    is to replace a round of exploratory greps, not to answer one narrow question.
    """
    g = _load()
    hits = _pick(g, args.symbol)
    out = []
    for n in hits[:3]:
        rec: dict = {
            "name": n.name, "kind": n.kind, "at": _loc(n),
            "repo": n.repo, "module": n.module,
            "doc": n.attrs.get("doc", ""),
            "annotations": n.attrs.get("annotations", []),
            "modifiers": n.attrs.get("modifiers", []),
        }
        for k in ("serial_name", "generated_ts", "jvm_only", "sealed", "path", "template"):
            if n.attrs.get(k):
                rec[k] = n.attrs[k]
        rec["fields"] = n.attrs.get("fields", [])
        rec["ctor"] = n.attrs.get("ctor", [])
        rec["entries"] = n.attrs.get("entries", [])
        rec["functions"] = n.attrs.get("functions", [])
        rec["fn_docs"] = n.attrs.get("fn_docs", {})
        rec["guards"] = n.attrs.get("guards", [])

        def side(edges, other):
            seen, acc = set(), []
            for e in edges:
                o = g.nodes.get(getattr(e, other))
                if not o or o.kind in (M.MODULE, M.REPO):
                    continue
                key = (o.name, e.kind)
                if key in seen:
                    continue
                seen.add(key)
                acc.append({"name": o.name, "kind": o.kind, "edge": e.kind,
                            "repo": o.repo, "doc": (o.attrs.get("doc") or "")[:110],
                            "via": e.attrs.get("via", ""), "at": f"{e.file}:{e.line}"})
            return acc

        rec["depends_on"] = side(g.out_edges(n.id, M.INJECTS, M.CALLS), "dst")
        rec["used_by"] = side(g.in_edges(n.id, M.INJECTS, M.CALLS, M.REFERENCES,
                                         M.FIELD_OF, M.HANDLES), "src")
        rec["implements"] = side(g.out_edges(n.id, M.EXTENDS, M.IMPLEMENTS), "dst")
        _own = {i["name"] for i in rec["implements"]}
        rec["implemented_by"] = [x for x in
                                 side(g.in_edges(n.id, M.BINDS, M.EXTENDS, M.IMPLEMENTS), "src")
                                 if x["name"] not in _own]
        rec["publishes"] = [
            {"key": g.nodes[e.dst].name, "at": f"{e.file}:{e.line}"}
            for e in g.out_edges(n.id, "publishes_from") if e.dst in g.nodes]
        rec["handles_keys"] = [
            {"key": g.nodes[e.dst].name, "payload": e.attrs.get("payload", "")}
            for e in g.out_edges(n.id, "handles_key") if e.dst in g.nodes]
        rec["handles_payloads"] = [
            {"payload": g.nodes[e.dst].name}
            for e in g.out_edges(n.id, M.HANDLES) if e.dst in g.nodes]
        rec["carried_on"] = [
            {"key": g.nodes[e.src].name, "direction": e.attrs.get("direction")}
            for e in g.in_edges(n.id, M.CARRIES) if e.src in g.nodes]
        rec["triggers"] = _entry_points(g, n.id)
        rec["tested_by"] = [
            {"test": g.nodes[e.src].name, "cases": e.attrs.get("cases", 0),
             "at": f"{e.file}:{e.line}",
             "describes": g.nodes[e.src].attrs.get("descriptions", [])[:6]}
            for e in g.in_edges(n.id, "tests") if e.src in g.nodes]
        out.append(rec)

    def render(recs):
        for r in recs:
            print(f"\n\033[1m{r['name']}\033[0m  ({r['kind']})  {r['at']}")
            tags = [t for t in (
                "@" + ", @".join(r["annotations"]) if r["annotations"] else "",
                " ".join(r["modifiers"]) if r["modifiers"] else "",
                f'wire "{r["serial_name"]}"' if r.get("serial_name") else "",
                "→ TypeScript" if r.get("generated_ts") else "",
                "JVM-only" if r.get("jvm_only") else "",
                f"path {r['path']}" if r.get("path") else "",
            ) if t]
            if tags:
                print("  " + "  ·  ".join(tags))
            if r["doc"]:
                print(f"\n  {r['doc']}")

            if r["fields"]:
                print(f"\n  fields ({len(r['fields'])}):")
                for f in r["fields"][:30]:
                    q = "?" if f.get("null") else ""
                    doc = f"   — {f['doc']}" if f.get("doc") else ""
                    print(f"    {f['n']:<24} {f['t']}{q}{doc}")
            if r["entries"]:
                print(f"\n  constants ({len(r['entries'])}): {', '.join(r['entries'][:20])}"
                      + (" …" if len(r["entries"]) > 20 else ""))
            if r["ctor"]:
                print(f"\n  dependencies ({len(r['ctor'])}):")
                for c in r["ctor"][:20]:
                    print(f"    {c['n']:<28} {c['t']}")
            if r["fn_docs"]:
                print("\n  what it does:")
                for fn, doc in list(r["fn_docs"].items())[:8]:
                    print(f"    {fn}() — {doc}")
            elif r["functions"]:
                print(f"\n  functions: {', '.join(r['functions'][:12])}")

            for label, items in (("implements", r["implements"]),
                                 ("implemented by", r["implemented_by"])):
                if items:
                    print(f"\n  {label}: " +
                          ", ".join(f"{i['name']}" for i in items[:8]))
            if r["guards"]:
                fns = {x.get("fn", "") for x in r["guards"]}
                stops = [x for x in r["guards"] if x.get("scope", "function") == "function"]
                skips = [x for x in r["guards"] if x.get("scope") in ("element", "block")]
                print(f"\n  guards — what stops it early ({len(stops)}"
                      + (f", plus {len(skips)} that skip one item" if skips else "") + "):")
                for gd in (stops + skips)[:12]:
                    cond = gd["cond"]
                    # `x ?: return` is a null check; showing the bare expression
                    # reads like a call, not like the condition it actually is.
                    if gd["kind"] == "elvis_return":
                        cond = f"{cond} == null"
                    elif gd["kind"] in ("require", "check"):
                        cond = f"{gd['kind']} {cond}"
                    res = gd.get("result", "")
                    res = f"  → {_cut(res, 48)}" if res else ""
                    scope = gd.get("scope", "function")
                    mark = {"function": "",
                            "element": "  \033[90m[skips one item]\033[0m",
                            "handler": "  \033[90m[ends request]\033[0m",
                            "block": "  \033[90m[exits a block, not the function]\033[0m",
                            }.get(scope, "")
                    fn = gd.get("fn", "")
                    where = f"\033[90m{fn}()\033[0m " if fn and len(fns) > 1 else ""
                    print(f"    :{gd['line']:<5} {where}{_cut(cond, 60)}{res}{mark}")
                if len(r["guards"]) > 12:
                    print(f"    … {len(r['guards']) - 12} more")
            if r["triggers"]:
                print("\n  triggered by:")
                for t in r["triggers"]:
                    via = f"  (via {t['via']})" if t["via"] else ""
                    print(f"    {t['kind']:<14} {t['name']}{via}")
            if r["handles_payloads"]:
                print("\n  handles: " +
                      ", ".join(h["payload"] for h in r["handles_payloads"][:12]))
            if r["handles_keys"]:
                print("\n  consumes routing keys:")
                for h in r["handles_keys"][:12]:
                    print(f"    {h['key']:<44} {h['payload']}")
            if r["publishes"]:
                print("\n  publishes:")
                for pub in {p["key"]: p for p in r["publishes"]}.values():
                    print(f"    {pub['key']:<44} {pub['at']}")
            if r["carried_on"]:
                print("\n  travels on: " +
                      ", ".join(sorted({f"{c['key']} ({c['direction']})"
                                        for c in r["carried_on"]})))
            if r["tested_by"]:
                for t in r["tested_by"]:
                    print(f"\n  tested by {t['test']} ({t['cases']} cases)  {t['at']}")
                    for dsc in t["describes"]:
                        print(f"    · {dsc[:100]}")
            if r["depends_on"]:
                print(f"\n  calls / injects ({len(r['depends_on'])}):")
                for dep in r["depends_on"][:14]:
                    doc = f"  — {dep['doc']}" if dep["doc"] else ""
                    print(f"    {dep['name']:<40}{doc}")
                if len(r["depends_on"]) > 14:
                    print(f"    … {len(r['depends_on']) - 14} more")
            if r["used_by"]:
                byrepo = defaultdict(list)
                for u in r["used_by"]:
                    byrepo[u["repo"] or "?"].append(u["name"])
                print(f"\n  used by ({len(r['used_by'])} across {len(byrepo)} repos):")
                for repo, names in sorted(byrepo.items(), key=lambda x: -len(x[1])):
                    uniq = sorted(set(names))
                    print(f"    {repo:<34} {', '.join(uniq[:6])}"
                          + (f" +{len(uniq) - 6}" if len(uniq) > 6 else ""))
    return _emit(out, args.json, render)


# A dispatcher is defined by what it does, not by how many dependencies it has:
# it routes many keys. RepublishItemWorkflowImpl has 16 dependencies and is a single
# path; DefaultMessageHandler routes 41 keys and is a fan-out point.
HUB_KEYS = 4


def _entry_points(g: Graph, start: str, max_hops: int = 6) -> list[dict]:
    """Walk inbound call/injection edges until an entry point is reached.

    "What triggers this?" is the question `callers` answers badly — it gives the
    immediate caller, when what you want is the routing key, cron or HTTP route at
    the top of the chain. This walks up to whatever actually starts the work.
    """
    seen = {start}
    frontier = [(start, 0)]
    found: dict[tuple, dict] = {}
    while frontier:
        nid_, hops = frontier.pop(0)
        if hops >= max_hops:
            continue
        # Does this node itself sit at an entry point?
        for e in g.in_edges(nid_, "dispatches_to"):
            k = g.nodes.get(e.src)
            if k:
                found[("key", k.name)] = {
                    "kind": "routing key", "name": k.name,
                    "via": g.nodes[nid_].name if nid_ in g.nodes else "",
                    "hops": hops}
        for e in g.in_edges(nid_, M.HANDLES):
            src = g.nodes.get(e.src)
            if src and src.kind == M.SERVICE:
                found[("svc", src.name)] = {
                    "kind": "job dispatch", "name": src.name,
                    "via": g.nodes[nid_].name if nid_ in g.nodes else "", "hops": hops}
        for e in g.in_edges(nid_, "serves"):
            r = g.nodes.get(e.src)
            if r and r.attrs.get("path"):
                found[("http", r.name)] = {
                    "kind": "HTTP", "name": r.name,
                    "via": g.nodes[nid_].name if nid_ in g.nodes else "", "hops": hops}
        # A slave handler is reached through the job pipeline, not by a topic key.
        for e in g.out_edges(nid_, M.HANDLES):
            v = g.nodes.get(e.dst)
            if v and v.kind == M.VARIANT and "JobPayload" in v.id:
                found[("job", v.name)] = {
                    "kind": "job payload", "name": v.name,
                    "via": g.nodes[nid_].name if nid_ in g.nodes else "", "hops": hops}
        for e in g.in_edges(nid_, M.CALLS, M.INJECTS, M.BINDS):
            if e.src in seen:
                continue
            src = g.nodes.get(e.src)
            if not src or src.kind in (M.MODULE, M.REPO):
                continue
            # A dispatcher fans out to dozens of unrelated paths; walking through it
            # would attribute every key it handles to every use case it can reach.
            if len(g.out_edges(e.src, "handles_key")) > HUB_KEYS:
                continue
            seen.add(e.src)
            frontier.append((e.src, hops + 1))
    return sorted(found.values(), key=lambda x: (x["hops"], x["kind"]))[:14]


def cmd_workflow(args) -> int:
    """Render a workflow's derived state machine."""
    g = _load()
    roots = [n for n in g.nodes.values() if n.attrs.get("workflow")]
    if args.name:
        roots = [n for n in roots if args.name.lower() in n.name.lower()]
    if not roots:
        print("known workflows: " + ", ".join(sorted(
            n.name for n in g.nodes.values() if n.attrs.get("workflow"))),
            file=sys.stderr)
        return 1
    out = []
    for root in sorted(roots, key=lambda n: n.name):
        variants = {}
        for e in g.in_edges(root.id, M.EXTENDS):
            v = g.nodes.get(e.src)
            if v:
                variants[v.name] = v
        rec = {"workflow": root.name, "at": _loc(root), "steps": []}
        for name, v in sorted(variants.items()):
            rec["steps"].append({
                "step": name,
                "doc": v.attrs.get("doc", ""),
                "writes_history": v.attrs.get("writes_history", []),
                "next": sorted({g.nodes[e.dst].name for e in g.out_edges(v.id, "step_next")
                                if e.dst in g.nodes}),
                "awaits": sorted({g.nodes[e.dst].name for e in g.out_edges(v.id, "step_awaits")
                                  if e.dst in g.nodes}),
                "resumed_by": sorted({g.nodes[e.src].name for e in g.in_edges(v.id, "resumes")
                                      if e.src in g.nodes}),
            })
        out.append(rec)

    def render(recs):
        for r in recs:
            print(f"\n\033[1m{r['workflow']}\033[0m  {r['at']}")
            for st in r["steps"]:
                bits = []
                if st["next"]:
                    bits.append("→ " + ", ".join(st["next"]))
                if st["awaits"]:
                    bits.append("⏸ awaits " + ", ".join(st["awaits"]))
                if st["resumed_by"]:
                    bits.append("↻ resumed by " + ", ".join(st["resumed_by"]))
                if st["writes_history"]:
                    bits.append("writes " + ", ".join(st["writes_history"]))
                print(f"    {st['step']:<20} {'  |  '.join(bits) or '(terminal)'}")
                if st["doc"]:
                    print(f"      \033[90m{st['doc'][:96]}\033[0m")
    return _emit(out, args.json, render)


def cmd_table(args) -> int:
    """Columns of an Exposed table, and the DTOs it maps to."""
    g = _load()
    hits = [n for n in g.by_kind(M.TABLE)
            if args.name.lower() in n.name.lower()
            or args.name.lower() in (n.attrs.get("object", "").lower())]
    if not hits:
        print(f"no table matching {args.name!r}", file=sys.stderr)
        return 1
    out = []
    for t in sorted(hits, key=lambda n: n.name)[:4]:
        out.append({
            "sql_name": t.name, "object": t.attrs.get("object"),
            "base": t.attrs.get("base"), "at": _loc(t),
            "explicit_name": t.attrs.get("explicit_name"),
            "columns": t.attrs.get("columns", []),
            "maps_to": [g.nodes[e.dst].name for e in g.out_edges(t.id, "maps_to")
                        if e.dst in g.nodes],
            "dto_only_fields": t.attrs.get("dto_only_fields", {}),
        })

    def render(recs):
        for r in recs:
            named = "explicit" if r["explicit_name"] else "derived from object name"
            print(f"\n\033[1m{r['sql_name']}\033[0m  (SQL name, {named})  "
                  f"— object {r['object']} : {r['base']}   {r['at']}")
            print(f"\n  columns ({len(r['columns'])}):")
            for c in r["columns"]:
                flags = []
                if c.get("pk"):
                    flags.append("PK")
                if c.get("nullable"):
                    flags.append("NULL")
                if c.get("unique"):
                    flags.append("UNIQUE")
                if c.get("unique_with"):
                    flags.append("UNIQUE(with " + ",".join(c["unique_with"]) + ")")
                if c.get("indexed"):
                    flags.append("INDEX")
                if c.get("default"):
                    flags.append("DEFAULT")
                if c.get("references"):
                    flags.append(f"→{c['references']}")
                ln = f"({c['length']})" if c.get("length") else ""
                print(f"    {c['col']:<28} {c['builder']}{ln:<8} {c['type']:<18}"
                      f" {' '.join(flags)}")
            if r["maps_to"]:
                print(f"\n  maps to: {', '.join(sorted(set(r['maps_to'])))}")
            if r["dto_only_fields"]:
                print("\n  \033[90mDTO fields with no column of the same name\033[0m "
                      "— most are computed, joined or nested objects; only "
                      "investigate one that looks like a plain scalar (there is no "
                      "migration tool, so a real gap means an ALTER TABLE never run):")
                for dto, fs in r["dto_only_fields"].items():
                    print(f"    {dto}: {', '.join(fs)}")
    return _emit(out, args.json, render)


def cmd_know(args) -> int:
    """What has already been verified about this workspace — with evidence.

    The point is to stop re-deriving. Every claim here cost a real investigation
    once; each carries its file:line and a check that re-runs on every build.
    """
    from .knowledge import Knowledge
    kb = Knowledge(KB).load()
    if not kb.claims:
        print("knowledge store is empty — run `graphify build --reseed`", file=sys.stderr)
        return 2
    hits = kb.search(args.topic)
    if args.kind:
        hits = [c for c in hits if c.kind == args.kind]
    if not hits:
        topics = sorted({c.topic for c in kb.claims.values()})
        print(f"nothing on {args.topic!r}. topics: {', '.join(topics)}", file=sys.stderr)
        return 1
    hits = hits[: args.limit]
    out = [{"id": c.id, "claim": c.claim, "topic": c.topic, "kind": c.kind,
            "status": c.status, "evidence": c.evidence, "detail": c.detail,
            "note": c.note} for c in hits]

    def render(recs):
        cur = None
        for r in recs:
            if r["topic"] != cur:
                cur = r["topic"]
                print(f"\n\033[1m# {cur}\033[0m")
            mark = {"fresh": "\033[32m✓\033[0m", "stale": "\033[31m✗ STALE\033[0m",
                    "unchecked": "\033[90m·\033[0m"}[r["status"]]
            tag = "⚠ " if r["kind"] == "gotcha" else ""
            print(f"\n  {mark} {tag}{r['claim']}")
            if r["detail"] and not args.brief:
                print(f"      \033[90m{r['detail'][:400]}\033[0m")
            if r["evidence"]:
                print(f"      {' · '.join(r['evidence'][:3])}")
            if r["status"] == "stale":
                print(f"      \033[31m{r['note']}\033[0m")
        print(f"\n  {len(recs)} claims")
    return _emit(out, args.json, render)


def cmd_brief(args) -> int:
    """A compact, paste-ready orientation block for one or more symbols.

    Generated from the graph rather than recalled, so it cannot drift from the code
    the way a hand-written handoff note does. Budgeted, because the whole point is to
    fit in a context window.
    """
    g = _load()
    budget = args.budget
    lines: list[str] = []
    seen_topics: set[str] = set()

    def emit(s: str) -> bool:
        """Append while the budget lasts. ~3.7 chars per token for prose+tables."""
        nonlocal budget
        cost = len(s) / 3.7
        if cost > budget:
            return False
        budget -= cost
        lines.append(s)
        return True

    emit(f"## Orientation — {', '.join(args.symbols)}")
    emit("")
    for sym in args.symbols:
        hits = _find(g, sym)
        if not hits:
            emit(f"### {sym}\n_not found in the graph_")
            continue
        n = hits[0]
        emit(f"### {n.name}  ({n.kind})")
        emit(f"`{_loc(n)}`" + (f" · {n.repo}" if n.repo else ""))
        if n.attrs.get("doc"):
            emit(f"\n{n.attrs['doc'][:400]}")
        trig = _entry_points(g, n.id)
        if trig:
            emit("\n**Triggered by:** " +
                 ", ".join(f"`{t['name']}`" for t in trig[:6]))
        guards = [x for x in n.attrs.get("guards", [])
                  if x.get("scope", "function") == "function"]
        if guards:
            emit("\n**Stops early when:**")
            for gd in guards[:6]:
                cond = gd["cond"]
                if gd.get("kind") == "elvis_return":
                    cond = f"{cond} == null"
                emit(f"- `{cond[:90]}` (:{gd['line']})")
        pub = sorted({g.nodes[e.dst].name for e in g.out_edges(n.id, "publishes_from")
                      if e.dst in g.nodes})
        if pub:
            emit("\n**Publishes:** " + ", ".join(f"`{p}`" for p in pub))
        deps = [g.nodes[e.dst].name for e in g.out_edges(n.id, M.INJECTS)
                if e.dst in g.nodes]
        if deps:
            emit("\n**Depends on:** " + ", ".join(f"`{d}`" for d in sorted(set(deps))[:10]))
        tests = [g.nodes[e.src].name for e in g.in_edges(n.id, "tests")
                 if e.src in g.nodes]
        emit("\n**Tests:** " + (", ".join(f"`{t}`" for t in tests) if tests
                                 else "_none mapped_"))
        seen_topics.add(n.repo)
        emit("")

    from .knowledge import Knowledge
    kb = Knowledge(KB).load()
    claims = []
    for sym in args.symbols:
        claims += [c for c in kb.search(sym)[:3]]
    if claims:
        emit("### Established constraints")
        for c in claims[:6]:
            emit(f"- {c.claim[:180]}" + (f"  `{c.evidence[0]}`" if c.evidence else ""))
        emit("")

    emit("### Re-orient with")
    emit("```bash")
    for sym in args.symbols[:4]:
        emit(f"graphify explain {sym}")
    emit("graphify know <topic>      # established conventions, with evidence")
    emit("graphify doctor            # is the graph trustworthy right now")
    emit("```")

    text = "\n".join(lines)
    if args.json:
        print(json.dumps({"brief": text,
                          "approx_tokens": int(len(text) / 3.7)}, indent=1))
    else:
        print(text)
        print(f"\n\033[90m~{int(len(text) / 3.7)} tokens\033[0m", file=sys.stderr)
    return 0


def cmd_trace(args) -> int:
    """Given a message a user or Sentry reported, find the code that emits it."""
    from .failures import search
    p = OUT / "messages.json"
    if not p.exists():
        print("no message index — run `graphify build`", file=sys.stderr)
        return 2
    _check_fresh(auto=_AUTO_REBUILD[0]) if not _NO_FRESHNESS[0] else None
    index = json.loads(p.read_text(encoding="utf-8"))
    hits = search(index, args.message, limit=args.limit)
    if not hits:
        print(f"no emission site matches {args.message!r}", file=sys.stderr)
        print("  the message may be interpolated with no literal run of 6+ chars, "
              "or emitted outside Kotlin (the app, or vision)", file=sys.stderr)
        return 1
    g = _load(check=False)
    out = []
    for h in hits:
        rec = dict(h)
        node = g.nodes.get(nid("kt", h["owner_fqn"])) if h["owner_fqn"] else None
        rec["guards"] = (node.attrs.get("guards", []) if node else [])[:4]
        rec["triggered_by"] = ([t["name"] for t in _entry_points(g, node.id)[:4]]
                               if node else [])
        out.append(rec)

    def render(recs):
        for r in recs:
            vis = {"yes": " \033[33m[user-visible]\033[0m",
                   "maybe": " \033[90m[may reach the user]\033[0m"}.get(
                       str(r["user_visible"]), "")
            print(f"\n\033[1m{r['file']}:{r['line']}\033[0m{vis}")
            print(f"  {r['kind']}"
                  + (f" · {r['exception']}" if r["exception"] else "")
                  + (f" · in {r['owner']}" if r["owner"] else "")
                  + f"  (match {r['coverage']:.0%})")
            print(f"  literal: {_cut(' … '.join(r['segments']), 150)}")
            if r["triggered_by"]:
                print(f"  reached from: {', '.join(r['triggered_by'])}")
            if r["guards"]:
                print("  guards on the way:")
                for gd in r["guards"]:
                    print(f"    :{gd['line']} {gd['cond'][:70]}")
        print(f"\n  {len(recs)} candidate sites")
    return _emit(out, args.json, render)


def cmd_status(args) -> int:
    """Where a domain status is written, and by what.

    Not a transition graph: only about half of writes have a statically knowable
    from-state, so this reports the writes it can prove rather than inventing edges.
    """
    g = _load()
    nodes = [n for n in g.nodes.values() if n.kind == "status"
             and (not args.enum or args.enum.lower() in n.name.lower())]
    if not nodes:
        enums = sorted({n.attrs["enum"] for n in g.nodes.values()
                        if n.kind == "status"})
        print("known status enums: " + ", ".join(enums), file=sys.stderr)
        return 1
    out = []
    for n in sorted(nodes, key=lambda x: x.name):
        writes = []
        for e in g.in_edges(n.id, "sets_status"):
            src = g.nodes.get(e.src)
            writes.append({"by": src.name if src else "?",
                           "repo": src.repo if src else "",
                           "kind": e.attrs.get("kind"),
                           "initial": bool(e.attrs.get("initial")),
                           "at": f"{e.file}:{e.line}"})
        out.append({"status": n.name, "enum": n.attrs["enum"],
                    "member": n.attrs["member"], "written_by": writes})

    def render(recs):
        cur = None
        for r in recs:
            if r["enum"] != cur:
                cur = r["enum"]
                print(f"\n\033[1m{cur}\033[0m")
            print(f"  {r['member']}")
            for wr in r["written_by"]:
                tag = " (initial)" if wr["initial"] else ""
                print(f"    ← {wr['by']}{tag}  {wr['at']}")
        print(f"\n  {len(recs)} states with a proven write site")
    return _emit(out, args.json, render)


def cmd_docs(args) -> int:
    """Claims the CLAUDE.md files make, checked against the code."""
    p = OUT / "docs.json"
    if not p.exists():
        print("no doc index — run `graphify build`", file=sys.stderr)
        return 2
    claims = json.loads(p.read_text(encoding="utf-8"))["claims"]
    if args.drift_only:
        claims = [c for c in claims if c["status"] == "drift"]
    if args.doc:
        claims = [c for c in claims if args.doc in c["doc"]]

    def render(recs):
        by = defaultdict(list)
        for c in recs:
            by[c["doc"]].append(c)
        for doc, cs in sorted(by.items()):
            drift = [c for c in cs if c["status"] == "drift"]
            print(f"\n\033[1m{doc}\033[0m  {len(cs)} claims"
                  + (f", \033[31m{len(drift)} drifted\033[0m" if drift else ""))
            for c in cs if args.drift_only else drift:
                print(f"  :{c['line']:<5} {_cut(c['claim'], 70)}")
                print(f"        \033[31m{c['detail']}\033[0m")
        total_d = sum(1 for c in recs if c["status"] == "drift")
        print(f"\n  {len(recs)} claims, {total_d} drifted")
    return _emit(claims, args.json, render)


def cmd_doctor(args) -> int:
    """Self-check the graph's invariants, and report drift worth acting on.

    Split deliberately: a FAIL means the extractor is wrong and the graph should not
    be trusted; a WARN is a fact about the codebase that the graph merely surfaced.
    """
    g = _load()
    fails, warns, oks = [], [], []

    # -- extractor invariants -------------------------------------------
    meta = json.loads((OUT / "meta.json").read_text()) if (OUT / "meta.json").exists() else {}
    st = meta.get("stats", {})
    kt, errs = st.get("kt_files", 0), st.get("kt_parse_errors", 0)
    if kt and errs / kt > 0.01:
        fails.append(f"{errs}/{kt} Kotlin files failed to parse cleanly (>1%)")
    else:
        oks.append(f"parse health: {kt - errs}/{kt} Kotlin files clean")

    cov = st.get("publish_coverage_pct")
    if cov is not None:
        sites = st.get("publish_call_sites_in_source", 0)
        got = st.get("publish_edges", 0)
        if cov < 90:
            fails.append(f"publish-site coverage {cov}% ({got}/{sites} `send*` call "
                         f"sites became edges) — a call position is being missed")
        else:
            oks.append(f"publish-site coverage {cov}% ({got}/{sites} `send*` call sites)")

    dups = st.get("duplicate_fqns", 0)
    if dups:
        merged = [f for f in {n.id.split("|", 1)[-1] for n in g.nodes.values()
                              if "|" in n.id}]
        if len(merged) < dups:
            fails.append(f"{dups} fully-qualified names are declared in more than one "
                         f"repo but only {len(merged)} were kept distinct — nodes merged")
        else:
            oks.append(f"{dups} cross-repo FQN collisions kept distinct "
                       "(repo-qualified node ids)")

    guarded = sum(1 for n in g.nodes.values() if n.attrs.get("guards"))
    documented = sum(1 for n in g.nodes.values() if n.attrs.get("doc"))
    if guarded == 0 or documented == 0:
        fails.append("behaviour layer is empty — KDoc and guard extraction produced "
                     "nothing, which means a parser change silently broke it")
    else:
        oks.append(f"behaviour layer: {documented:,} nodes with KDoc, "
                   f"{guarded:,} with guards")

    wfs = [n for n in g.nodes.values() if n.attrs.get("workflow")]
    wired = [n for n in wfs if any(
        g.out_edges(e.src, "step_next", "step_awaits")
        for e in g.in_edges(n.id, M.EXTENDS))]
    if wfs and len(wired) < len(wfs):
        dead = sorted(n.name for n in wfs if n not in wired)
        fails.append(f"{len(wfs) - len(wired)} workflow(s) have no derived transitions "
                     f"— the dispatch shape changed: {', '.join(dead)}")
    elif wfs:
        oks.append(f"{len(wfs)} workflows, all with derived transitions "
                   f"({sum(len(n.attrs.get('variants', [])) for n in wfs)} steps)")

    tbls = g.by_kind(M.TABLE)
    if tbls:
        nocols = [t.name for t in tbls if not t.attrs.get("columns")]
        if nocols:
            fails.append(f"{len(nocols)} Exposed tables parsed with zero columns "
                         f"— the DSL shape changed: {', '.join(nocols[:5])}")
        else:
            cols = sum(len(t.attrs.get("columns", [])) for t in tbls)
            oks.append(f"data layer: {len(tbls)} tables, {cols:,} columns")

    tests = [n for n in g.nodes.values() if n.kind == "test"]
    if tests:
        mapped = sum(1 for t in tests if t.attrs.get("resolved"))
        pct = 100 * mapped / len(tests)
        if pct < 50:
            fails.append(f"only {pct:.0f}% of test files resolved to a subject — "
                         "the test convention changed")
        else:
            oks.append(f"tests: {len(tests)} files / "
                       f"{sum(t.attrs.get('cases', 0) for t in tests):,} cases, "
                       f"{mapped} mapped to a subject ({pct:.0f}%)")
        # Untested use cases are a fact about the codebase, not a tool failure.
        ucs = [n for n in g.nodes.values()
               if n.kind == M.CLASS and n.name.endswith("UseCaseImpl")
               and n.repo in ("controlresell-backend", "controlresell-connector")]
        untested = [n for n in ucs if not g.in_edges(n.id, "tests")]
        if untested:
            warns.append(f"{len(untested)} of {len(ucs)} *UseCaseImpl in backend+"
                         f"connector have no mapped test")

    kstat = meta.get("knowledge") or {}
    if kstat:
        total = sum(kstat.values())
        if total == 0:
            fails.append("knowledge store is empty — run `graphify build --reseed`")
        else:
            oks.append(f"knowledge: {total} claims, {kstat.get('fresh', 0)} verified "
                       f"against source, {kstat.get('unchecked', 0)} uncheckable")
        if kstat.get("stale"):
            warns.append(f"{kstat['stale']} knowledge claims no longer hold — "
                         "`graphify know --kind gotcha` shows which")

    dclaims, ddrift = st.get("doc_claims", 0), st.get("doc_drift", 0)
    if dclaims:
        falsifiable = st.get("doc_falsifiable", dclaims)
        if ddrift:
            warns.append(f"{ddrift} of {falsifiable} structured CLAUDE.md claims no "
                         f"longer hold (of {dclaims} extracted; prose claims are out "
                         "of scope) — `graphify docs --drift-only`")
        else:
            oks.append(f"docs: {falsifiable} structured claims of {dclaims} extracted, "
                       "none drifted (prose claims are out of scope — see README)")

    cls = [n for n in g.nodes.values() if n.kind in (M.CLASS, M.INTERFACE)]
    if cls:
        cov = sum(1 for n in cls if _entry_points(g, n.id, max_hops=4))
        pct = 100 * cov / len(cls)
        if pct < 25:
            fails.append(f"only {pct:.0f}% of classes resolve to an entry point — "
                         "the trigger walk lost a path")
        else:
            oks.append(f"entry points: {cov:,} of {len(cls):,} classes reach a trigger "
                       f"({pct:.0f}%) — the rest are infrastructure or vendored")

    sw = st.get("status_writes", 0)
    if sw:
        oks.append(f"status writes: {sw} proven sites "
                   f"({st.get('status_opaque_writes', 0)} opaque writes where the "
                   "literal is not at the write)")

    msgs = st.get("message_sites", 0)
    if (OUT / "messages.json").exists():
        if msgs < 100:
            fails.append(f"failure index holds only {msgs} message sites — an emission "
                         "shape stopped being recognised")
        else:
            oks.append(f"failure index: {msgs} message sites "
                       f"({st.get('message_interpolated', 0)} interpolated)")

    keys = g.by_kind(M.ROUTING_KEY)
    bad = [k for k in keys if not k.attrs.get("const")]
    if bad:
        fails.append(f"{len(bad)} routing keys have no enum constant")
    else:
        oks.append(f"{len(keys)} routing keys, all mapped to an enum constant")

    # A repo may only have code edges to repos whose artifacts it actually pins.
    pinned: dict[str, set] = defaultdict(set)
    for e in g.edges:
        if e.kind != M.DEPENDS_ON:
            continue
        s_, d_ = g.nodes.get(e.src), g.nodes.get(e.dst)
        if not s_ or not d_:
            continue
        if d_.kind == M.ARTIFACT and d_.repo:
            pinned[s_.repo].add(d_.repo)
        elif s_.kind == M.REPO and d_.kind == M.REPO:
            pinned[s_.name].add(d_.name)
    CODE = (M.CALLS, M.INJECTS, M.EXTENDS, M.IMPLEMENTS, M.FIELD_OF, M.BINDS)
    illegal = defaultdict(list)
    for e in g.edges:
        if e.kind not in CODE:
            continue
        s_, d_ = g.nodes.get(e.src), g.nodes.get(e.dst)
        if not s_ or not d_ or not s_.repo or not d_.repo or s_.repo == d_.repo:
            continue
        if d_.repo not in pinned.get(s_.repo, set()):
            illegal[(s_.repo, d_.repo)].append(f"{s_.name}->{d_.name} @{e.file}:{e.line}")
    if illegal:
        for (a, b), ex in sorted(illegal.items(), key=lambda x: -len(x[1]))[:8]:
            fails.append(f"{len(ex):>4} code edges {a} -> {b}, but {a} pins no {b} artifact"
                         f"  e.g. {ex[0]}")
    else:
        oks.append("no code edge crosses a repo boundary that is not backed by a pin")

    # -- codebase drift (facts, not bugs) --------------------------------
    versions: dict[str, dict[str, str]] = defaultdict(dict)
    for e in g.edges:
        if e.kind != M.DEPENDS_ON or not e.attrs.get("version"):
            continue
        s_, d_ = g.nodes.get(e.src), g.nodes.get(e.dst)
        if s_ and d_ and d_.kind == M.ARTIFACT:
            versions[d_.name][s_.repo] = e.attrs["version"]
    for art, by in sorted(versions.items()):
        distinct = sorted(set(by.values()))
        if len(distinct) > 2:
            spread = ", ".join(f"{r.replace('controlresell-', '')}={v}"
                               for r, v in sorted(by.items()))
            warns.append(f"`{art}` pinned at {len(distinct)} different versions: {spread}")

    dead = [k.name for k in keys
            if not g.in_edges(k.id, M.PUBLISHES) and not g.in_edges(k.id, M.SUBSCRIBES)]
    if dead:
        warns.append(f"{len(dead)} routing keys with neither publisher nor subscriber "
                     f"in this workspace: {', '.join(dead)}")

    unhandled = [n.name for n in g.by_kind(M.VARIANT)
                 if "JobPayload" in n.id and not any(
                     g.nodes.get(e.src, Node('', '', '')).kind == M.SERVICE
                     for e in g.in_edges(n.id, M.HANDLES))]
    if unhandled:
        warns.append(f"{len(unhandled)} JobPayload variants with no handler in this "
                     f"workspace: {', '.join(unhandled)}")

    payload = {"fail": fails, "warn": warns, "ok": oks}

    def render(p):
        for f in p["fail"]:
            print(f"  \033[31mFAIL\033[0m  {f}")
        for wn in p["warn"]:
            print(f"  \033[33mWARN\033[0m  {wn}")
        for o in p["ok"]:
            print(f"  \033[32m ok \033[0m  {o}")
        print(f"\n  {len(p['fail'])} failures, {len(p['warn'])} warnings")
    _emit(payload, args.json, render)
    return 1 if fails else 0


def cmd_find(args) -> int:
    g = _load()
    hits = _find(g, args.term)
    total = len(hits)
    out = [{"name": n.name, "kind": n.kind, "repo": n.repo, "at": _loc(n)}
           for n in hits[: args.limit]]

    def render(recs):
        for r in recs:
            print(f"  {r['kind']:<12} {r['name']:<44} {r['repo']:<30} {r['at']}")
        shown = len(recs)
        more = f"  (showing {shown}; --limit to see more)" if total > shown else ""
        print(f"\n  {total} matches{more}")
    return _emit(out, args.json, render)


# --------------------------------------------------------------------- main
def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="graphify",
                                description=__doc__.split("\n")[0])
    p.add_argument("--json", action="store_true", help="machine-readable output")
    p.add_argument("--stale-ok", action="store_true",
                   help="skip the freshness check (faster; may answer from a stale graph)")
    p.add_argument("--no-auto-rebuild", action="store_true",
                   help="warn instead of rebuilding when the graph is stale")
    sub = p.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("build", help="walk the workspace and write the graph")
    b.add_argument("--root", default=str(DEFAULT_ROOT))
    b.add_argument("--include-tests", action="store_true")
    b.add_argument("--pretty", action="store_true", help="indent graph.json")
    b.add_argument("--reseed", action="store_true",
                   help="re-harvest the knowledge store from discovery transcripts")
    b.add_argument("--no-cache", action="store_true",
                   help="ignore the parse cache and re-parse everything")
    b.add_argument("--summary", help="where to write ARCHITECTURE_GRAPH.md")
    b.add_argument("-q", "--quiet", action="store_true")
    b.add_argument("-v", "--verbose", action="store_true")
    b.set_defaults(fn=cmd_build)

    k = sub.add_parser("key", help="publishers/subscribers/payloads of a routing key")
    k.add_argument("key")
    k.set_defaults(fn=cmd_key)

    c = sub.add_parser("contract", help="a DTO's fields, producers and consumers")
    c.add_argument("type")
    c.set_defaults(fn=cmd_contract)

    ca = sub.add_parser("callers", help="who calls / injects / handles a symbol")
    ca.add_argument("symbol")
    ca.add_argument("--depth", type=int, default=2)
    ca.set_defaults(fn=cmd_callers)

    im = sub.add_parser("impact", help="blast radius of changing a symbol")
    im.add_argument("symbol")
    im.add_argument("--depth", type=int, default=3)
    im.set_defaults(fn=cmd_impact)

    d = sub.add_parser("deps", help="what a repo pins, and who pins it")
    d.add_argument("repo")
    d.set_defaults(fn=cmd_deps)

    r = sub.add_parser("routes", help="HTTP route table")
    r.add_argument("repo", nargs="?", default="")
    r.set_defaults(fn=cmd_routes)

    f = sub.add_parser("find", help="locate anything by name")
    f.add_argument("term")
    f.add_argument("--limit", type=int, default=30)
    f.set_defaults(fn=cmd_find)

    ex = sub.add_parser("explain", help="full briefing on a symbol (start here)")
    ex.add_argument("symbol")
    ex.set_defaults(fn=cmd_explain)

    wf = sub.add_parser("workflow", help="render a workflow's derived state machine")
    wf.add_argument("name", nargs="?", default="")
    wf.set_defaults(fn=cmd_workflow)

    tb = sub.add_parser("table", help="columns of an Exposed table + its DTO mapping")
    tb.add_argument("name")
    tb.set_defaults(fn=cmd_table)

    stc = sub.add_parser("status", help="where a domain status is written")
    stc.add_argument("enum", nargs="?", default="")
    stc.set_defaults(fn=cmd_status)

    dc = sub.add_parser("docs", help="check CLAUDE.md claims against the code")
    dc.add_argument("doc", nargs="?", default="")
    dc.add_argument("--drift-only", action="store_true")
    dc.set_defaults(fn=cmd_docs)

    tr = sub.add_parser("trace", help="find the code that emits a reported message")
    tr.add_argument("message")
    tr.add_argument("--limit", type=int, default=6)
    tr.set_defaults(fn=cmd_trace)

    br = sub.add_parser("brief", help="paste-ready orientation block for a fresh session")
    br.add_argument("symbols", nargs="+")
    br.add_argument("--budget", type=int, default=1200,
                    help="approximate token ceiling for the output")
    br.set_defaults(fn=cmd_brief)

    kn = sub.add_parser("know", help="verified knowledge about this workspace")
    kn.add_argument("topic", nargs="?", default="")
    kn.add_argument("--kind", choices=["convention", "gotcha", "count", "contract",
                                       "process"])
    kn.add_argument("--limit", type=int, default=25)
    kn.add_argument("--brief", action="store_true", help="claims only, no detail")
    kn.set_defaults(fn=cmd_know)

    dr = sub.add_parser("doctor", help="self-check invariants and report drift")
    dr.set_defaults(fn=cmd_doctor)

    s = sub.add_parser("stats", help="graph size and composition")
    s.set_defaults(fn=cmd_stats)

    rt = sub.add_parser("root", help="the workspace root graphify resolved to")
    rt.set_defaults(fn=cmd_root)

    args = p.parse_args(argv)
    _NO_FRESHNESS[0] = getattr(args, "stale_ok", False)
    _AUTO_REBUILD[0] = not getattr(args, "no_auto_rebuild", False)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
